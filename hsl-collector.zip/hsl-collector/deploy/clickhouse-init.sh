#!/bin/bash
# Runs once, on the first start of an empty ClickHouse data volume (official image,
# /docker-entrypoint-initdb.d). Creates the least-privilege account the collector uses:
# full rights on database `hsl` only, read access to two system tables for the
# disk guard - nothing else (no other databases, no user management).
set -euo pipefail
: "${HSL_APP_PASSWORD:?HSL_APP_PASSWORD must be set}"
case "$HSL_APP_PASSWORD" in *"'"*|*"\\"*) echo "HSL_APP_PASSWORD must not contain ' or \\" >&2; exit 1;; esac

clickhouse client --user "$CLICKHOUSE_USER" --password "$CLICKHOUSE_PASSWORD" --multiquery <<SQL
CREATE DATABASE IF NOT EXISTS hsl;
CREATE USER IF NOT EXISTS hsl_app IDENTIFIED WITH sha256_password BY '${HSL_APP_PASSWORD}';
GRANT ALL ON hsl.* TO hsl_app;
GRANT SELECT ON system.parts TO hsl_app;
GRANT SELECT ON system.disks TO hsl_app;
SQL
echo "created ClickHouse user hsl_app"
