"""Security regression tests. Run: python3 -m pytest -q tests

No ClickHouse needed; these cover the attack surface reachable without a login
(UDP decoder) and the authentication logic.
"""
import json
import random
import struct
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tools")]

import hsl_simulator as sim  # noqa: E402
from hslc.auth import AuthError, Sessions, Throttle, UserStore, clean  # noqa: E402
from hslc.decoder import Decoder, hsl_row, syslog_row  # noqa: E402
from hslc.maintenance import clean_name  # noqa: E402
from hslc.pipeline import _allowed  # noqa: E402
import ipaddress  # noqa: E402


# ---------------------------------------------------------------- UDP / decoder
def _ipfix(tid, fields, record):
    tpl = struct.pack("!HH", tid, len(fields)) + b"".join(struct.pack("!HH", f, l) for f, l in fields)
    body = struct.pack("!HH", 2, 4 + len(tpl)) + tpl + struct.pack("!HH", tid, 4 + len(record)) + record
    return struct.pack("!HHIII", 10, 16 + len(body), int(time.time()), 0, 1) + body


ROW_TYPES = {"proto": (int, 0, 255), "src_port": (int, 0, 65535), "dst_port": (int, 0, 65535),
             "bytes": (int, 0, 2**64 - 1), "packets": (int, 0, 2**64 - 1), "in_if": (int, 0, 2**32 - 1),
             "out_if": (int, 0, 2**32 - 1), "vrf": (int, 0, 2**32 - 1), "ext_event": (int, 0, 65535),
             "xlate_src_port": (int, 0, 65535), "xlate_dst_port": (int, 0, 65535)}


def _check_row(row):
    for k, (t, lo, hi) in ROW_TYPES.items():
        assert type(row[k]) is t and lo <= row[k] <= hi, (k, row[k])
    for k in ("src_ip", "dst_ip", "xlate_src_ip", "xlate_dst_ip", "event", "class_name",
              "in_if_name", "out_if_name", "extra", "message"):
        assert isinstance(row[k], str), (k, row[k])
    json.dumps(row)


@pytest.mark.parametrize("fields,record", [
    ([(8, 4), (231, 12)], b"\x0a\x06\x06\x06" + b"A" * 12),        # counter field as text (crashed v2.2)
    ([(8, 4), (4, 10)], b"\x0a\x06\x06\x07" + b"POISONPILL"),       # protocol as text (blocked inserts)
    ([(7, 4), (11, 8), (4, 2)], struct.pack("!IQH", 99999, 2**40, 300)),  # out-of-range numbers
    ([(8, 16), (12, 3)], b"\x01" * 19),                              # wrong address lengths
    ([(233, 8)], struct.pack("!Q", 2**63)),                          # huge firewall event code
])
def test_crafted_records_produce_valid_rows(fields, record):
    d = Decoder()
    recs = d.parse(_ipfix(300, fields, record), "198.51.100.1", 1)
    assert recs, "record should decode"
    for r in recs:
        _check_row(hsl_row(r, "198.51.100.1", time.time()))


def test_decoder_fuzz_no_exceptions():
    random.seed(7)
    seeds = []
    for ipfix in (False, True):
        r = sim.Router(None, ipfix)
        seeds += [r.packet(5, True)] + [r.packet(19) for _ in range(3)]
    d = Decoder()
    for i in range(15000):
        b = bytearray(random.choice(seeds))
        for _ in range(random.randint(1, 10)):
            if b and random.random() < 0.6:
                b[random.randrange(len(b))] = random.randrange(256)
            elif b:
                del b[random.randrange(len(b)):random.randrange(len(b) + 1)]
        for rec in d.parse(bytes(b), f"10.0.{i % 3}.1", i % 4):     # must never raise
            _check_row(hsl_row(rec, "x", time.time()))
        _check_row(syslog_row(bytes(b), "x", time.time()))


def test_template_and_stream_limits():
    d = Decoder({"max_templates": 10, "max_streams": 3, "max_fields": 50, "max_exporters": 2})
    for port in range(6):                                   # 6 streams from one router
        for tid in range(256, 300):                         # 44 templates each
            d.parse(_ipfix(tid, [(8, 4)], b"\x01\x02\x03\x04"), "10.0.0.1", port)
    assert len(d.streams["10.0.0.1"]) == 3
    assert sum(1 for k in d.templates if k[0] == "10.0.0.1") <= 10
    d.parse(_ipfix(400, [(8, 4)] * 51, b"\x00" * 204), "10.0.0.1", 0)    # too many fields
    assert all(k[4] != 400 for k in d.templates)
    d.parse(_ipfix(256, [(8, 4)], b"\x01\x02\x03\x04"), "10.0.0.2", 0)
    d.parse(_ipfix(256, [(8, 4)], b"\x01\x02\x03\x04"), "10.0.0.3", 0)   # third router refused
    assert "10.0.0.3" not in d.exporters and d.rejected_exporters == 1


def test_allowlist():
    nets = [ipaddress.ip_network("10.0.0.0/8"), ipaddress.ip_network("2001:db8::/32")]
    assert _allowed("10.1.2.3", nets) and _allowed("2001:db8::1", nets)
    assert not _allowed("192.0.2.1", nets) and not _allowed("garbage", nets)


# ---------------------------------------------------------------- auth
@pytest.fixture
def users(tmp_path):
    return UserStore(str(tmp_path))


def test_default_admin_and_hashing(users, tmp_path):
    assert users.verify("admin", "admin") == "admin"
    assert users.public("admin")["default_password"] is True
    stored = json.loads((tmp_path / "users.json").read_text())["admin"]
    assert stored["hash"].startswith("pbkdf2_sha256$") and "admin" not in stored["hash"]
    assert "password" not in stored
    assert oct((tmp_path / "users.json").stat().st_mode & 0o777) == "0o600"


@pytest.mark.parametrize("pw", ["short", "admin123", "Admin-pass", "aaaaaaaaaaaa", "password", "12345678"])
def test_weak_passwords_rejected(users, pw):
    with pytest.raises(AuthError):
        users.set_password("admin", pw)


def test_last_admin_and_roles(users):
    users.set_password("admin", "Kq7-river-lamp")
    with pytest.raises(AuthError):
        users.set_role("admin", "viewer")
    with pytest.raises(AuthError):
        users.delete("admin")
    users.add("noc", "Tide-42-orbit", "viewer")
    with pytest.raises(AuthError):
        users.add("bad name", "Tide-42-orbit", "viewer")
    assert users.verify("noc", "Tide-42-orbit") == "noc" and users.verify("noc", "x") is None
    assert users.verify("nobody", "x") is None


def test_throttle_locks_and_recovers():
    t = Throttle(limit=3, base=60)
    for _ in range(2):
        t.fail("a")
    assert t.check("a") == 0
    t.fail("a")
    assert t.check("a") > 0
    t.ok("a")
    assert t.check("a") == 0


def test_sessions_capped_per_user():
    s = Sessions()
    tokens = [s.create("u") for _ in range(60)]
    assert sum(1 for v in s.s.values() if v["user"] == "u") == 50
    assert s.get(tokens[-1]) == "u" and s.get(tokens[0]) is None


def test_log_and_name_sanitising():
    assert "\n" not in clean("evil\nFAKE LOG LINE") and len(clean("x" * 500)) == 64
    assert clean_name("ams\x07-01\n") == "ams -01" and len(clean_name("a" * 300)) == 128


def test_csv_formula_protection():
    import collector
    assert collector.csv_cell("=1+1") == "'=1+1" and collector.csv_cell("ams-01") == "ams-01"
    sql = collector.csv_safe("message")
    assert "IN ('=', '+', '-', '@'" in sql and sql.endswith("AS message")
