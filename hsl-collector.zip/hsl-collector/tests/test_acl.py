"""Access list tests. Run: python3 -m pytest -q tests"""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hslc.acl import AclError, AclStore, matcher, parse_network  # noqa: E402


def test_parse_network():
    assert str(parse_network("10.1.2.3")) == "10.1.2.3/32"
    assert str(parse_network(" 10.1.2.3/16 ")) == "10.1.0.0/16"        # host bits cleared
    assert str(parse_network("2001:db8::1")) == "2001:db8::1/128"
    for bad in ("", "10.300.1.1", "bogus", "10.0.0.0/33", "0.0.0.0/0", "::/0"):
        with pytest.raises(AclError):
            parse_network(bad)


def test_matcher_v4_v6():
    m = matcher(["10.0.0.0/8", "192.0.2.7/32", "2001:db8::/32"])
    assert m("10.200.1.1") and m("192.0.2.7") and m("2001:db8::5")
    assert not m("192.0.2.8") and not m("11.0.0.1") and not m("2001:db9::1") and not m("x")
    assert not matcher([])("10.0.0.1")


def test_add_dedupe_errors_and_persistence(tmp_path):
    a = AclStore(str(tmp_path))
    pushed = []
    a.listeners.append(pushed.append)
    a.add("10.1.0.1", "ams\x07-01\n", "admin")
    res = a.add_many([("10.1.0.1", "dup"), ("10.2.0.0/16", "site"), ("nope", "")], "admin")
    assert [e["network"] for e in res["added"]] == ["10.2.0.0/16"]
    assert res["skipped"] == ["10.1.0.1/32"] and len(res["errors"]) == 1
    assert a.snapshot()["entries"][0]["description"] == "ams -01"      # control chars removed
    a.set_mode("enforce")
    assert pushed[-1] == {"enforce": True, "networks": ["10.1.0.1/32", "10.2.0.0/16"]}
    f = tmp_path / "acl.json"
    assert oct(f.stat().st_mode & 0o777) == "0o600"
    b = AclStore(str(tmp_path))                                          # reload from disk
    assert b.effective() == pushed[-1]
    b.remove(b.snapshot()["entries"][0]["id"])
    assert json.loads(f.read_text())["entries"][0]["network"] == "10.2.0.0/16"
    with pytest.raises(AclError):
        b.remove("does-not-exist")


def test_single_invalid_add_raises(tmp_path):
    with pytest.raises(AclError):
        AclStore(str(tmp_path)).add("10.300.0.1", "", "admin")


def test_config_entries_lock_enforcement(tmp_path):
    a = AclStore(str(tmp_path), ["10.9.0.0/16"])
    snap = a.snapshot()
    assert snap["locked"] and snap["mode"] == "enforce" and a.effective()["enforce"]
    assert snap["entries"][0]["source"] == "config"
    with pytest.raises(AclError):
        a.set_mode("open")
    with pytest.raises(AclError):
        a.remove("config-0")
    assert a.add_many([("10.9.0.0/16", "")], "admin")["skipped"] == ["10.9.0.0/16"]
