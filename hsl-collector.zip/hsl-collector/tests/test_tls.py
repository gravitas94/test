"""Certificate management tests with a throwaway test CA. Run: python3 -m pytest -q tests"""
import datetime as dt
import sys
from pathlib import Path

import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.hazmat.primitives.serialization import pkcs7, pkcs12
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hslc.tls import CertError, TlsManager, host_matches, load_certs  # noqa: E402

NOW = dt.datetime.now(dt.timezone.utc)


def _name(cn):
    return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])


def _ca(cn, signer=None, signer_key=None):
    key = ec.generate_private_key(ec.SECP256R1())
    b = (x509.CertificateBuilder().subject_name(_name(cn))
         .issuer_name(signer.subject if signer else _name(cn)).public_key(key.public_key())
         .serial_number(x509.random_serial_number())
         .not_valid_before(NOW - dt.timedelta(days=1)).not_valid_after(NOW + dt.timedelta(days=3650))
         .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True))
    return b.sign(signer_key or key, hashes.SHA256()), key


@pytest.fixture(scope="module")
def pki():
    root, root_key = _ca("Test Root CA")
    inter, inter_key = _ca("Test Issuing CA", root, root_key)
    return root, root_key, inter, inter_key


def _leaf(pub, issuer, issuer_key, names=("hsl.example.net",), days=365, eku=True, start=-1, algo=None):
    b = (x509.CertificateBuilder().subject_name(_name(names[0] if names else "x"))
         .issuer_name(issuer.subject).public_key(pub).serial_number(x509.random_serial_number())
         .not_valid_before(NOW + dt.timedelta(days=start)).not_valid_after(NOW + dt.timedelta(days=days)))
    if names:
        b = b.add_extension(x509.SubjectAlternativeName([x509.DNSName(n) for n in names]), critical=False)
    if eku is not None:
        usage = [ExtendedKeyUsageOID.SERVER_AUTH] if eku else [ExtendedKeyUsageOID.CLIENT_AUTH]
        b = b.add_extension(x509.ExtendedKeyUsage(usage), critical=False)
    return b.sign(issuer_key, algo or hashes.SHA256())


def _pem(*certs):
    return b"".join(c.public_bytes(serialization.Encoding.PEM) for c in certs)


def _kpem(key, pw=None):
    enc = serialization.BestAvailableEncryption(pw.encode()) if pw else serialization.NoEncryption()
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, enc)


@pytest.fixture
def mgr(tmp_path):
    return TlsManager(str(tmp_path))


def test_first_start_self_signed(mgr, tmp_path):
    info = mgr.info()
    assert info["active"]["self_signed"] and "localhost" in info["active"]["names"]
    assert oct((tmp_path / "tls" / "active.key").stat().st_mode & 0o777) == "0o600"
    assert oct((tmp_path / "tls").stat().st_mode & 0o777) == "0o700"
    ctx = mgr.make_context()
    assert ctx.minimum_version.name == "TLSv1_2"


def test_csr_flow_with_chain_in_wrong_order(mgr, pki):
    root, root_key, inter, inter_key = pki
    pem = mgr.create_csr("hsl.example.net", ["hsl", "10.0.0.5"], "Example BV", "NL", "rsa2048", "admin")
    csr = x509.load_pem_x509_csr(pem.encode())
    san = csr.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert "hsl.example.net" in san.get_values_for_type(x509.DNSName)
    assert mgr.info()["pending"]["common_name"] == "hsl.example.net"
    leaf = _leaf(csr.public_key(), inter, inter_key, names=["hsl.example.net", "hsl"])
    warnings = mgr.complete_csr(_pem(root, leaf, inter), "admin", hosts=["hsl.example.net"])  # unordered
    a = mgr.info()["active"]
    assert a["subject"] == "hsl.example.net" and a["issuer"] == "Test Issuing CA"
    assert [c["subject"] for c in a["chain"]] == ["Test Issuing CA", "Test Root CA"]
    assert mgr.info()["pending"] is None and mgr.info()["previous"]["self_signed"]
    assert not any("expire" in w for w in warnings)


def test_csr_rejects_foreign_certificate(mgr, pki):
    _, _, inter, inter_key = pki
    mgr.create_csr("hsl.example.net", [], "", "", "ec256", "admin")
    other = _leaf(ec.generate_private_key(ec.SECP256R1()).public_key(), inter, inter_key)
    with pytest.raises(CertError, match="not issued for the open request"):
        mgr.complete_csr(_pem(other, inter), "admin")


def test_import_pem_der_p7b_and_pfx(mgr, pki):
    root, root_key, inter, inter_key = pki
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    leaf = _leaf(key.public_key(), inter, inter_key)
    mgr.import_pair(_pem(leaf, inter), _kpem(key, "s3cret-pw"), "s3cret-pw", "admin")
    assert mgr.info()["active"]["key"] == "RSA 2048"
    der = leaf.public_bytes(serialization.Encoding.DER)
    assert load_certs(der)[0] == leaf
    p7 = pkcs7.serialize_certificates([leaf, inter], serialization.Encoding.DER)
    assert len(load_certs(p7)) == 2
    pfx = pkcs12.serialize_key_and_certificates(b"hsl", key, leaf, [inter, root],
                                                serialization.BestAvailableEncryption(b"pfx-pw"))
    mgr.import_pkcs12(pfx, "pfx-pw", "admin")
    assert len(mgr.info()["active"]["chain"]) == 2
    with pytest.raises(CertError, match="wrong password"):
        mgr.import_pkcs12(pfx, "nope", "admin")


@pytest.mark.parametrize("case,match", [
    ("mismatch", "doesn't belong"),
    ("expired", "expired"),
    ("future", "not valid until"),
    ("no_san", "Subject Alternative Names"),
    ("client_eku", "not allowed for servers"),
    ("weak_rsa", "too weak"),
    ("needs_pw", "password"),
])
def test_rejections(mgr, pki, case, match):
    _, _, inter, inter_key = pki
    key = ec.generate_private_key(ec.SECP256R1())
    pub, kpem, pw = key.public_key(), _kpem(key), None
    kw = {}
    if case == "mismatch":
        pub = ec.generate_private_key(ec.SECP256R1()).public_key()
    elif case == "expired":
        kw = {"days": -1, "start": -30}
    elif case == "future":
        kw = {"start": 5}
    elif case == "no_san":
        kw = {"names": []}
    elif case == "client_eku":
        kw = {"eku": False}
    elif case == "weak_rsa":
        k = rsa.generate_private_key(public_exponent=65537, key_size=1024)
        pub, kpem = k.public_key(), _kpem(k)
    elif case == "needs_pw":
        kpem = _kpem(key, "pw-123456")
    leaf = _leaf(pub, inter, inter_key, **kw)
    before = mgr.info()["active"]["sha256"]
    with pytest.raises(CertError, match=match):
        mgr.import_pair(_pem(leaf, inter), kpem, pw, "admin")
    assert mgr.info()["active"]["sha256"] == before          # nothing changed


def test_warnings_and_rollback(mgr, pki):
    _, _, inter, inter_key = pki
    key = ec.generate_private_key(ec.SECP256R1())
    leaf = _leaf(key.public_key(), inter, inter_key, days=10)
    w = mgr.import_pair(_pem(leaf), _kpem(key), None, "admin", hosts=["other.example.net"])
    text = " ".join(w)
    assert "expires in" in text and "Not valid for 'other.example.net'" in text and "intermediate" in text
    first = mgr.info()
    mgr.rollback("admin")
    assert mgr.info()["active"]["self_signed"]
    mgr.rollback("admin")
    assert mgr.info()["active"]["sha256"] == first["active"]["sha256"]


def _served_cert(ctx):
    """Handshake against ctx (in memory) and return the certificate the server presented."""
    import ssl
    c_in, c_out, s_in, s_out = ssl.MemoryBIO(), ssl.MemoryBIO(), ssl.MemoryBIO(), ssl.MemoryBIO()
    cctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    cctx.check_hostname, cctx.verify_mode = False, ssl.CERT_NONE
    cli = cctx.wrap_bio(c_in, c_out, server_hostname="hsl.example.net")
    srv = ctx.wrap_bio(s_in, s_out, server_side=True)
    for _ in range(10):
        for obj in (cli, srv):
            try:
                obj.do_handshake()
            except ssl.SSLWantReadError:
                pass
        s_in.write(c_out.read())
        c_in.write(s_out.read())
    return x509.load_der_x509_certificate(cli.getpeercert(binary_form=True))


def test_live_reload_switches_key_type(mgr, pki):
    """Self-signed ECDSA -> CA-signed RSA must be served without a restart."""
    _, _, inter, inter_key = pki
    ctx = mgr.make_context()
    assert _served_cert(ctx).issuer == _served_cert(ctx).subject       # self-signed at first
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    leaf = _leaf(key.public_key(), inter, inter_key)
    mgr.import_pair(_pem(leaf, inter), _kpem(key), None, "admin")
    assert _served_cert(ctx) == leaf                                   # same listening context


def test_locked_by_config(tmp_path):
    m0 = TlsManager(str(tmp_path / "a"))
    m = TlsManager(str(tmp_path / "b"), str(m0.cert_path), str(m0.key_path))
    assert m.info()["locked"]
    with pytest.raises(CertError, match="--tls-cert"):
        m.self_signed(["x"], "admin")


def test_host_matching_and_name_validation(mgr):
    assert host_matches("hsl.example.net", ["*.example.net"])
    assert not host_matches("a.b.example.net", ["*.example.net"])
    assert host_matches("10.0.0.5", ["10.0.0.5"])
    with pytest.raises(CertError, match="not a valid host name"):
        mgr.create_csr("bad name!", [], "", "", "ec256", "admin")
    with pytest.raises(CertError, match="2-letter"):
        mgr.create_csr("hsl.example.net", [], "", "Netherlands", "ec256", "admin")


def test_default_names_skip_reverse_dns(monkeypatch):
    import hslc.tls as T
    monkeypatch.setattr(T.socket, "getfqdn", lambda: "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa")
    monkeypatch.setattr(T.socket, "gethostname", lambda: "Ratis-MBP.local")
    names = T.default_names()
    assert not any(n.endswith(".arpa") for n in names)
    assert names[0] == "Ratis-MBP.local" and "localhost" in names and "127.0.0.1" in names
