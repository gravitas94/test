# HSL Collector v2.5 — Cisco SD-WAN High Speed Logging at 100+ router scale

Receives **High Speed Logging (HSL)** from Cisco Catalyst SD-WAN edge routers
(IOS XE), decodes it, stores it in **ClickHouse** and shows it in a web GUI.
HSL firewall logs arrive as NetFlow v9; IPFIX and syslog are accepted too.

## Architecture

```
 100+ routers ──UDP 2055──► receiver process ──hash(router IP)──► decoder 0 ─┐
              ──UDP 5514──►  (reads packets only)               ► decoder 1 ─┼─► ClickHouse ◄── web GUI / API
                                                                 ► decoder N ─┘   (batched inserts)
```

| Piece | What it does | Why it scales |
|---|---|---|
| Receiver | One process reads the UDP sockets (32 MB buffer) and hands packets out in batches | Only copies bytes; handles far more packets/s than 100 routers send |
| Decoders | N processes (default: CPU cores − 1). Each router always goes to the same decoder, so its templates and sequence numbers live in one place | Uses all CPU cores; ~40,000 records/s per core |
| Fast decode | Fixed-length templates are compiled once and decoded with a single `struct.iter_unpack` per data set | ~4× faster than field-by-field decoding (decoding is no longer the bottleneck) |
| ClickHouse | Column database; inserts every second in batches of up to 50k rows; 7× – 10× compression | Handles millions of rows/s and billions of rows on disk |
| Rollup tables | Per-minute counts, top talkers and ports are kept in small summary tables, filled automatically by ClickHouse | Dashboard stays instant at any data volume |
| Template persistence | Learned templates/names are saved every 30 s | After a collector restart, data is decoded immediately — no waiting for the routers' next template refresh |
| Retention | ClickHouse TTL drops whole days automatically | No slow DELETEs |

### Loss is measured, not guessed

The **Lost / dropped** card and the *Routers → Pipeline* view show every place an event can disappear:

| Counter | Meaning | Fix |
|---|---|---|
| Lost (seq gaps) | Gaps in each router's NetFlow/IPFIX sequence numbers → packets lost **in the network** before reaching the collector | Check WAN/QoS path, put the collector close to the routers |
| Socket overflow (Linux) | Kernel dropped packets because the UDP buffer was full | `sysctl-hsl.conf`, more `--workers` |
| Decoder overload | Decoders could not keep up | More CPU cores / `--workers` |
| DB backlog | ClickHouse unreachable longer than the buffer holds (256 MB ≈ 500k events per decoder) | Fix ClickHouse; buffered rows are retried every 2 s |

## Users and login

The GUI and API require a login. On first start the collector creates
**admin / admin**. After signing in with it you must choose a new password
before anything else works (GUI and API).

| Role | Can do |
|---|---|
| **admin** | everything: view data, edit/import router names, manage users |
| **viewer** | view everything (events, dashboards, CSV export), change nothing except their own password |

- **Users tab** (admins): add users, choose role, set any user's password,
  change roles, delete users. The last admin can't be deleted or demoted, and
  you can't delete yourself.
- **Your own password:** user menu (top right) → *Change my password*
  (asks for the current one). Works for viewers too.
- Changing a password or role, or deleting a user, signs that user out
  everywhere immediately.
- Passwords: minimum 8 characters, not a common word, not containing the
  username, at least 4 different characters. Stored as salted PBKDF2-SHA256
  hashes in `state/users.json` (file mode 600). Never in clear text.
- Brute-force protection: after 5 wrong passwords from one address, or 10 for
  one username from anywhere, login is blocked for 60 s / 30 s (doubling up
  to 15 min).
- Sessions: HttpOnly, SameSite=Strict cookie; ends after 12 h idle or 7 days;
  a collector restart signs everyone out.
- Scripts can use HTTP Basic auth with the same accounts, e.g.
  `curl -u noc:password https://collector:8443/api/stats` (add `--cacert your-ca.pem`).
- `/api/health` answers without login for monitoring tools, but then only with
  `status` and `problems`; turn that off with `--no-public-health`.

**Locked out?** On the collector host run

```bash
python3 collector.py --reset-admin          # Docker: docker exec hsl-collector python collector.py --reset-admin
```

This sets `admin` back to password `admin` (role admin); a running collector
picks it up immediately. Use the same `--state-dir` as the service.

Security details: [SECURITY.md](SECURITY.md).

## HTTPS and certificates

The GUI and API are **HTTPS only**, on port **8443**. Port **8080** only
redirects to HTTPS (same path), so old bookmarks keep working.

- **First start:** a self-signed certificate is created for the host's names and
  IPs (add more with `--tls-hostnames` / `HSL_TLS_HOSTNAMES`). Browsers warn
  about it until you install a CA-signed certificate.
- **Certificate tab** (admins), two ways to install one from your CA:
  1. **Certificate request (recommended):** enter the host name and any other
     names/IPs → **Create request** → download the `.csr` and send it to your
     CA → upload the issued certificate (`.cer`, `.crt`, `.pem` or `.p7b`,
     preferably with the CA chain) → **Validate and install**. The private key
     is generated on the server and never leaves it.
  2. **Import:** certificate + private key (PEM/DER, optionally
     password-protected) or a `.pfx`/`.p12` file with its password.
- **Checked before activation:** the key matches, the chain is complete and in
  order, the certificate is currently valid, the key is strong enough (RSA ≥ 2048,
  ECDSA P-256/384), it has Subject Alternative Names, and it is allowed for
  servers. Problems are rejected with a clear message and the current
  certificate stays. Warnings (e.g. the name you're browsing with isn't in the
  certificate, missing intermediate, expiring within 30 days) are shown after
  installing.
- **No restart:** a new certificate is used from the next connection; reload
  the page. The previous certificate is kept: **Roll back** restores it.
- **Monitoring:** the health status warns 30 days before expiry and while a
  self-signed certificate is used, and is critical once it has expired.
- Every change is logged with the user name and the new certificate's
  SHA-256 fingerprint. Private keys are stored with mode 600 in `state/tls/`
  and are never shown or downloadable.
- TLS 1.2 and 1.3 only, forward-secret AES-GCM / ChaCha20 ciphers, HSTS.

Options: `--tls-cert`/`--tls-key` pin a certificate from files (the GUI then
shows it read-only). `--no-tls` (`HSL_TLS=off`) serves plain HTTP on the web
port - only for running behind a reverse proxy that terminates TLS, together
with `--trusted-proxies`.

## Access list (authorized routers)

The **Access list** tab decides which routers may send HSL and syslog to the
collector. Packets from other addresses are dropped before decoding.

1. Start in **Not enforced** mode: everything is accepted, and every sender
   that isn't on the list yet shows up under *Senders not on the list*, with
   its router name and packet count.
2. Add your routers: **Allow** next to a sender, **Allow all shown**, type an
   IP or network (`10.1.2.3`, `10.20.0.0/16`, IPv6 too) with a description, or
   **Add several…** to paste a list (`IP[/len], description` per line).
3. Click **Enforce access list**. If routers that sent logs in the last hour
   are not on the list, you're asked to confirm and shown which ones.

Changes apply immediately, without a restart. Admins can change the list;
viewers can see it. Every change is written to the service log with the user
name. The list is stored in `state/acl.json` (not in ClickHouse), so it keeps
working while the database is down.

Use the address each router sends from, i.e. its HSL source interface. For
the 100-router case, the quickest way is: leave it open for a day, then
**Allow all shown**, check the list, and enforce.

`--allow` / `HSL_ALLOW` still works: those entries are fixed (shown as
*server config*, not removable in the GUI) and keep enforcement switched on.
Use it when the access list must not be changeable from the GUI.

The health status warns while the list is not enforced, and is critical if it
is enforced but empty (all logs blocked).

## Disk protection

The collector never lets ClickHouse fill the disk:

1. **Retention by day.** Every minute, whole days older than `--retention-days`
   are deleted. This is instant, also right after you lower the retention.
2. **Free-space guard.** If free space on ClickHouse's disk drops below
   `--min-free-pct` (15%), the **oldest day** is deleted, one day per check,
   until there is room again. Today's data is never deleted. Every deletion is
   listed under *Routers → Storage* and in the log.
3. **Visibility.** The *Disk free* card shows free space and days until the
   limit at the current rate. *Routers → Storage* shows growth per day and
   whether the disk is big enough for the configured retention. Warnings appear
   below `--warn-free-pct` (25%), when the limit is < 3 days away, or when the
   retention doesn't fit.
4. **Bounded memory.** While ClickHouse is unreachable, each decoder buffers at
   most `--max-buffer-mb` (256 MB); beyond that new events are dropped and
   counted, instead of running the VM out of memory. Memory budget:
   workers × 256 MB.

Put ClickHouse's data on its own disk (not the OS disk) so a full data disk
can never affect the operating system.

### Monitoring

`GET /api/health` returns `"status": "ok" | "warning" | "critical"` and a list
of `problems`. With `?strict=1` it answers **HTTP 503** when critical (process
down, database unreachable or failing, disk below the minimum), so any HTTP
monitor (Zabbix, PRTG, Uptime Kuma, Nagios `check_http`) can alert on it.

## Router names

Routers can be shown by hostname instead of IP everywhere: event table,
router filter, details panel, CSV export. The free-text search also matches
router names (search `ams-` to see all Amsterdam branches).

- **One at a time:** *Routers* tab → ✎ next to a router → type name → Enter.
- **All at once:** *Routers* → **Import names (CSV)** — paste or choose a file
  with one `IP,hostname` per line (comma, semicolon, tab or space; `hostname,IP`
  also works; header lines are skipped). **Export names** downloads the list.
- **Automatic:** start with `--rdns` to name routers from reverse DNS (PTR)
  when no name was set. Manual/imported names always win.

Names are stored in ClickHouse (`routers` table) and survive restarts.

Tip: the HSL source IP is the router interface you configured as HSL source
(not necessarily the system IP). Export the list of routers with their
interface IPs from SD-WAN Manager to build the CSV.

API: `GET /api/routers`, `PUT /api/routers/{ip}` with `{"name": "..."}`
(empty name removes it), `POST /api/routers/import` (CSV body), `GET /api/routers.csv`.

## Export streams

Templates and sequence numbers are tracked per export stream (router IP +
source port + NetFlow version + domain), as the NetFlow/IPFIX standards
specify. A router that sends HSL (NetFlow v9) and flow visibility (IPFIX) to
the same collector is decoded correctly and doesn't report false losses.

## Tested performance

Measured in a 2-vCPU VM running ClickHouse, the collector and the traffic
simulator together, 100 simulated routers sending ZBFW-style records:

| Load | Result |
|---|---|
| 10,000 records/s | 0 lost, 0 dropped |
| 20,000 records/s | 0 lost, 0 dropped |
| 30,000 records/s | 0 lost, 0 dropped |
| ClickHouse paused, then resumed | 0 lost (rows buffered and inserted after) |
| Dashboard / filtered search on 2.4 M rows | 10–300 ms |

On a dedicated server with more cores, decoding capacity grows with
`--workers` (~40k records/s per core).

## Sizing for 100 routers

Records per second depend mostly on whether **session logging (audit trail)** is on:

| Logging | Typical total for 100 branches | Disk per day (≈40–60 B/row in ClickHouse) |
|---|---|---|
| Drops only | 100 – 2,000 rec/s | 0.5 – 10 GB |
| Sessions on busy branches | 10,000 – 40,000 rec/s | 35 – 200 GB |

Recommended hosts:

| Load | Collector + ClickHouse |
|---|---|
| up to ~10k rec/s | 4 vCPU, 16 GB RAM, SSD sized for retention |
| 10k – 40k rec/s | 8+ vCPU, 32 GB RAM, NVMe; or ClickHouse on its own server |
| above that | several collectors (routers split by port or IP) writing to the same ClickHouse |

Disk ≈ records/s × 86,400 × 50 bytes × retention days. Example: 20k rec/s × 7 days ≈ 600 GB.

## Install (Linux, production)

```bash
sudo cp sysctl-hsl.conf /etc/sysctl.d/90-hsl.conf && sudo sysctl --system
cp .env.example .env && chmod 600 .env
# edit .env: two random passwords (openssl rand -base64 24)
docker compose up -d --build
```

GUI: `https://<server>:8443` (`http://<server>:8080` redirects there). Then
install your CA-signed certificate in the Certificate tab. The collector uses
host networking so the routers' source IPs are kept and UDP
doesn't pass through Docker NAT.

What the compose file sets up:

- ClickHouse reachable only from the host (127.0.0.1:8123); its data on a volume.
- On first start, `deploy/clickhouse-init.sh` creates the account `hsl_app`
  with rights on database `hsl` only. The collector uses that account, not the
  ClickHouse admin. (The script runs only on an empty data volume; to change
  passwords later use `ALTER USER` in ClickHouse.)
- The collector runs as an unprivileged user, with a read-only filesystem, no
  Linux capabilities and a health check.
- It refuses to start without the passwords in `.env`.

**Upgrading from 2.2 with Docker:** the collector no longer runs as root. Give
its state volume to the new user once:
`docker run --rm -v hsl-collector_hsl-state:/state alpine chown -R 10001:10001 /state`.
An existing ClickHouse volume keeps its old accounts; either keep using them
(`HSL_CH_USER`/`HSL_CH_PASSWORD`) or create `hsl_app` with the SQL in
`deploy/clickhouse-init.sh`.

Without Docker: install ClickHouse from clickhouse.com, create the `hsl_app`
account with the SQL in `deploy/clickhouse-init.sh`, then

```bash
sudo useradd --system --shell /usr/sbin/nologin hsl
sudo mkdir -p /opt/hsl-collector /etc/hsl-collector   # copy the project to /opt/hsl-collector
cd /opt/hsl-collector && sudo python3 -m venv venv && sudo venv/bin/pip install -r requirements.txt
sudo cp deploy/hsl-collector.env.example /etc/hsl-collector/hsl-collector.env
sudo chmod 600 /etc/hsl-collector/hsl-collector.env      # fill in password and HSL_ALLOW
sudo cp hsl-collector.service /etc/systemd/system/ && sudo systemctl enable --now hsl-collector
```

The systemd unit runs the collector sandboxed (no capabilities, read-only
system, private /tmp, restricted system calls).

## Run on a Mac (testing)

```bash
# ClickHouse in Docker Desktop
docker run -d --name clickhouse -p 127.0.0.1:8123:8123 --ulimit nofile=262144:262144 \
  -e CLICKHOUSE_PASSWORD=hsl clickhouse/clickhouse-server:25.8

# collector natively (in the unzipped folder)
python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt
python3 collector.py --ch-password hsl
```

Open `https://localhost:8443` (or `http://localhost:8080`, which redirects).
The browser warns about the self-signed certificate the first time; continue
to the site (Chrome: *Advanced → Proceed*).

Run the collector itself natively, not in Docker Desktop: Docker Desktop
rewrites the source IP of incoming UDP, so all routers would look like one.
`-p 127.0.0.1:8123:8123` keeps ClickHouse reachable from your Mac only.

## Options (flag / environment variable)

| Flag | Env | Default |
|---|---|---|
| `--flow-port` | `HSL_FLOW_PORT` | 2055 |
| `--syslog-port` | `HSL_SYSLOG_PORT` | 5514 (`0` = off) |
| `--workers` | `HSL_WORKERS` | CPU cores − 1, max 8 |
| `--ch-url` / `--ch-user` / `--ch-password` / `--ch-database` | `HSL_CH_*` | `http://127.0.0.1:8123` / `default` / – / `hsl` |
| `--retention-days` | `HSL_RETENTION_DAYS` | 7 (`0` = keep all) |
| `--web-host` / `--web-port` | `HSL_WEB_HOST` / `HSL_WEB_PORT` | 0.0.0.0 / 8443 (HTTPS) |
| `--http-port` | `HSL_HTTP_PORT` | 8080 (redirect to HTTPS; `0` = off) |
| `--tls-hostnames` | `HSL_TLS_HOSTNAMES` | – (extra names for the first self-signed certificate) |
| `--no-tls` | `HSL_TLS=off` | off (HTTPS on; disable only behind a TLS reverse proxy) |
| `--public-health` / `--no-public-health` | `HSL_PUBLIC_HEALTH` | on (`/api/health` without login) |
| `--reset-admin` | – | reset `admin` to password `admin` and exit |
| `--state-dir` | `HSL_STATE_DIR` | `./state` |
| `--rcvbuf` | `HSL_RCVBUF` | 32 MB |
| `--batch-rows` / `--flush-interval` | `HSL_BATCH_ROWS` / `HSL_FLUSH_INTERVAL` | 50,000 / 1 s |
| `--max-buffer-mb` | `HSL_MAX_BUFFER_MB` | 256 MB per decoder |
| `--min-free-pct` | `HSL_MIN_FREE_PCT` | 15 (delete oldest days below this) |
| `--warn-free-pct` | `HSL_WARN_FREE_PCT` | 25 (warning below this) |
| `--guard-interval` | `HSL_GUARD_INTERVAL` | 60 s |
| `--rdns` | `HSL_RDNS=1` | off (name routers from reverse DNS) |
| `--allow` | `HSL_ALLOW` | – (fixed access-list entries that lock enforcement on; normally use the Access list tab) |
| `--max-exporters` / `--max-templates` | `HSL_MAX_EXPORTERS` / `HSL_MAX_TEMPLATES` | 2000 routers per decoder / 256 templates per router |
| `--tls-cert` / `--tls-key` | `HSL_TLS_CERT` / `HSL_TLS_KEY` | – (certificate managed in the GUI) |
| `--trusted-proxies` | `HSL_TRUSTED_PROXIES` | – (ignore X-Forwarded-For) |
| `--allowed-hosts` | `HSL_ALLOWED_HOSTS` | – (any host name) |

Pass passwords through environment variables (`HSL_CH_PASSWORD`, an env file),
not on the command line, where other users of the host can see them.

## Router configuration

**SD-WAN Manager, policy-based:** *Configuration → Security → (security policy)
→ Additional Policy Settings → High Speed Logging*: VPN in which the collector
is reachable, Server IP = collector, Port = 2055 (17.16+: source interface).

**Configuration / Policy Groups:** in the NGFW / security logging settings add a
High Speed Logging server with the collector IP and port 2055.

Session (create/delete) records need audit-trail logging on the inspect rules;
without it mostly drops are exported. Check on a router:

```
show running-config | section parameter-map type inspect-global
show flow exporter statistics
```

## Load testing

```bash
python3 tools/hsl_simulator.py --routers 100 --rate 10000            # NetFlow v9
python3 tools/hsl_simulator.py --routers 100 --rate 10000 --ipfix    # IPFIX
```

`--routers` sends from 127.0.1.1 … 127.0.1.N (works on Linux; on macOS first
add aliases with `sudo ifconfig lo0 alias 127.0.1.X`).

## API

`/api/events`, `/api/stats`, `/api/exporters`, `/api/health`, `/api/templates`,
`/api/export.csv` — interactive docs at `/api/docs`. `/api/health` is suitable
for monitoring (database status, drops, buffered rows, process liveness).

## Security tests

```bash
pip install pytest bandit pip-audit
python3 -m pytest -q tests        # fuzzing + crafted packets + auth rules
bandit -r collector.py hslc       # static analysis
pip-audit -r requirements.txt     # known vulnerabilities in dependencies
```

Findings and decisions are documented in [SECURITY.md](SECURITY.md).

## Files

```
collector.py            entry point: supervisor + web API
hslc/decoder.py         NetFlow v9 / IPFIX decoder, loss tracking, row builder
hslc/pipeline.py        receiver and decoder processes, ClickHouse writer
hslc/clickhouse.py      ClickHouse HTTP client and schema
hslc/maintenance.py     disk guard, router names
hslc/auth.py            users, sessions, login throttling
hslc/acl.py             access list of authorized routers
hslc/tls.py             HTTPS certificates: self-signed, CSR, import, validation
static/index.html       web GUI
tools/hsl_simulator.py  multi-router HSL load generator
tools/healthcheck.py    health probe for Docker/systemd
tests/                  security regression tests
deploy/                 ClickHouse account script, systemd env file example
SECURITY.md             security assessment and hardening notes
docker-compose.yml, .env.example, Dockerfile, hsl-collector.service, sysctl-hsl.conf
```
