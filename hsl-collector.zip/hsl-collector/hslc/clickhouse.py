"""Minimal ClickHouse HTTP client (stdlib only) and the collector schema."""
from __future__ import annotations

import gzip
import json
import re
import urllib.error
import urllib.parse
import urllib.request


class ClickHouseError(Exception):
    def __init__(self, msg, code: int | None = None):
        super().__init__(msg)
        self.code = code            # ClickHouse error code, None = not reachable


# ClickHouse error codes caused by the data in an INSERT (not by the server state)
DATA_ERRORS = {6, 26, 27, 32, 38, 41, 53, 69, 70, 72, 117, 128, 131, 144, 190, 691}
_CODE_RE = re.compile(r"Code: (\d+)")
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,62}$")


class ClickHouse:
    def __init__(self, url: str, user: str = "default", password: str = "",  # nosec B107 - empty default, real password comes from config
                 database: str = "hsl", timeout: float = 60):
        if urllib.parse.urlsplit(url).scheme not in ("http", "https"):
            raise ValueError("ClickHouse URL must start with http:// or https://")
        if not _IDENT_RE.match(database):
            raise ValueError("ClickHouse database name: letters, digits and _ only")
        self.url = url.rstrip("/") + "/"
        self.user, self.password, self.database = user, password, database
        self.timeout = timeout
        self.default_settings: dict = {}   # e.g. readonly / time limits for web queries

    def _request(self, sql: str | None, body: bytes | None = None, params: dict | None = None,
                 settings: dict | None = None, gzip_body: bool = False, database: bool = True,
                 stream: bool = False):
        q = {}
        if sql is not None:
            q["query"] = sql
        if database:
            q["database"] = self.database
        for k, v in (params or {}).items():
            q[f"param_{k}"] = str(v)
        q.update({k: str(v) for k, v in {**self.default_settings, **(settings or {})}.items()})
        headers = {"X-ClickHouse-User": self.user, "X-ClickHouse-Key": self.password}
        if gzip_body and body is not None:
            body = gzip.compress(body, 3)
            headers["Content-Encoding"] = "gzip"
        req = urllib.request.Request(self.url + "?" + urllib.parse.urlencode(q),
                                     data=body if body is not None else b"",
                                     headers=headers, method="POST")
        try:
            resp = urllib.request.urlopen(req, timeout=self.timeout)  # nosec B310 - scheme validated to http/https in __init__
        except urllib.error.HTTPError as ex:
            text = ex.read().decode("utf-8", "replace")[:1000]
            m = _CODE_RE.search(text)
            raise ClickHouseError(text, int(m.group(1)) if m else ex.code) from None
        except (urllib.error.URLError, OSError) as ex:
            raise ClickHouseError(f"cannot reach ClickHouse at {self.url}: {ex}") from None
        if stream:
            return resp
        with resp:
            return resp.read()

    def command(self, sql: str, database: bool = True, settings: dict | None = None):
        self._request(None, sql.encode(), database=database, settings=settings)

    def query(self, sql: str, params: dict | None = None, settings: dict | None = None) -> list:
        raw = self._request(sql + " FORMAT JSON", params=params, settings=settings)
        return json.loads(raw)["data"]

    def stream(self, sql: str, params: dict | None = None):
        return self._request(sql, params=params, stream=True)

    def insert_json_lines(self, table: str, lines: bytes, skip_bad_rows: bool = False):
        settings = {"date_time_input_format": "best_effort", "input_format_skip_unknown_fields": 1}
        if skip_bad_rows:
            settings.update(input_format_allow_errors_num=1_000_000,
                            input_format_allow_errors_ratio=1)
        self._request(f"INSERT INTO {table} FORMAT JSONEachRow", lines, gzip_body=True,
                      settings=settings)


EVENT_COLUMNS = """
  id UInt64,
  ts DateTime64(3, 'UTC') CODEC(Delta, ZSTD(1)),
  rx DateTime64(3, 'UTC') CODEC(Delta, ZSTD(1)),
  exporter LowCardinality(String),
  kind LowCardinality(String),
  event LowCardinality(String),
  proto UInt8,
  src_ip String CODEC(ZSTD(1)),
  src_port UInt16,
  dst_ip String CODEC(ZSTD(1)),
  dst_port UInt16,
  bytes UInt64 CODEC(T64, ZSTD(1)),
  packets UInt64 CODEC(T64, ZSTD(1)),
  in_if UInt32,
  out_if UInt32,
  in_if_name LowCardinality(String),
  out_if_name LowCardinality(String),
  class_name LowCardinality(String),
  vrf UInt32,
  xlate_src_ip String CODEC(ZSTD(1)),
  xlate_src_port UInt16,
  xlate_dst_ip String CODEC(ZSTD(1)),
  xlate_dst_port UInt16,
  ext_event UInt16,
  severity Int8,
  message String CODEC(ZSTD(3)),
  extra String CODEC(ZSTD(3)),
  INDEX ix_src src_ip TYPE bloom_filter(0.01) GRANULARITY 4,
  INDEX ix_dst dst_ip TYPE bloom_filter(0.01) GRANULARITY 4,
  INDEX ix_ports dst_port TYPE set(256) GRANULARITY 4
"""


def ensure_schema(ch: ClickHouse, retention_days: float):
    db = ch.database
    ch.command(f"CREATE DATABASE IF NOT EXISTS {db}", database=False)
    stmts = [
        f"""CREATE TABLE IF NOT EXISTS {db}.events ({EVENT_COLUMNS})
            ENGINE = MergeTree PARTITION BY toYYYYMMDD(ts) ORDER BY (ts, exporter)""",
        # per-minute rollups so the dashboard stays fast with billions of rows
        f"""CREATE TABLE IF NOT EXISTS {db}.stats_1m (
              minute DateTime('UTC'), exporter LowCardinality(String),
              event LowCardinality(String), n UInt64, bytes UInt64)
            ENGINE = SummingMergeTree ORDER BY (minute, exporter, event)""",
        """CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.stats_1m_mv TO {db}.stats_1m AS
            SELECT toStartOfMinute(ts) AS minute, exporter, event, count() AS n,
                   sum(bytes) AS bytes FROM {db}.events GROUP BY minute, exporter, event""".replace("{db}", db),  # nosec B608 - db is a validated identifier
        f"""CREATE TABLE IF NOT EXISTS {db}.talkers_1m (
              minute DateTime('UTC'), dir Enum8('src' = 1, 'dst' = 2), denied UInt8,
              ip String, n UInt64)
            ENGINE = SummingMergeTree ORDER BY (minute, dir, denied, ip)""",
        """CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.talkers_src_mv TO {db}.talkers_1m AS
            SELECT toStartOfMinute(ts) AS minute, 'src' AS dir, event = 'denied' AS denied,
                   src_ip AS ip, count() AS n FROM {db}.events WHERE src_ip != ''
            GROUP BY minute, denied, ip""".replace("{db}", db),  # nosec B608 - db is a validated identifier
        """CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.talkers_dst_mv TO {db}.talkers_1m AS
            SELECT toStartOfMinute(ts) AS minute, 'dst' AS dir, event = 'denied' AS denied,
                   dst_ip AS ip, count() AS n FROM {db}.events WHERE dst_ip != ''
            GROUP BY minute, denied, ip""".replace("{db}", db),  # nosec B608 - db is a validated identifier
        f"""CREATE TABLE IF NOT EXISTS {db}.ports_1m (
              minute DateTime('UTC'), proto UInt8, port UInt16, n UInt64)
            ENGINE = SummingMergeTree ORDER BY (minute, proto, port)""",
        """CREATE MATERIALIZED VIEW IF NOT EXISTS {db}.ports_1m_mv TO {db}.ports_1m AS
            SELECT toStartOfMinute(ts) AS minute, proto, dst_port AS port, count() AS n
            FROM {db}.events WHERE dst_port != 0 GROUP BY minute, proto, port""".replace("{db}", db),  # nosec B608 - db is a validated identifier
        # router names (manual / imported / reverse DNS); latest row per router wins
        f"""CREATE TABLE IF NOT EXISTS {db}.routers (
              exporter String, name String, source LowCardinality(String),
              updated DateTime64(3, 'UTC'))
            ENGINE = ReplacingMergeTree(updated) ORDER BY exporter""",
    ]
    for s in stmts:
        ch.command(s)
    # expired days are removed as whole parts (cheap) instead of rewriting rows,
    # and checked hourly instead of every 4 h
    ch.command(f"ALTER TABLE {db}.events MODIFY SETTING ttl_only_drop_parts = 1, "
               "merge_with_ttl_timeout = 3600")
    # retention (TTL) - re-applied on every start so a config change takes effect.
    # The disk guard also drops whole days older than the retention immediately.
    no_mat = {"materialize_ttl_after_modify": 0}
    if retention_days and retention_days > 0:
        secs = int(retention_days * 86400)
        ch.command(f"ALTER TABLE {db}.events MODIFY TTL toDateTime(ts) + INTERVAL {secs} SECOND",
                   settings=no_mat)
        for t in ("stats_1m", "talkers_1m", "ports_1m"):
            ch.command(f"ALTER TABLE {db}.{t} MODIFY TTL minute + INTERVAL {secs} SECOND",
                       settings=no_mat)
    else:
        for t in ("events", "stats_1m", "talkers_1m", "ports_1m"):
            try:
                ch.command(f"ALTER TABLE {db}.{t} REMOVE TTL")
            except ClickHouseError:
                pass  # no TTL set
