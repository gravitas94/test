"""
Disk guard and router names (both run in the main collector process).

DiskGuard, every `interval` seconds:
  * enforces retention immediately by dropping whole days older than the
    retention period (TTL is only the backup),
  * if free space on ClickHouse's disk falls below `min_free_pct`, drops the
    oldest day (never today), one day per check, until there is room again,
  * reports free space, growth per day, days until full and whether the disk is
    big enough for the configured retention.

RouterNames: router IP -> hostname, stored in ClickHouse table `routers`.
Sources: manual (GUI), import (CSV), dns (optional reverse lookup).
"""
from __future__ import annotations

import ipaddress
import re
import logging
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from .clickhouse import ClickHouse, ClickHouseError
from .decoder import ch_time

log = logging.getLogger("hsl-collector")
DEFAULT_ROW_BYTES = 50          # estimate until there is enough data to measure


class DiskGuard:
    def __init__(self, ch: ClickHouse, cfg: dict):
        self.ch = ch
        self.db = ch.database
        self.min_free = cfg["min_free_pct"]
        self.warn_free = cfg["warn_free_pct"]
        self.retention = cfg["retention_days"]
        self.interval = cfg["guard_interval"]
        self.status: dict = {"checked": 0}
        self.actions: list = []
        self.lock = threading.Lock()

    def start(self):
        threading.Thread(target=self._loop, name="disk-guard", daemon=True).start()

    def _loop(self):
        while True:
            try:
                self.check()
            except ClickHouseError as ex:
                with self.lock:
                    self.status["error"] = str(ex)[:300]
            except Exception:                       # never let the guard thread die
                log.exception("disk guard failed")
            time.sleep(self.interval)

    def _action(self, msg: str, level=logging.WARNING):
        log.log(level, "disk guard: %s", msg)
        with self.lock:
            self.actions.append({"ts": time.time(), "message": msg})
            self.actions = self.actions[-30:]

    def _partitions(self) -> list:
        return self.ch.query(
            "SELECT partition_id AS partition, sum(bytes_on_disk) AS bytes, sum(rows) AS rows FROM system.parts "
            "WHERE active AND database = {db:String} AND table = 'events' "
            "GROUP BY partition_id ORDER BY partition_id", {"db": self.db})

    def _drop(self, partition: str, reason: str, nbytes: int):
        self.ch.command(f"ALTER TABLE {self.db}.events DROP PARTITION ID '{int(partition)}'")
        self._action(f"deleted day {partition[:4]}-{partition[4:6]}-{partition[6:]} "
                     f"({nbytes / 1e9:.2f} GB) - {reason}")

    def check(self):
        a = {"db": self.db}
        disk_name = self.ch.query(
            "SELECT disk_name FROM system.parts WHERE active AND database = {db:String} "
            "AND table = 'events' GROUP BY disk_name ORDER BY sum(bytes_on_disk) DESC LIMIT 1", a)
        disk_name = disk_name[0]["disk_name"] if disk_name else "default"
        d = self.ch.query("SELECT name, path, toUInt64(free_space) AS free, "
                          "toUInt64(total_space) AS total, toUInt64(keep_free_space) AS keep "
                          "FROM system.disks WHERE name = {d:String}", {"d": disk_name})[0]
        # space of dropped/merged parts that ClickHouse is about to delete counts as free
        pending = self.ch.query(
            "SELECT toUInt64(sum(bytes_on_disk)) AS b FROM system.parts WHERE NOT active "
            "AND database = {db:String} AND table = 'events'", a)[0]["b"] or 0
        parts = self._partitions()
        rows = sum(int(p["rows"]) for p in parts)
        ev_bytes = sum(int(p["bytes"]) for p in parts)
        total = int(d["total"]) or 1
        free = int(d["free"]) + int(pending)
        free_pct = free / total * 100

        # growth: last hour of ingest x measured bytes per row
        last_hour = self.ch.query("SELECT sum(n) AS n FROM stats_1m "
                                  "WHERE minute >= now() - INTERVAL 1 HOUR")[0]["n"] or 0
        row_bytes = ev_bytes / rows if rows > 100_000 else DEFAULT_ROW_BYTES
        growth = float(last_hour) * 24 * row_bytes          # bytes per day
        usable = free - total * self.min_free / 100
        days_left = max(0.0, usable / growth) if growth > 0 else None
        used = total - free
        other_bytes = max(0, used - ev_bytes)
        needed = growth * self.retention if self.retention else None
        fits = needed is None or needed <= ev_bytes + usable

        # 1) retention by whole days - immediate, also after lowering --retention-days
        today = time.strftime("%Y%m%d", time.gmtime())
        if self.retention and self.retention > 0:
            cutoff = time.strftime("%Y%m%d", time.gmtime(time.time() - self.retention * 86400))
            for p in parts:
                if p["partition"] < cutoff and p["partition"] != today:
                    self._drop(p["partition"], f"older than retention ({self.retention:g} days)",
                               int(p["bytes"]))
                    parts = [x for x in parts if x["partition"] != p["partition"]]
        # 2) free-space guard: oldest day first, one day per check
        if free_pct < self.min_free:
            old = [p for p in parts if p["partition"] != today]
            if old:
                self._drop(old[0]["partition"],
                           f"disk {free_pct:.1f}% free, below {self.min_free:g}% limit",
                           int(old[0]["bytes"]))
            elif self.status.get("only_today_logged") != today:
                self._action(f"disk {free_pct:.1f}% free but only today's data is left - "
                             "add disk space or reduce logging", logging.ERROR)
                self.status["only_today_logged"] = today

        with self.lock:
            self.status = {
                "checked": time.time(), "disk": d["name"], "path": d["path"],
                "total_bytes": total, "free_bytes": free, "free_pct": round(free_pct, 1),
                "events_bytes": ev_bytes, "rows": rows,
                "oldest_day": parts[0]["partition"] if parts else None,
                "days_stored": len(parts), "bytes_per_row": round(row_bytes, 1),
                "growth_bytes_per_day": int(growth),
                "days_until_full": round(days_left, 1) if days_left is not None else None,
                "retention_days": self.retention,
                "retention_needs_bytes": int(needed) if needed is not None else None,
                "retention_fits": fits, "min_free_pct": self.min_free,
                "warn_free_pct": self.warn_free, "error": None,
                "other_bytes": other_bytes,
                "only_today_logged": self.status.get("only_today_logged"),
            }

    def snapshot(self) -> dict:
        with self.lock:
            return {**self.status, "actions": list(self.actions)}


class RouterNames:
    def __init__(self, ch: ClickHouse, rdns: bool):
        self.ch = ch
        self.rdns = rdns
        self.names: dict = {}        # ip -> (name, source)
        self.tried: set = set()
        self.lock = threading.Lock()
        self.pool = ThreadPoolExecutor(4, thread_name_prefix="rdns") if rdns else None

    def load(self):
        rows = self.ch.query("SELECT exporter, argMax(name, updated) AS name, "
                             "argMax(source, updated) AS source FROM routers GROUP BY exporter")
        with self.lock:
            self.names = {r["exporter"]: (r["name"], r["source"]) for r in rows if r["name"]}

    def get(self, ip):
        v = self.names.get(ip)
        return v[0] if v else None

    def all(self) -> dict:
        with self.lock:
            return {ip: {"name": n, "source": s} for ip, (n, s) in self.names.items()}

    def _write(self, entries: list):
        now = ch_time(time.time())
        body = "\n".join(
            '{"exporter":%s,"name":%s,"source":%s,"updated":"%s"}' % (
                _js(ip), _js(name), _js(src), now) for ip, name, src in entries)
        self.ch.insert_json_lines("routers", body.encode())
        with self.lock:
            for ip, name, src in entries:
                if name:
                    self.names[ip] = (name, src)
                else:
                    self.names.pop(ip, None)

    def set(self, ip: str, name: str, source="manual"):
        ip = str(ipaddress.ip_address(ip.strip()))
        name = clean_name(name)
        self._write([(ip, name, source if name else "removed")])
        return ip, name

    def import_csv(self, text: str) -> dict:
        """Lines of 'ip,name' or 'name,ip'; separators , ; tab or spaces; header ok."""
        entries, errors = [], []
        for i, line in enumerate(text.splitlines(), 1):
            line = line.strip().lstrip("\ufeff")
            if not line or line.startswith("#"):
                continue
            row = [c.strip().strip('"').strip("'").strip() for c in re.split(r"[,;\t]", line)]
            row = [c for c in row if c]
            if len(row) < 2:
                row = line.split()
            if len(row) < 2:
                errors.append(f"line {i}: needs IP and name")
                continue
            pair = None
            for ip, name in ((row[0], row[1]), (row[1], row[0])):
                try:
                    pair = (str(ipaddress.ip_address(ip)), name)
                    break
                except ValueError:
                    continue
            if pair is None:
                if i > 1:
                    errors.append(f"line {i}: no IP address")
                continue                               # header line
            name = clean_name(pair[1])
            if name:
                entries.append((pair[0], name, "import"))
        if entries:
            self._write(entries)
        return {"imported": len(entries), "errors": errors[:20]}

    def match(self, q: str) -> list:
        q = q.lower()
        with self.lock:
            return [ip for ip, (n, _) in self.names.items() if q in n.lower()]

    def resolve_new(self, ips):
        """Reverse-DNS routers that have no name yet (only with --rdns)."""
        if not self.pool:
            return
        for ip in ips:
            if ip in self.tried or ip in self.names:
                continue
            self.tried.add(ip)
            self.pool.submit(self._resolve, ip)

    def _resolve(self, ip):
        try:
            host = socket.gethostbyaddr(ip)[0]
        except (OSError, UnicodeError):
            return
        host = clean_name(host)
        if host and host != ip and ip not in self.names:
            try:
                self._write([(ip, host, "dns")])
            except ClickHouseError as ex:
                log.warning("cannot store DNS name for %s: %s", ip, ex)


_CTRL = re.compile(r"[\x00-\x1f\x7f]+")


def clean_name(name: str) -> str:
    """Router names come from users and DNS: no control characters, max 128 chars."""
    return _CTRL.sub(" ", str(name)).strip()[:128]


def _js(v: str) -> str:
    import json
    return json.dumps(v)
