"""
NetFlow v9 / IPFIX decoder for Cisco IOS XE High Speed Logging (HSL).

* Per-exporter template cache; fixed-length templates are compiled into a
  struct.Struct so a whole data set is decoded with iter_unpack (fast path).
* Option templates teach id -> name mappings (interfaces, class-maps, VRFs,
  zone-pairs ...) which are added to the records as <field>_name.
* Sequence numbers are tracked per exporter/observation domain to detect
  export loss (v9 counts packets, IPFIX counts data records).
* Template state can be exported/imported so a restart does not wait for the
  routers' next template refresh.
"""
from __future__ import annotations

import ipaddress
import json
import re
import socket
import struct
import time

FIELD_NAMES = {
    1: "bytes", 2: "packets", 4: "protocol", 5: "tos", 6: "tcp_flags",
    7: "src_port", 8: "src_ip", 10: "input_if", 11: "dst_port", 12: "dst_ip",
    14: "output_if", 15: "next_hop", 21: "last_switched", 22: "first_switched",
    27: "src_ipv6", 28: "dst_ipv6", 32: "icmp_type_code", 51: "class_id",
    54: "frag_id", 56: "src_mac", 57: "dst_mac", 61: "direction",
    80: "post_dst_mac", 81: "post_src_mac", 82: "interface_name",
    83: "interface_desc", 94: "app_description", 95: "app_id", 96: "app_name",
    100: "class_name", 130: "exporter_ipv4", 136: "flow_end_reason",
    144: "exporting_process_id", 148: "flow_id", 149: "observation_domain_id",
    150: "flow_start_s", 151: "flow_end_s", 152: "flow_start_ms", 153: "flow_end_ms",
    176: "icmp_type", 177: "icmp_code", 178: "icmpv6_type", 179: "icmpv6_code",
    225: "xlate_src_ip", 226: "xlate_dst_ip", 227: "xlate_src_port",
    228: "xlate_dst_port", 230: "nat_event", 231: "initiator_bytes",
    232: "responder_bytes", 233: "fw_event", 234: "ingress_vrf_id",
    235: "egress_vrf_id", 236: "vrf_name", 281: "xlate_src_ipv6",
    282: "xlate_dst_ipv6", 298: "initiator_packets", 299: "responder_packets",
    323: "event_time_ms", 33002: "fw_ext_event",
}
IP_FIELDS = {8, 12, 15, 18, 27, 28, 62, 63, 130, 225, 226, 281, 282}
MAC_FIELDS = {56, 57, 80, 81}
STR_FIELDS = {82, 83, 94, 96, 100, 236}
V9_SCOPES = {1: "scope_system", 2: "scope_interface", 3: "scope_linecard",
             4: "scope_cache", 5: "scope_template"}
KEY_ALIAS = {14: 10, 235: 234}          # output_if -> input_if, egress vrf -> ingress vrf
NON_KEY = {130, 131, 143, 144, 149}     # option scope fields that are not lookup keys
CISCO_PEN = 9

FW_EVENTS = {0: "ignore", 1: "created", 2: "deleted", 3: "denied", 4: "alert", 5: "update"}
NAT_EVENTS = {1: "nat-create", 2: "nat-delete", 3: "nat-exhausted"}
PROTOS = {1: "ICMP", 2: "IGMP", 6: "TCP", 17: "UDP", 47: "GRE", 50: "ESP",
          51: "AH", 58: "ICMPv6", 89: "OSPF", 112: "VRRP", 132: "SCTP"}
PROTO_BY_NAME = {v.lower(): k for k, v in PROTOS.items()}


def _known(fid, ent):
    """Canonical v9 field id for a (field, enterprise) pair, or None."""
    if ent == 0 and fid in FIELD_NAMES:
        return fid
    if ent == CISCO_PEN and (fid | 0x8000) in FIELD_NAMES:
        return fid | 0x8000
    return None


def field_name(fid: int, ent: int) -> str:
    if ent == -1:
        return V9_SCOPES.get(fid, f"scope_{fid}")
    k = _known(fid, ent)
    if k is not None:
        return FIELD_NAMES[k]
    return f"e{ent}_{fid}" if ent else f"field_{fid}"


def _str(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("utf-8", "replace").strip()


def _auto(raw: bytes):
    n = len(raw)
    if n >= 8:
        s = raw.rstrip(b"\0")
        if s and all(32 <= b < 127 for b in s) and any(chr(b).isalpha() for b in s):
            return s.decode("ascii").strip(), "str"
    if n <= 8:
        return int.from_bytes(raw, "big"), "int"
    return raw.hex(), "hex"


def decode_value(fid: int, ent: int, raw: bytes):
    """Return (value, kind) where kind is int|ip|mac|str|hex."""
    n = len(raw)
    k = _known(fid, ent) if ent != -1 else None
    if k is not None:
        if k in IP_FIELDS and n in (4, 16):
            return str(ipaddress.ip_address(raw)), "ip"
        if k in MAC_FIELDS and n == 6:
            return ":".join(f"{b:02x}" for b in raw), "mac"
        if k in STR_FIELDS:
            return _str(raw), "str"
        if n <= 8:
            return int.from_bytes(raw, "big"), "int"
    return _auto(raw)


# ---------------------------------------------------------------- fast path
_INT_FMT = {1: "B", 2: "H", 4: "I", 8: "Q"}


def _ip4(b):
    return socket.inet_ntoa(b)


def _ip6(b):
    return socket.inet_ntop(socket.AF_INET6, b)


def _mac(b):
    return ":".join(f"{x:02x}" for x in b)


def _bigint(b):
    return int.from_bytes(b, "big")


def _auto_val(b):
    return _auto(b)[0]


def compile_template(fields):
    """Build (Struct, columns) for a fixed-length template, or None."""
    if any(fl == 65535 for _, fl, _ in fields) or not fields:
        return None
    fmt, cols, seen = ["!"], [], set()
    for fid, fl, ent in fields:
        k = _known(fid, ent) if ent != -1 else None
        name = field_name(fid, ent)
        base, i = name, 2
        while name in seen:
            name = f"{base}_{i}"
            i += 1
        seen.add(name)
        conv, keyfid = None, 0
        if k is not None and k in IP_FIELDS and fl in (4, 16):
            fmt.append(f"{fl}s")
            conv = _ip4 if fl == 4 else _ip6
        elif k is not None and k in MAC_FIELDS and fl == 6:
            fmt.append("6s")
            conv = _mac
        elif k is not None and k in STR_FIELDS:
            fmt.append(f"{fl}s")
            conv = _str
        elif k is not None and fl <= 8:
            if fl in _INT_FMT:
                fmt.append(_INT_FMT[fl])
            else:
                fmt.append(f"{fl}s")
                conv = _bigint
            keyfid = KEY_ALIAS.get(k, k)
        elif fl in _INT_FMT and fl < 8:
            fmt.append(_INT_FMT[fl])          # unknown short field: integer
            keyfid = KEY_ALIAS.get(fid, fid) if ent == 0 else 0
        else:
            fmt.append(f"{fl}s")
            conv = _auto_val if fl >= 8 else _bigint
        cols.append((name, conv, keyfid))
    return struct.Struct("".join(fmt)), cols


# ---------------------------------------------------------------- decoder
# Resource limits. Anyone who can send UDP to the collector controls what the
# decoder stores (templates, names, per-stream state), so everything is capped.
DEFAULT_LIMITS = {
    "max_exporters": 2000,        # routers per decoder process
    "max_streams": 16,            # export streams (src port/version/domain) per router
    "max_templates": 256,         # templates per router (oldest replaced first)
    "max_fields": 256,            # fields per template (Cisco HSL uses ~20-40)
    "max_names": 20000,           # learned option names per router
}


class LimitError(ValueError):
    pass


class Decoder:
    def __init__(self, limits: dict | None = None):
        self.lim = {**DEFAULT_LIMITS, **(limits or {})}
        self.templates: dict = {}     # (exporter, src port, version, domain, tid) -> template
        self.by_exp: dict = {}        # exporter -> {template key: None}, insertion ordered
        self.streams: dict = {}       # exporter -> set of (port, version, domain)
        self.names: dict = {}         # exporter -> {(key_field, value): label}
        self.options_log: list = []
        self.exporters: dict = {}
        self.seq: dict = {}           # (exporter, src port, version, domain) -> sequence state
        self._port = 0                # source port of the packet being parsed
        self.dirty = False
        self.rejected_exporters = 0   # packets from new routers beyond max_exporters

    def _stat(self, ip: str):
        st = self.exporters.get(ip)
        if st is None:
            if len(self.exporters) >= self.lim["max_exporters"]:
                self.rejected_exporters += 1
                return None
            st = self.exporters[ip] = {
                "exporter": ip, "version": None, "packets": 0, "records": 0,
                "options_records": 0, "templates": 0, "no_template": 0,
                "errors": 0, "lost": 0, "lost_unit": None, "syslog": 0,
                "first_seen": time.time(), "last_seen": 0.0, "last_error": None,
            }
        return st

    def parse(self, data: bytes, exp: str, port: int = 0) -> list:
        """Templates and sequence numbers are scoped per export stream (router IP,
        source port, version, domain), so e.g. HSL (v9) and flow visibility (IPFIX)
        from the same router never mix."""
        self._port = port
        st = self._stat(exp)
        if st is None:
            return []
        st["packets"] += 1
        st["last_seen"] = time.time()
        try:
            if len(data) < 4:
                raise ValueError("short packet")
            ver = (data[0] << 8) | data[1]
            st["version"] = ver
            if ver == 9:
                recs = self._parse_v9(data, exp, st)
            elif ver == 10:
                recs = self._parse_ipfix(data, exp, st)
            else:
                raise ValueError(f"unsupported export version {ver}")
        except Exception as ex:  # malformed packet must never kill the worker
            st["errors"] += 1
            st["last_error"] = str(ex)[:200]
            return []
        st["records"] += len(recs)
        return recs

    # ---- sequence tracking -------------------------------------------------
    def _stream(self, key):
        """Register an export stream; refuse more than max_streams per router."""
        exp, rest = key[0], key[1:]
        ss = self.streams.setdefault(exp, set())
        if rest not in ss:
            if len(ss) >= self.lim["max_streams"]:
                raise LimitError("too many export streams from this router "
                                 f"(limit {self.lim['max_streams']})")
            ss.add(rest)

    def _track(self, st, key, seq, count, unit):
        st["lost_unit"] = unit
        last = self.seq.get(key)
        if last is None:
            self._stream(key)
        if last is not None:
            expected = (last[0] + last[1]) & 0xFFFFFFFF
            gap = (seq - expected) & 0xFFFFFFFF
            if 0 < gap < 0x7FFFFFFF and gap < 10_000_000:  # big/backwards jump = reboot
                st["lost"] += gap
        self.seq[key] = (seq, count)

    def _track_v9(self, st, key, seq, count):
        """RFC 3954 says the v9 sequence counts packets, but some exporters count
        records. Detect which one this exporter uses before counting losses."""
        info = self.seq.get(key)
        if info is None:
            self._stream(key)
            self.seq[key] = [seq, count, "packets", 0]
            st["lost_unit"] = "packets"
            return
        last, last_count, mode, hits = info
        delta = (seq - last) & 0xFFFFFFFF
        if mode == "packets" and last_count > 1 and delta == last_count:
            hits += 1
            if hits >= 3:
                mode, hits = "records", 0
        elif mode == "packets" and delta == 1:
            hits = 0
        step = 1 if mode == "packets" else last_count
        gap = (delta - step) & 0xFFFFFFFF
        if 0 < gap < 10_000_000 and not (mode == "packets" and delta == last_count and hits):
            st["lost"] += gap
        st["lost_unit"] = mode
        self.seq[key] = [seq, count, mode, hits]

    # ---- NetFlow v9 -------------------------------------------------------
    def _parse_v9(self, data, exp, st):
        if len(data) < 20:
            raise ValueError("short v9 header")
        _, count, _, _, seq, domain = struct.unpack_from("!HHIIII", data)
        self._track_v9(st, (exp, self._port, 9, domain), seq, count)
        off, out, n = 20, [], len(data)
        while off + 4 <= n:
            sid, slen = struct.unpack_from("!HH", data, off)
            if slen < 4 or off + slen > n:
                break
            if sid == 0:
                self._v9_templates(data[off + 4: off + slen], exp, domain, st)
            elif sid == 1:
                self._v9_option_templates(data[off + 4: off + slen], exp, domain, st)
            elif sid >= 256:
                self._data(data, off + 4, off + slen, exp, domain, sid, st, out, 9)
            off += slen
        return out

    def _v9_templates(self, body, exp, domain, st):
        p = 0
        while p + 4 <= len(body):
            tid, fc = struct.unpack_from("!HH", body, p)
            p += 4
            if tid < 256 or p + 4 * fc > len(body):
                break
            fields = []
            for _ in range(fc):
                ft, fl = struct.unpack_from("!HH", body, p)
                p += 4
                fields.append((ft, fl, 0))
            self._store_template(exp, domain, tid, fields, 0, False, 9, st)

    def _v9_option_templates(self, body, exp, domain, st):
        p = 0
        while p + 6 <= len(body):
            tid, scope_len, opt_len = struct.unpack_from("!HHH", body, p)
            p += 6
            if tid < 256 or p + scope_len + opt_len > len(body):
                break
            fields = []
            for i in range(scope_len // 4):
                ft, fl = struct.unpack_from("!HH", body, p + 4 * i)
                fields.append((ft, fl, -1))
            p += scope_len
            for i in range(opt_len // 4):
                ft, fl = struct.unpack_from("!HH", body, p + 4 * i)
                fields.append((ft, fl, 0))
            p += opt_len
            self._store_template(exp, domain, tid, fields, scope_len // 4, True, 9, st)

    # ---- IPFIX ------------------------------------------------------------
    def _parse_ipfix(self, data, exp, st):
        if len(data) < 16:
            raise ValueError("short IPFIX header")
        _, length, _, seq, domain = struct.unpack_from("!HHIII", data)
        end = min(length, len(data))
        off, out = 16, []
        data_records = 0
        while off + 4 <= end:
            sid, slen = struct.unpack_from("!HH", data, off)
            if slen < 4 or off + slen > end:
                break
            if sid in (2, 3):
                self._ipfix_templates(data[off + 4: off + slen], exp, domain, st, sid == 3)
            elif sid >= 256:
                data_records += self._data(data, off + 4, off + slen, exp, domain, sid, st, out, 10)
            off += slen
        self._track(st, (exp, self._port, 10, domain), seq, data_records, "records")
        return out

    def _ipfix_templates(self, body, exp, domain, st, options):
        p = 0
        while p + 4 <= len(body):
            tid, fc = struct.unpack_from("!HH", body, p)
            p += 4
            if tid < 256:
                break
            scope = 0
            if options and fc:
                if p + 2 > len(body):
                    return
                scope = struct.unpack_from("!H", body, p)[0]
                p += 2
            if fc == 0:  # template withdrawal
                key = (exp, self._port, 10, domain, tid)
                if self.templates.pop(key, None) is not None:
                    self.by_exp.get(exp, {}).pop(key, None)
                continue
            fields = []
            for _ in range(fc):
                if p + 4 > len(body):
                    return
                ie, fl = struct.unpack_from("!HH", body, p)
                p += 4
                ent = 0
                if ie & 0x8000:
                    if p + 4 > len(body):
                        return
                    ent = struct.unpack_from("!I", body, p)[0]
                    p += 4
                    ie &= 0x7FFF
                fields.append((ie, fl, ent))
            self._store_template(exp, domain, tid, fields, scope, options, 10, st)

    # ---- common -----------------------------------------------------------
    def _store_template(self, exp, domain, tid, fields, scope, options, ver, st, ts=None, port=None):
        port = self._port if port is None else port
        key = (exp, port, ver, domain, tid)
        if len(fields) > self.lim["max_fields"]:
            raise LimitError(f"template {tid} has {len(fields)} fields "
                             f"(limit {self.lim['max_fields']})")
        old = self.templates.get(key)
        if old is not None and old["fields"] == fields and old["options"] == options:
            old["updated"] = ts or time.time()      # refresh only
            return
        self.templates[key] = {
            "exporter": exp, "port": port, "domain": domain, "id": tid, "version": ver,
            "fields": fields, "scope": scope, "options": options,
            "updated": ts or time.time(),
            "plan": None if options else compile_template(fields),
        }
        owned = self.by_exp.setdefault(exp, {})
        owned.pop(key, None)
        owned[key] = None
        while len(owned) > self.lim["max_templates"]:      # replace the oldest
            oldest = next(iter(owned))
            del owned[oldest]
            self.templates.pop(oldest, None)
        st["templates"] = len(owned)
        self.dirty = True

    def _data(self, data, start, end, exp, domain, tid, st, out, ver) -> int:
        t = self.templates.get((exp, self._port, ver, domain, tid))
        if t is None:
            st["no_template"] += 1
            return 0
        plan = t["plan"]
        if plan is not None:                     # fast path: fixed-length records
            s, cols = plan
            cnt = (end - start) // s.size
            if cnt <= 0:
                return 0
            names = self.names.get(exp)
            for vals in s.iter_unpack(data[start:start + cnt * s.size]):
                rec = {}
                for (name, conv, keyfid), v in zip(cols, vals):
                    if conv is not None:
                        v = conv(v)
                    rec[name] = v
                    if keyfid and names:
                        label = names.get((keyfid, v))
                        if label is not None:
                            rec[name + "_name"] = label
                out.append(rec)
            return cnt
        return self._data_slow(data[start:end], exp, t, st, out)

    def _data_slow(self, body, exp, t, st, out) -> int:
        fields = t["fields"]
        minlen = sum(1 if fl == 65535 else fl for _, fl, _ in fields)
        if minlen == 0:
            return 0
        p, n, cnt = 0, len(body), 0
        while p + minlen <= n:
            items, ok = [], True
            for fid, fl, ent in fields:
                ln = fl
                if fl == 65535:  # IPFIX variable length
                    ln = body[p]
                    p += 1
                    if ln == 255:
                        if p + 2 > n:
                            ok = False
                            break
                        ln = struct.unpack_from("!H", body, p)[0]
                        p += 2
                if p + ln > n:
                    ok = False
                    break
                val, kind = decode_value(fid, ent, body[p:p + ln])
                p += ln
                items.append((fid, ent, val, kind))
            if not ok:
                break
            cnt += 1
            if t["options"]:
                st["options_records"] += 1
                self._learn(exp, t, items)
            else:
                out.append(self._record(exp, items))
        return cnt

    def _learn(self, exp, t, items):
        keys, strs = [], []
        for fid, ent, val, kind in items:
            if kind == "str":
                strs.append(val)
            elif kind == "int":
                if ent == -1:
                    if fid == 2:                       # v9 interface scope = ifIndex
                        keys.append((10, val))
                else:
                    k = _known(fid, ent)
                    if k is None and ent == 0:
                        k = fid
                    if k is not None and k not in NON_KEY:
                        keys.append((KEY_ALIAS.get(k, k), val))
        if keys and strs:
            m = self.names.setdefault(exp, {})
            room = self.lim["max_names"] - len(m)
            pairs = zip(keys, strs) if len(keys) == len(strs) else ((k, strs[0]) for k in keys)
            for key, label in pairs:
                if key not in m and room <= 0:
                    continue
                if key not in m:
                    room -= 1
                label = label[:256]
                if m.get(key) != label:
                    m[key] = label
                    self.dirty = True
        self.options_log.append({
            "ts": time.time(), "exporter": exp, "template": t["id"],
            "values": {field_name(f, e): v for f, e, v, _ in items},
        })
        if len(self.options_log) > 200:
            del self.options_log[:100]

    def _record(self, exp, items):
        rec, names = {}, self.names.get(exp)
        for fid, ent, val, kind in items:
            name = field_name(fid, ent)
            if name in rec:
                i = 2
                while f"{name}_{i}" in rec:
                    i += 1
                name = f"{name}_{i}"
            rec[name] = val
            if kind == "int" and names and ent != -1:
                k = _known(fid, ent) or fid
                label = names.get((KEY_ALIAS.get(k, k), val))
                if label is not None:
                    rec[name + "_name"] = label
        return rec

    # ---- state persistence & snapshots ----------------------------------
    def export_state(self) -> dict:
        return {
            "templates": [{k: v for k, v in t.items() if k != "plan"}
                          for t in self.templates.values()],
            "names": [[exp, kf, kv, label] for exp, m in self.names.items()
                      for (kf, kv), label in m.items()],
        }

    def import_state(self, state: dict, accept=lambda exp: True, max_age=7 * 86400):
        now = time.time()
        for t in state.get("templates", []):
            if not accept(t["exporter"]) or now - t.get("updated", 0) > max_age:
                continue
            st = self._stat(t["exporter"])
            if st is None:
                continue
            try:
                fields = [tuple(f) for f in t["fields"]]
                self._store_template(t["exporter"], t["domain"], t["id"], fields, t["scope"],
                                     t["options"], t["version"], st, ts=t.get("updated"),
                                     port=t.get("port", 0))
            except (LimitError, TypeError, ValueError):
                continue
        for exp, kf, kv, label in state.get("names", []):
            if accept(exp) and exp in self.exporters:
                m = self.names.setdefault(exp, {})
                if len(m) < self.lim["max_names"]:
                    m[(kf, kv)] = label
        self.dirty = False

    def templates_snapshot(self) -> dict:
        tpls = [{
            "exporter": t["exporter"], "port": t["port"], "domain": t["domain"], "id": t["id"],
            "version": t["version"], "options": t["options"], "scope": t["scope"],
            "updated": t["updated"], "fast": t["plan"] is not None,
            "fields": [{"id": f, "enterprise": max(e, 0), "length": l,
                        "name": field_name(f, e)} for f, l, e in t["fields"]],
        } for t in self.templates.values()]
        names = [{"exporter": exp, "field": field_name(kf, 0), "value": kv, "label": label}
                 for exp, m in self.names.items() for (kf, kv), label in m.items()]
        tpls.sort(key=lambda t: -t["updated"])
        return {"templates": tpls[:2000], "names": names[:5000],
                "templates_total": len(self.templates), "names_total": len(names)}


# ---------------------------------------------------------------- rows
_tcache = [None, ""]


def ch_time(t: float) -> str:
    """Seconds -> 'YYYY-MM-DD HH:MM:SS.mmm' (UTC) with a per-second cache."""
    s = int(t)
    if _tcache[0] != s:
        _tcache[0] = s
        _tcache[1] = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(s))
    return f"{_tcache[1]}.{int((t - s) * 1000):03d}"


_CONSUMED = ("src_ip", "src_ipv6", "dst_ip", "dst_ipv6", "src_port", "dst_port",
             "protocol", "fw_event", "bytes", "packets", "input_if", "output_if",
             "input_if_name", "output_if_name", "class_id_name", "class_name",
             "ingress_vrf_id", "xlate_src_ip", "xlate_src_port", "xlate_dst_ip",
             "xlate_dst_port", "fw_ext_event", "event_time_ms")


_IP_RE = re.compile(r"[0-9A-Fa-f:.]{2,45}")
U64_MAX = (1 << 64) - 1


def _u(v, bits: int) -> int:
    """Unsigned integer that fits the column, else 0. Network input is untrusted:
    a malformed template can turn any field into a string, a huge number or bytes."""
    if isinstance(v, int) and not isinstance(v, bool) and 0 <= v < (1 << bits):
        return v
    return 0


def _ip(v) -> str:
    return v if isinstance(v, str) and _IP_RE.fullmatch(v) else ""


def _s(v, n: int = 256) -> str:
    return v[:n] if isinstance(v, str) else ""


def _event(code, table, prefix):
    if isinstance(code, int) and not isinstance(code, bool):
        return table.get(code) or (f"{prefix}-{code}" if 0 <= code < 256 else f"{prefix}-other")
    return f"{prefix}-other"


def hsl_row(rec: dict, exp: str, rx: float) -> dict:
    """Decoded record -> ClickHouse row. Every column is forced to its type and
    range here, so a crafted packet can neither crash the decoder nor produce a
    row that ClickHouse rejects (which would block the whole insert batch)."""
    g = rec.get
    if "fw_event" in rec:
        event = _event(rec["fw_event"], FW_EVENTS, "fw")
    elif "nat_event" in rec:
        event = _event(rec["nat_event"], NAT_EVENTS, "nat")
    else:
        event = "flow"
    if "bytes" in rec:
        nbytes = _u(g("bytes"), 64)
    else:
        nbytes = min(U64_MAX, _u(g("initiator_bytes"), 64) + _u(g("responder_bytes"), 64))
    if "packets" in rec:
        npk = _u(g("packets"), 64)
    else:
        npk = min(U64_MAX, _u(g("initiator_packets"), 64) + _u(g("responder_packets"), 64))
    ts = rx
    t_ms = g("event_time_ms") or g("flow_end_ms")
    if isinstance(t_ms, int) and not isinstance(t_ms, bool) and abs(t_ms / 1000 - rx) < 172800:
        ts = t_ms / 1000
    extra = {k: v for k, v in rec.items() if k not in _CONSUMED}
    return {
        "ts": ch_time(ts), "rx": ch_time(rx), "exporter": exp, "kind": "hsl",
        "event": event, "proto": _u(g("protocol"), 8),
        "src_ip": _ip(g("src_ip")) or _ip(g("src_ipv6")), "src_port": _u(g("src_port"), 16),
        "dst_ip": _ip(g("dst_ip")) or _ip(g("dst_ipv6")), "dst_port": _u(g("dst_port"), 16),
        "bytes": nbytes, "packets": npk,
        "in_if": _u(g("input_if"), 32), "out_if": _u(g("output_if"), 32),
        "in_if_name": _s(g("input_if_name"), 128), "out_if_name": _s(g("output_if_name"), 128),
        "class_name": _s(g("class_id_name"), 256) or _s(g("class_name"), 256),
        "vrf": _u(g("ingress_vrf_id"), 32),
        "xlate_src_ip": _ip(g("xlate_src_ip")) or _ip(g("xlate_src_ipv6")),
        "xlate_src_port": _u(g("xlate_src_port"), 16),
        "xlate_dst_ip": _ip(g("xlate_dst_ip")) or _ip(g("xlate_dst_ipv6")),
        "xlate_dst_port": _u(g("xlate_dst_port"), 16),
        "ext_event": _u(g("fw_ext_event"), 16), "severity": -1, "message": "",
        "extra": json.dumps(extra, separators=(",", ":"))[:8192] if extra else "",
    }


SYSLOG_RE = re.compile(r"^<(\d{1,3})>(.*)$", re.S)
IPPORT_RE = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?(?![\d.])")
PROTO_RE = re.compile(r"\b(tcp|udp|icmp|gre|esp)\b", re.I)
DENY_RE = re.compile(r"drop|deny|denied|block|reset", re.I)


def syslog_row(data: bytes, exp: str, rx: float) -> dict:
    text = data.decode("utf-8", "replace").strip()
    pri = None
    m = SYSLOG_RE.match(text)
    if m:
        pri, text = int(m.group(1)), m.group(2)
    ips = IPPORT_RE.findall(text)

    def ep(i):
        if len(ips) > i:
            return ips[i][0], int(ips[i][1]) if ips[i][1] and int(ips[i][1]) < 65536 else 0
        return "", 0
    src, sp = ep(0)
    dst, dp = ep(1)
    pm = PROTO_RE.search(text)
    return {
        "ts": ch_time(rx), "rx": ch_time(rx), "exporter": exp, "kind": "syslog",
        "event": "denied" if DENY_RE.search(text) else "syslog",
        "proto": PROTO_BY_NAME.get(pm.group(1).lower(), 0) if pm else 0,
        "src_ip": src, "src_port": sp, "dst_ip": dst, "dst_port": dp,
        "bytes": 0, "packets": 0, "in_if": 0, "out_if": 0, "in_if_name": "",
        "out_if_name": "", "class_name": "", "vrf": 0, "xlate_src_ip": "",
        "xlate_src_port": 0, "xlate_dst_ip": "", "xlate_dst_port": 0, "ext_event": 0,
        "severity": (pri & 7) if pri is not None else -1, "message": text[:4000],
        "extra": json.dumps({"facility": pri >> 3}) if pri is not None else "",
    }
