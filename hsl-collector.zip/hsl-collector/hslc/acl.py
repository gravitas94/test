"""
Access list (ACL) of routers allowed to send HSL and syslog to the collector.

* Entries are single addresses or networks (IPv4/IPv6), with a description.
* Mode "enforce": only listed senders are accepted, everything else is dropped
  in the receiver before decoding. Mode "open": everything is accepted and
  senders that are not listed are shown, so the list can be built first.
* Entries from --allow / HSL_ALLOW are "config" entries: always active, not
  editable in the GUI; when present, enforcement is on and locked.
* Stored in <state-dir>/acl.json (mode 600), independent of ClickHouse, so the
  ACL keeps working while the database is down.
"""
from __future__ import annotations

import ipaddress
import json
import os
import re
import secrets
import threading
import time
from pathlib import Path

MAX_ENTRIES = 10_000
_CTRL = re.compile(r"[\x00-\x1f\x7f]+")


class AclError(ValueError):
    pass


def parse_network(text: str):
    """'10.1.2.3', '10.1.0.0/16', '2001:db8::/32' -> ip_network. Host bits are cleared."""
    t = str(text).strip()
    if not t:
        raise AclError("Enter an IP address or network")
    try:
        net = ipaddress.ip_network(t, strict=False)
    except ValueError:
        raise AclError(f"'{t[:60]}' is not an IP address or network (e.g. 10.1.2.3 or 10.1.0.0/16)")
    if net.prefixlen == 0:
        raise AclError("0.0.0.0/0 would allow everyone - switch the mode to 'Any sender' instead")
    return net


def _desc(text) -> str:
    return _CTRL.sub(" ", str(text or "")).strip()[:200]


class AclStore:
    def __init__(self, state_dir: str, config_entries: list[str] | None = None):
        self.path = Path(state_dir) / "acl.json"
        self.lock = threading.Lock()
        self.config = [parse_network(x) for x in (config_entries or [])]
        self.entries: list[dict] = []
        self.mode = "open"
        self.listeners: list = []
        self._load()

    # ---- persistence ------------------------------------------------------
    def _load(self):
        if self.path.exists():
            data = json.loads(self.path.read_text())
            self.mode = data.get("mode", "open")
            for e in data.get("entries", []):
                try:
                    parse_network(e["network"])
                    self.entries.append(e)
                except (AclError, KeyError):
                    continue
        if self.mode not in ("open", "enforce"):
            self.mode = "open"

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump({"mode": self.mode, "entries": self.entries}, fh, indent=1)
        os.replace(tmp, self.path)

    def _changed(self):
        self._save()
        snap = self.effective()
        for fn in self.listeners:
            fn(snap)

    # ---- queries ----------------------------------------------------------
    @property
    def locked(self) -> bool:
        """Config entries force enforcement (set by the administrator of the host)."""
        return bool(self.config)

    def effective(self) -> dict:
        """What the receiver applies: enforce flag + list of network strings."""
        nets = [str(n) for n in self.config] + [e["network"] for e in self.entries]
        return {"enforce": self.locked or self.mode == "enforce", "networks": nets}

    def snapshot(self) -> dict:
        with self.lock:
            cfg = [{"id": f"config-{i}", "network": str(n), "description": "from --allow / HSL_ALLOW",
                    "source": "config", "added_by": None, "added": None}
                   for i, n in enumerate(self.config)]
            return {"mode": "enforce" if self.locked else self.mode, "locked": self.locked,
                    "entries": cfg + [dict(e, source="gui") for e in self.entries]}

    # ---- changes ----------------------------------------------------------
    def add(self, network: str, description: str, user: str) -> dict:
        return self.add_many([(network, description)], user)["added"][0]

    def add_many(self, items, user: str) -> dict:
        """items: iterable of (network, description). Duplicates are skipped."""
        added, skipped, errors = [], [], []
        with self.lock:
            have = {e["network"] for e in self.entries} | {str(n) for n in self.config}
            for net_text, desc in items:
                try:
                    net = str(parse_network(net_text))
                except AclError as ex:
                    errors.append(str(ex))
                    continue
                if net in have:
                    skipped.append(net)
                    continue
                if len(self.entries) >= MAX_ENTRIES:
                    errors.append(f"limit of {MAX_ENTRIES} entries reached")
                    break
                e = {"id": secrets.token_hex(6), "network": net, "description": _desc(desc),
                     "added_by": user, "added": time.time()}
                self.entries.append(e)
                have.add(net)
                added.append(e)
            if added:
                self._changed()
        if not added and errors and len(errors) == 1 and not skipped:
            raise AclError(errors[0])
        return {"added": added, "skipped": skipped, "errors": errors[:20]}

    def update(self, entry_id: str, description: str):
        with self.lock:
            for e in self.entries:
                if e["id"] == entry_id:
                    e["description"] = _desc(description)
                    self._save()
                    return dict(e)
        raise AclError("No such entry")

    def remove(self, entry_id: str) -> dict:
        with self.lock:
            for i, e in enumerate(self.entries):
                if e["id"] == entry_id:
                    del self.entries[i]
                    self._changed()
                    return e
        if entry_id.startswith("config-"):
            raise AclError("This entry comes from --allow / HSL_ALLOW and can only be changed there")
        raise AclError("No such entry")

    def set_mode(self, mode: str):
        if mode not in ("open", "enforce"):
            raise AclError("mode must be 'open' or 'enforce'")
        if self.locked and mode == "open":
            raise AclError("Enforcement is switched on by --allow / HSL_ALLOW on the server")
        with self.lock:
            if self.mode != mode:
                self.mode = mode
                self._changed()


def matcher(networks: list[str]):
    """Fast membership test for the receiver: (v4 nets, v6 nets) -> callable(ip) -> bool."""
    v4 = [ipaddress.ip_network(n) for n in networks if ":" not in n]
    v6 = [ipaddress.ip_network(n) for n in networks if ":" in n]

    def allowed(ip: str) -> bool:
        try:
            a = ipaddress.ip_address(ip.split("%")[0])
        except ValueError:
            return False
        return any(a in n for n in (v6 if a.version == 6 else v4))
    return allowed
