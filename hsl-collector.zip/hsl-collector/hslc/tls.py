"""
HTTPS certificate management for the web GUI.

* First start: a self-signed certificate is generated so the GUI is never
  served over plain HTTP.
* A CA-signed certificate can be installed two ways:
    - certificate request (CSR): the private key is generated here and never
      leaves the server; the signed certificate is uploaded afterwards;
    - import: certificate + private key (PEM/DER) or a PKCS#12 (.pfx/.p12).
* Everything is validated before it is activated (key match, chain, dates,
  key strength, names, usage) and the previous certificate is kept for rollback.
* Activation is live: the running server's SSL context reloads the new
  certificate; new connections use it immediately.
* Files live in <state-dir>/tls (directory 700, keys 600). Private keys are
  never returned by the API.
* --tls-cert/--tls-key on the command line pin a certificate from files; the
  GUI then shows it but can't change it.
"""
from __future__ import annotations

import datetime as dt
import ipaddress
import json
import os
import re
import shutil
import socket
import ssl
import tempfile
import threading
import time
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed448, ed25519, rsa
from cryptography.hazmat.primitives.serialization import pkcs7, pkcs12
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

CIPHERS = "ECDHE+AESGCM:ECDHE+CHACHA20:!aNULL:!eNULL:!MD5:!DSS:!RC4:!3DES"
KEY_TYPES = {"rsa2048": "RSA 2048", "rsa3072": "RSA 3072", "rsa4096": "RSA 4096",
             "ec256": "ECDSA P-256", "ec384": "ECDSA P-384"}
WARN_DAYS = 30
_NAME_RE = re.compile(r"^(\*\.)?[A-Za-z0-9]([A-Za-z0-9-]{0,62})?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,62})?)*\.?$")


class CertError(ValueError):
    """Validation failed. .errors = list of messages."""

    def __init__(self, errors):
        self.errors = errors if isinstance(errors, list) else [errors]
        super().__init__("; ".join(self.errors))


def _now():
    return dt.datetime.now(dt.timezone.utc)


# ---------------------------------------------------------------- parsing
def load_certs(data: bytes) -> list:
    """PEM (one or more), DER, or PKCS#7 (.p7b, PEM or DER) -> certificates."""
    data = data.strip()
    if not data:
        raise CertError("The certificate is empty")
    try:
        if b"-----BEGIN PKCS7-----" in data:
            return list(pkcs7.load_pem_pkcs7_certificates(data))
        if b"-----BEGIN" in data:
            certs = x509.load_pem_x509_certificates(data)
            if certs:
                return list(certs)
        else:
            try:
                return [x509.load_der_x509_certificate(data)]
            except ValueError:
                return list(pkcs7.load_der_pkcs7_certificates(data))
    except ValueError:
        pass
    raise CertError("Not a readable certificate. Use PEM (.pem/.crt), DER (.cer) or PKCS#7 (.p7b)")


def load_key(data: bytes, password: str | None):
    data = data.strip()
    pw = password.encode() if password else None
    try:
        if b"-----BEGIN" in data:
            return serialization.load_pem_private_key(data, pw)
        return serialization.load_der_private_key(data, pw)
    except TypeError:
        raise CertError("The private key is protected by a password - enter the password"
                        if pw is None else "This private key is not password protected - leave the password empty")
    except ValueError:
        raise CertError("Not a readable private key, or wrong password")


def load_pkcs12(data: bytes, password: str | None):
    try:
        key, cert, extra = pkcs12.load_key_and_certificates(data, password.encode() if password else None)
    except ValueError:
        raise CertError("Can't open the .pfx/.p12 file - wrong password or not a PKCS#12 file")
    if key is None or cert is None:
        raise CertError("The .pfx/.p12 file must contain the certificate and its private key")
    return key, [cert] + list(extra or [])


# ---------------------------------------------------------------- helpers
def _spki(pub) -> bytes:
    return pub.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)


def _names(cert) -> list[str]:
    try:
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        return []
    return ([str(n) for n in san.get_values_for_type(x509.DNSName)]
            + [str(n) for n in san.get_values_for_type(x509.IPAddress)])


def _cn(name: x509.Name) -> str:
    attrs = name.get_attributes_for_oid(NameOID.COMMON_NAME)
    return str(attrs[0].value) if attrs else name.rfc4514_string()


def _self_issued(c) -> bool:
    return c.issuer == c.subject


def _key_desc(pub) -> str:
    if isinstance(pub, rsa.RSAPublicKey):
        return f"RSA {pub.key_size}"
    if isinstance(pub, ec.EllipticCurvePublicKey):
        return {"secp256r1": "ECDSA P-256", "secp384r1": "ECDSA P-384",
                "secp521r1": "ECDSA P-521"}.get(pub.curve.name, f"EC {pub.curve.name}")
    return type(pub).__name__


def host_matches(host: str, names: list[str]) -> bool:
    host = host.lower().rstrip(".")
    for n in names:
        n = n.lower().rstrip(".")
        if n == host:
            return True
        if n.startswith("*.") and "." in host and host.split(".", 1)[1] == n[2:]:
            return True
    return False


def order_chain(certs: list, key=None):
    """Find the leaf (matching the key if given) and build issuer order; return (leaf, chain, unused)."""
    leaf = None
    if key is not None:
        spki = _spki(key.public_key())
        leaf = next((c for c in certs if _spki(c.public_key()) == spki), None)
        if leaf is None:
            raise CertError("The private key doesn't belong to this certificate")
    if leaf is None:
        issuers = {c.issuer for c in certs}
        leaf = next((c for c in certs if c.subject not in issuers or _self_issued(c) and len(certs) == 1),
                    certs[0])
    chain, cur, pool = [], leaf, [c for c in certs if c is not leaf]
    while not _self_issued(cur):
        nxt = next((c for c in pool if c.subject == cur.issuer), None)
        if nxt is None:
            break
        chain.append(nxt)
        pool.remove(nxt)
        cur = nxt
    return leaf, chain, pool


def validate(leaf, chain: list, key, hosts: list[str] = ()) -> list[str]:
    """Raise CertError for problems that would break HTTPS; return warnings."""
    errors, warnings = [], []
    pub = leaf.public_key()
    if _spki(pub) != _spki(key.public_key()):
        errors.append("The private key doesn't belong to this certificate")
    if isinstance(pub, rsa.RSAPublicKey) and pub.key_size < 2048:
        errors.append(f"RSA key of {pub.key_size} bits is too weak - use 2048 bits or more")
    elif isinstance(pub, ec.EllipticCurvePublicKey) and pub.curve.name not in ("secp256r1", "secp384r1", "secp521r1"):
        errors.append(f"Elliptic curve {pub.curve.name} is not supported by browsers - use P-256 or P-384")
    elif isinstance(pub, (ed25519.Ed25519PublicKey, ed448.Ed448PublicKey)):
        errors.append("Ed25519/Ed448 certificates are not supported by browsers - use RSA or ECDSA")
    elif not isinstance(pub, (rsa.RSAPublicKey, ec.EllipticCurvePublicKey)):
        errors.append("Unsupported key type - use RSA or ECDSA")
    now = _now()
    if leaf.not_valid_before_utc > now:
        errors.append(f"The certificate is not valid until {leaf.not_valid_before_utc:%Y-%m-%d %H:%M} UTC")
    if leaf.not_valid_after_utc <= now:
        errors.append(f"The certificate expired on {leaf.not_valid_after_utc:%Y-%m-%d}")
    elif (leaf.not_valid_after_utc - now).days < WARN_DAYS:
        warnings.append(f"The certificate expires in {(leaf.not_valid_after_utc - now).days} days")
    algo = leaf.signature_hash_algorithm
    if algo is not None and algo.name in ("sha1", "md5"):
        errors.append(f"The certificate is signed with {algo.name.upper()}, which browsers reject")
    names = _names(leaf)
    if not names:
        errors.append("The certificate has no Subject Alternative Names - browsers require the "
                      "host name there (the Common Name alone is ignored)")
    try:
        eku = leaf.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
        if ExtendedKeyUsageOID.SERVER_AUTH not in eku:
            errors.append("The certificate is not allowed for servers (Extended Key Usage has no "
                          "'TLS Web Server Authentication')")
    except x509.ExtensionNotFound:
        pass
    try:
        if leaf.extensions.get_extension_for_class(x509.BasicConstraints).value.ca:
            warnings.append("This is a CA certificate, not a server certificate")
    except x509.ExtensionNotFound:
        pass
    cur = leaf
    for c in chain:
        try:
            cur.verify_directly_issued_by(c)
        except (ValueError, TypeError, Exception):  # InvalidSignature etc.
            errors.append(f"'{_cn(c.subject)}' in the chain did not sign '{_cn(cur.subject)}'")
            break
        cur = c
    if not _self_issued(leaf) and not chain:
        warnings.append("No intermediate/CA certificates included. If your CA uses an intermediate "
                        "certificate, include it, otherwise some clients will fail")
    lifetime = (leaf.not_valid_after_utc - leaf.not_valid_before_utc).days
    if lifetime > 825:
        warnings.append(f"Valid for {lifetime} days: Safari/macOS reject certificates valid for "
                        "more than 825 days")
    for h in hosts:
        if h and names and not host_matches(h, names):
            warnings.append(f"Not valid for '{h}' (the name you're using now). Browsers will warn "
                            f"unless you connect with: {', '.join(names[:6])}")
    if errors:
        raise CertError(errors)
    return warnings


def _write(path: Path, data: bytes, secret=False):
    tmp = path.with_suffix(path.suffix + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600 if secret else 0o644)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
    os.replace(tmp, path)


def _pem_key(key) -> bytes:
    return key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                             serialization.NoEncryption())


def _new_key(kind: str):
    if kind.startswith("rsa"):
        return rsa.generate_private_key(public_exponent=65537, key_size=int(kind[3:]))
    return ec.generate_private_key(ec.SECP256R1() if kind == "ec256" else ec.SECP384R1())


def _is_ip(n: str) -> bool:
    try:
        ipaddress.ip_address(n)
        return True
    except ValueError:
        return False


def parse_names(items) -> list:
    """Host names / IPs -> x509 GeneralNames (validated)."""
    out, seen = [], set()
    for raw in items:
        n = str(raw).strip().lower()
        if not n or n in seen:
            continue
        seen.add(n)
        try:
            out.append(x509.IPAddress(ipaddress.ip_address(n)))
            continue
        except ValueError:
            pass
        if not _NAME_RE.match(n) or len(n) > 253:
            raise CertError(f"'{str(raw)[:60]}' is not a valid host name or IP address")
        out.append(x509.DNSName(n.rstrip(".")))
    return out


def _usable_name(n: str) -> bool:
    """Skip reverse-DNS names: on macOS getfqdn() can return e.g. '1.0.0...ip6.arpa'."""
    n = (n or "").lower().rstrip(".")
    return bool(n) and not n.endswith((".in-addr.arpa", ".ip6.arpa")) and _NAME_RE.match(n) is not None


def default_names(extra=()) -> list[str]:
    names = []
    for n in (socket.getfqdn(), socket.gethostname(), "localhost", "127.0.0.1", "::1", *extra):
        if n and n not in names and (n in extra or _usable_name(n) or _is_ip(n)):
            names.append(n)
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip not in names:
                names.append(ip)
    except OSError:
        pass
    return names


# ---------------------------------------------------------------- manager
class TlsManager:
    def __init__(self, state_dir: str, fixed_cert: str = "", fixed_key: str = "", extra_names=()):
        self.dir = Path(state_dir) / "tls"
        self.dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.dir, 0o700)
        except OSError:
            pass
        self.fixed = bool(fixed_cert)
        self.extra_names = [n for n in extra_names if n]
        self.cert_path = Path(fixed_cert) if fixed_cert else self.dir / "active.crt"
        self.key_path = Path(fixed_key) if fixed_key else self.dir / "active.key"
        self.lock = threading.Lock()
        self.contexts: list = []
        self.meta = self._read_json("meta.json")
        if not self.fixed and not (self.cert_path.exists() and self.key_path.exists()):
            self._self_signed(default_names(self.extra_names), "system", first=True)

    # ---- files ------------------------------------------------------------
    def _read_json(self, name):
        try:
            return json.loads((self.dir / name).read_text())
        except (OSError, ValueError):
            return {}

    def _write_json(self, name, data):
        _write(self.dir / name, json.dumps(data, indent=1).encode())

    # ---- SSL context for the web server ------------------------------------
    def _build_context(self) -> ssl.SSLContext:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.set_ciphers(CIPHERS)
        ctx.options |= ssl.OP_NO_COMPRESSION | ssl.OP_CIPHER_SERVER_PREFERENCE
        ctx.load_cert_chain(str(self.cert_path), str(self.key_path))
        return ctx

    def make_context(self) -> ssl.SSLContext:
        """Context for the listening socket. Each handshake is switched to the
        context of the currently active certificate (the callback also runs when
        the client sends no server name), so a new certificate - even with a
        different key type - is used from the next connection on."""
        self.current = self._build_context()
        front = self._build_context()

        def pick(sslobj, server_name, _ctx):
            sslobj.context = self.current
        front.sni_callback = pick
        self.contexts.append(front)
        return front

    def _reload(self):
        if self.contexts:
            self.current = self._build_context()

    # ---- info -----------------------------------------------------------
    def _describe(self, certs):
        leaf, chain = certs[0], certs[1:]
        now = _now()
        days = (leaf.not_valid_after_utc - now).total_seconds() / 86400
        return {
            "subject": _cn(leaf.subject), "subject_dn": leaf.subject.rfc4514_string(),
            "issuer": _cn(leaf.issuer), "issuer_dn": leaf.issuer.rfc4514_string(),
            "names": _names(leaf), "self_signed": _self_issued(leaf),
            "not_before": leaf.not_valid_before_utc.timestamp(),
            "not_after": leaf.not_valid_after_utc.timestamp(), "days_left": int(days // 1),
            "expired": days <= 0, "key": _key_desc(leaf.public_key()),
            "serial": format(leaf.serial_number, "x"),
            "sha256": leaf.fingerprint(hashes.SHA256()).hex(":").upper(),
            "chain": [{"subject": _cn(c.subject), "issuer": _cn(c.issuer),
                       "not_after": c.not_valid_after_utc.timestamp()} for c in chain],
        }

    def info(self) -> dict:
        with self.lock:
            out = {"locked": self.fixed, "previous": None, "pending": None,
                   "source": "files on the server" if self.fixed else self.meta.get("source"),
                   "activated_by": self.meta.get("activated_by"),
                   "activated": self.meta.get("activated")}
            try:
                out["active"] = self._describe(load_certs(self.cert_path.read_bytes()))
            except (OSError, CertError) as ex:
                out["active"] = None
                out["error"] = str(ex)
            prev = self.dir / "previous.crt"
            if not self.fixed and prev.exists():
                try:
                    p = self._describe(load_certs(prev.read_bytes()))
                    out["previous"] = {k: p[k] for k in ("subject", "issuer", "not_after", "self_signed")}
                except CertError:
                    pass
            pend = self._read_json("pending.json")
            if pend and (self.dir / "pending.csr").exists():
                out["pending"] = {**pend, "csr": (self.dir / "pending.csr").read_text()}
            return out

    def summary(self) -> dict:
        a = self.info().get("active") or {}
        return {"days_left": a.get("days_left"), "expired": a.get("expired"),
                "self_signed": a.get("self_signed"), "subject": a.get("subject")}

    # ---- install ------------------------------------------------------------
    def _guard(self):
        if self.fixed:
            raise CertError("The certificate is set with --tls-cert/--tls-key on the server "
                            "and can only be changed there")

    def _install(self, leaf, chain, key, source, user, hosts, first=False):
        warnings = validate(leaf, chain, key, hosts)
        pem_certs = b"".join(c.public_bytes(serialization.Encoding.PEM) for c in [leaf, *chain])
        pem_key = _pem_key(key)
        # make sure OpenSSL accepts the pair before touching the live files
        with tempfile.TemporaryDirectory(dir=self.dir) as td:
            c, k = Path(td) / "c.pem", Path(td) / "k.pem"
            _write(c, pem_certs)
            _write(k, pem_key, secret=True)
            try:
                ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER).load_cert_chain(str(c), str(k))
            except ssl.SSLError as ex:
                raise CertError(f"OpenSSL can't use this certificate: {ex}")
        if not first and self.cert_path.exists():
            shutil.copyfile(self.cert_path, self.dir / "previous.crt")
            shutil.copyfile(self.key_path, self.dir / "previous.key")
            os.chmod(self.dir / "previous.key", 0o600)
            (self.dir / "previous.json").write_text(json.dumps(self.meta))
        _write(self.key_path, pem_key, secret=True)
        _write(self.cert_path, pem_certs)
        self.meta = {"source": source, "activated_by": user, "activated": time.time()}
        self._write_json("meta.json", self.meta)
        self._reload()
        return warnings

    def _self_signed(self, names, user, first=False):
        gn = parse_names(names) or parse_names(["localhost"])
        dns = [str(n.value) for n in gn if isinstance(n, x509.DNSName)]
        cn = next((n for n in dns if n != "localhost" and "." in n), None) or \
            next((n for n in dns if n != "localhost"), None) or (dns[0] if dns else "hsl-collector")
        key = ec.generate_private_key(ec.SECP256R1())
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn[:64]),
                             x509.NameAttribute(NameOID.ORGANIZATION_NAME, "HSL Collector (self-signed)")])
        now = _now()
        cert = (x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
                .public_key(key.public_key()).serial_number(x509.random_serial_number())
                .not_valid_before(now - dt.timedelta(minutes=5)).not_valid_after(now + dt.timedelta(days=397))
                .add_extension(x509.SubjectAlternativeName(gn), critical=False)
                .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
                .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
                .add_extension(x509.KeyUsage(digital_signature=True, key_encipherment=False,
                                             content_commitment=False, data_encipherment=False,
                                             key_agreement=False, key_cert_sign=False, crl_sign=False,
                                             encipher_only=False, decipher_only=False), critical=True)
                .sign(key, hashes.SHA256()))
        return self._install(cert, [], key, "self-signed", user, [], first=first)

    def self_signed(self, names, user):
        self._guard()
        with self.lock:
            return self._self_signed(names or default_names(self.extra_names), user)

    def import_pair(self, cert_data: bytes, key_data: bytes, key_password, user, hosts=()):
        self._guard()
        key = load_key(key_data, key_password)
        leaf, chain, unused = order_chain(load_certs(cert_data), key)
        with self.lock:
            w = self._install(leaf, chain, key, "imported", user, hosts)
        return w + ([f"{len(unused)} certificate(s) in the upload were not part of the chain and "
                     "were left out"] if unused else [])

    def import_pkcs12(self, data: bytes, password, user, hosts=()):
        self._guard()
        key, certs = load_pkcs12(data, password)
        leaf, chain, unused = order_chain(certs, key)
        with self.lock:
            return self._install(leaf, chain, key, "imported (.pfx)", user, hosts)

    # ---- certificate request ---------------------------------------------
    def create_csr(self, common_name, names, organization, country, key_type, user) -> str:
        self._guard()
        if key_type not in KEY_TYPES:
            raise CertError("Unknown key type")
        cn = str(common_name or "").strip().lower()
        if not cn:
            raise CertError("Enter the host name (Common Name)")
        gn = parse_names([cn, *names])
        attrs = [x509.NameAttribute(NameOID.COMMON_NAME, cn[:64])]
        if organization and str(organization).strip():
            attrs.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, str(organization).strip()[:64]))
        if country and str(country).strip():
            c = str(country).strip().upper()
            if not re.fullmatch(r"[A-Z]{2}", c):
                raise CertError("Country must be a 2-letter code, e.g. NL")
            attrs.append(x509.NameAttribute(NameOID.COUNTRY_NAME, c))
        key = _new_key(key_type)
        csr = (x509.CertificateSigningRequestBuilder().subject_name(x509.Name(attrs))
               .add_extension(x509.SubjectAlternativeName(gn), critical=False)
               .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
               .sign(key, hashes.SHA256()))
        pem = csr.public_bytes(serialization.Encoding.PEM)
        with self.lock:
            _write(self.dir / "pending.key", _pem_key(key), secret=True)
            _write(self.dir / "pending.csr", pem)
            self._write_json("pending.json", {
                "common_name": cn, "names": [str(n.value) for n in gn], "key_type": KEY_TYPES[key_type],
                "created_by": user, "created": time.time()})
        return pem.decode()

    def cancel_csr(self):
        with self.lock:
            for n in ("pending.key", "pending.csr", "pending.json"):
                (self.dir / n).unlink(missing_ok=True)

    def complete_csr(self, cert_data: bytes, user, hosts=()):
        self._guard()
        kp = self.dir / "pending.key"
        if not kp.exists():
            raise CertError("There is no open certificate request - create one first")
        key = serialization.load_pem_private_key(kp.read_bytes(), None)
        try:
            leaf, chain, unused = order_chain(load_certs(cert_data), key)
        except CertError as ex:
            if "doesn't belong" in str(ex):
                raise CertError("This certificate was not issued for the open request (its key "
                                "doesn't match). Upload the certificate the CA issued for this CSR")
            raise
        with self.lock:
            w = self._install(leaf, chain, key, "CA-signed (request created here)", user, hosts)
            for n in ("pending.key", "pending.csr", "pending.json"):
                (self.dir / n).unlink(missing_ok=True)
        return w + ([f"{len(unused)} certificate(s) in the upload were not part of the chain and "
                     "were left out"] if unused else [])

    def rollback(self, user):
        self._guard()
        pc, pk = self.dir / "previous.crt", self.dir / "previous.key"
        if not (pc.exists() and pk.exists()):
            raise CertError("There is no previous certificate")
        with self.lock:
            key = serialization.load_pem_private_key(pk.read_bytes(), None)
            certs = load_certs(pc.read_bytes())
            ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER).load_cert_chain(str(pc), str(pk))
            old = self._read_json("previous.json")
            # swap active <-> previous
            cur_c, cur_k = self.cert_path.read_bytes(), self.key_path.read_bytes()
            _write(self.key_path, _pem_key(key), secret=True)
            _write(self.cert_path, b"".join(c.public_bytes(serialization.Encoding.PEM) for c in certs))
            _write(pc, cur_c)
            _write(pk, cur_k, secret=True)
            (self.dir / "previous.json").write_text(json.dumps(self.meta))
            self.meta = {**old, "activated_by": user, "activated": time.time(),
                         "source": (old.get("source") or "previous") + " (restored)"}
            self._write_json("meta.json", self.meta)
            self._reload()
