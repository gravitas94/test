"""
Users, sessions and login throttling for the web GUI / API.

* Users live in <state-dir>/users.json (file mode 600); passwords are stored as
  PBKDF2-SHA256 hashes with a random salt, never in clear text.
* First start creates the user admin / admin (role admin).
* Roles: admin  - everything, including user management and router names
         viewer - read-only
* Browser sessions: random token in an HttpOnly, SameSite=Strict cookie,
  kept in memory (a collector restart logs everyone out). Changing a
  password or deleting a user ends that user's sessions.
* Scripts may use HTTP Basic auth with the same accounts.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import threading
import time
from pathlib import Path

log = logging.getLogger("hsl-collector")

ROLES = ("admin", "viewer")
ITERATIONS = 240_000
MIN_PASSWORD = 8
USERNAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._@-]{0,63}$")
DEFAULT_USER, DEFAULT_PASSWORD = "admin", "admin"


class AuthError(Exception):
    def __init__(self, msg, status=400):
        super().__init__(msg)
        self.status = status


def _hash(password: str, salt: bytes | None = None, iterations: int = ITERATIONS) -> str:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${dk.hex()}"


def _check(password: str, stored: str) -> bool:
    try:
        algo, it, salt, digest = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(it))
        return hmac.compare_digest(dk.hex(), digest)
    except (ValueError, TypeError):
        return False


_DUMMY = _hash("timing-equaliser")
# PBKDF2 is deliberately slow; cap concurrent checks so a login flood can't use all CPUs
_HASH_SLOTS = threading.BoundedSemaphore(4)
_CTRL = re.compile(r"[\x00-\x1f\x7f]")


def clean(s, n: int = 64) -> str:
    """Untrusted text for log lines: no control characters (no forged log lines)."""
    return _CTRL.sub("?", str(s))[:n]


class UserStore:
    def __init__(self, state_dir: str):
        self.path = Path(state_dir) / "users.json"
        self.lock = threading.Lock()
        self.users: dict = {}
        self.mtime = 0.0
        self.load()

    # ---- persistence ------------------------------------------------------
    def load(self):
        if self.path.exists():
            self.users = json.loads(self.path.read_text())
        else:
            self.users = {}
        self._stamp()
        if not self.users:
            self.users[DEFAULT_USER] = self._new(DEFAULT_PASSWORD, "admin", default=True)
            self._save()
            log.warning("created default user '%s' with password '%s' - change it after the "
                        "first login", DEFAULT_USER, DEFAULT_PASSWORD)

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump(self.users, fh, indent=1)
        os.replace(tmp, self.path)
        self._stamp()

    def _stamp(self):
        try:
            self.mtime = self.path.stat().st_mtime
        except OSError:
            self.mtime = 0.0

    def _fresh(self):
        """Pick up changes made outside this process (e.g. --reset-admin)."""
        try:
            m = self.path.stat().st_mtime
        except OSError:
            return
        if m != self.mtime:
            try:
                self.users = json.loads(self.path.read_text()) or self.users
                log.info("users file changed on disk - reloaded")
            except (OSError, ValueError) as ex:
                log.error("cannot reload users file: %s", ex)
            self.mtime = m

    @staticmethod
    def _new(password, role, default=False):
        return {"hash": _hash(password), "role": role, "created": time.time(),
                "password_changed": time.time(), "last_login": None,
                "default_password": default}

    # ---- queries ----------------------------------------------------------
    def verify(self, username: str, password: str):
        if len(password) > 256 or len(username) > 64:
            return None
        with self.lock:
            self._fresh()
            u = self.users.get(username)
        with _HASH_SLOTS:
            if u is None:
                _check(password, _DUMMY)      # same work as a real check (no user probing)
                return None
            return username if _check(password, u["hash"]) else None

    def get(self, username):
        with self.lock:
            self._fresh()
            u = self.users.get(username)
            return dict(u) if u else None

    def public(self, username):
        u = self.get(username)
        if not u:
            return None
        return {"username": username, "role": u["role"], "created": u["created"],
                "last_login": u["last_login"], "password_changed": u["password_changed"],
                "default_password": u.get("default_password", False)}

    def list(self):
        with self.lock:
            self._fresh()
            names = sorted(self.users)
        return [self.public(n) for n in names]

    def _admins(self):
        return [n for n, u in self.users.items() if u["role"] == "admin"]

    # ---- changes ----------------------------------------------------------
    def touch_login(self, username):
        with self.lock:
            self._fresh()
            if username in self.users:
                self.users[username]["last_login"] = time.time()
                self._save()

    def add(self, username: str, password: str, role: str):
        username = (username or "").strip()
        if not USERNAME_RE.match(username):
            raise AuthError("Username: 1-64 characters, letters, digits and . _ @ - only")
        if role not in ROLES:
            raise AuthError(f"Role must be one of {', '.join(ROLES)}")
        _validate(password, username)
        with self.lock:
            self._fresh()
            if username in self.users:
                raise AuthError("User already exists", 409)
            self.users[username] = self._new(password, role)
            self._save()

    def set_password(self, username: str, password: str):
        _validate(password, username)
        with self.lock:
            self._fresh()
            if username not in self.users:
                raise AuthError("No such user", 404)
            u = self.users[username]
            u["hash"] = _hash(password)
            u["password_changed"] = time.time()
            u["default_password"] = False
            self._save()

    def set_role(self, username: str, role: str):
        if role not in ROLES:
            raise AuthError(f"Role must be one of {', '.join(ROLES)}")
        with self.lock:
            self._fresh()
            if username not in self.users:
                raise AuthError("No such user", 404)
            if role != "admin" and self.users[username]["role"] == "admin" and len(self._admins()) == 1:
                raise AuthError("This is the last admin - make another user admin first")
            self.users[username]["role"] = role
            self._save()

    def delete(self, username: str):
        with self.lock:
            self._fresh()
            if username not in self.users:
                raise AuthError("No such user", 404)
            if self.users[username]["role"] == "admin" and len(self._admins()) == 1:
                raise AuthError("Cannot delete the last admin")
            del self.users[username]
            self._save()

    def reset_admin(self):
        """Recovery: (re)create admin/admin with role admin."""
        with self.lock:
            self.users[DEFAULT_USER] = self._new(DEFAULT_PASSWORD, "admin", default=True)
            self._save()


WEAK = {"admin", "password", "changeme", "change-me", "hslcollector", "collector", "cisco",
        "letmein", "welcome", "qwerty", "12345678", "123456789", "1234567890", "password1",
        "admin123", "administrator", "sdwan", "viptela"}


def _validate(password, username: str = ""):
    if not isinstance(password, str) or len(password) < MIN_PASSWORD:
        raise AuthError(f"Password must be at least {MIN_PASSWORD} characters")
    if len(password) > 256:
        raise AuthError("Password too long")
    low = password.lower()
    if low in WEAK or (username and username.lower() in low) or len(set(password)) < 4:
        raise AuthError("Password is too easy to guess - don't use the username or a common word")


class Sessions:
    def __init__(self, idle_hours: float = 12, max_hours: float = 7 * 24):
        self.idle = idle_hours * 3600
        self.max = max_hours * 3600
        self.s: dict = {}           # token -> {user, created, seen, csrf}
        self.lock = threading.Lock()

    def create(self, user: str) -> str:
        token = secrets.token_urlsafe(32)
        now = time.time()
        with self.lock:
            self._expire(now)
            mine = sorted((v["seen"], t) for t, v in self.s.items() if v["user"] == user)
            for _, t in mine[:max(0, len(mine) - 49)]:     # max 50 sessions per user
                del self.s[t]
            self.s[token] = {"user": user, "created": now, "seen": now}
        return token

    def get(self, token: str | None):
        if not token:
            return None
        now = time.time()
        with self.lock:
            v = self.s.get(token)
            if not v:
                return None
            if now - v["seen"] > self.idle or now - v["created"] > self.max:
                del self.s[token]
                return None
            v["seen"] = now
            return v["user"]

    def drop(self, token):
        with self.lock:
            self.s.pop(token, None)

    def drop_user(self, user, keep: str | None = None):
        with self.lock:
            for t in [t for t, v in self.s.items() if v["user"] == user and t != keep]:
                del self.s[t]

    def _expire(self, now):
        for t in [t for t, v in self.s.items()
                  if now - v["seen"] > self.idle or now - v["created"] > self.max]:
            del self.s[t]


class Throttle:
    """After `limit` failures for one key (address or username), wait `base` seconds,
    doubling with every further failure up to `cap`."""

    def __init__(self, limit=5, base=60, cap=900):
        self.limit, self.base, self.cap = limit, base, cap
        self.f: dict = {}           # ip -> [fails, locked_until]
        self.lock = threading.Lock()

    def check(self, ip) -> int:
        with self.lock:
            v = self.f.get(ip)
            return max(0, int(v[1] - time.time())) if v else 0

    def fail(self, ip):
        with self.lock:
            if len(self.f) > 50_000:                   # flood of addresses / usernames
                now = time.time()
                for k in [k for k, v in self.f.items() if v[1] < now][:25_000]:
                    del self.f[k]
            v = self.f.setdefault(ip, [0, 0.0])
            v[0] += 1
            if v[0] >= self.limit:
                v[1] = time.time() + min(self.cap, self.base * 2 ** (v[0] - self.limit))

    def ok(self, ip):
        with self.lock:
            self.f.pop(ip, None)
