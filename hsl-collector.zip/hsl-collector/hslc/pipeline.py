"""
Ingest pipeline:

    UDP sockets --> receiver process --(hash by router IP)--> N decoder processes
                                                                 |  decode + enrich
                                                                 v
                                                          writer thread --> ClickHouse

* The receiver only reads packets and hands them out in small batches, so it
  keeps up with tens of thousands of packets per second.
* Every router always lands on the same decoder (hash of its IP), so its
  templates and sequence numbers live in exactly one place.
* Decoders batch rows and insert into ClickHouse every second (or sooner when
  a batch is full). If ClickHouse is down, rows are buffered up to a limit.
* Every stage counts what it drops; the web GUI shows all of it.
"""
from __future__ import annotations

import ipaddress
import json
import logging
import os
import queue
import selectors
import signal
import socket
import threading
import time
import zlib
from pathlib import Path

from .acl import matcher
from .clickhouse import DATA_ERRORS, ClickHouse, ClickHouseError
from .decoder import Decoder, hsl_row, syslog_row

log = logging.getLogger("hsl-collector")


# ---------------------------------------------------------------- receiver
def udp_socket(host: str, port: int, rcvbuf: int) -> socket.socket:
    fam = socket.AF_INET6 if ":" in host else socket.AF_INET
    s = socket.socket(fam, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, rcvbuf)
    except OSError:
        pass
    s.bind((host, port))
    s.setblocking(False)
    return s


def kernel_drops(sock: socket.socket):
    """Linux only: packets the kernel dropped because the socket buffer was full."""
    try:
        inode = str(os.fstat(sock.fileno()).st_ino)
    except OSError:
        return None
    total = None
    for f in ("/proc/net/udp", "/proc/net/udp6"):
        try:
            with open(f) as fh:
                next(fh)
                for line in fh:
                    parts = line.split()
                    if len(parts) >= 13 and parts[9] == inode:
                        total = (total or 0) + int(parts[-1])
        except (OSError, StopIteration, ValueError):
            continue
    return total


def _allowed(ip: str, nets) -> bool:
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
    except ValueError:
        return False
    return any(a in net for net in nets)


MAX_UNKNOWN = 1000          # unlisted senders tracked for the GUI


def receiver_main(cfg: dict, queues: list, stats_q, acl_q=None):
    signal.signal(signal.SIGINT, signal.SIG_IGN)   # parent handles shutdown
    logging.basicConfig(level=cfg["log_level"], format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    n = len(queues)
    socks = {"f": udp_socket(cfg["listen"], cfg["flow_port"], cfg["rcvbuf"])}
    if cfg["syslog_port"]:
        socks["s"] = udp_socket(cfg["listen"], cfg["syslog_port"], cfg["rcvbuf"])
    actual = {k: s.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF) for k, s in socks.items()}
    if actual["f"] < cfg["rcvbuf"] // 2:
        log.warning("UDP receive buffer is only %d bytes (asked %d) - raise net.core.rmem_max",
                    actual["f"], cfg["rcvbuf"])
    sel = selectors.DefaultSelector()
    for kind, s in socks.items():
        sel.register(s, selectors.EVENT_READ, kind)

    # access list: applied here, before any decoding; updated live from the web side
    acl = cfg.get("acl") or {"enforce": False, "networks": []}
    listed = matcher(acl["networks"])
    enforce = acl["enforce"]
    # source address -> (worker, clean ip, listed) or None = blocked
    route: dict = {}
    unknown: dict = {}                   # unlisted sender -> [packets, first seen, last seen, blocked]
    pending = [[] for _ in range(n)]
    st = {"packets": 0, "bytes": 0, "queue_drops": 0, "kernel_drops": None,
          "rcvbuf": actual["f"], "rejected": 0, "unknown_overflow": 0,
          "acl_enforce": enforce, "acl_entries": len(acl["networks"])}
    k0 = kernel_drops(socks["f"])
    last_flush = last_stats = last_acl = time.monotonic()
    while True:
        for key, _ in sel.select(timeout=0.02):
            s, kind = key.fileobj, key.data
            for _ in range(2000):
                try:
                    data, addr = s.recvfrom(65535)
                except (BlockingIOError, InterruptedError):
                    break
                r = route.get(addr[0], False)
                if r is False:
                    exp = addr[0][7:] if addr[0].startswith("::ffff:") else addr[0]
                    ok = listed(exp)
                    if not ok and enforce:
                        r = None
                        log.warning("blocking packets from %s: not on the access list", exp)
                    else:
                        r = (zlib.crc32(exp.encode()) % n, exp, ok)
                    if not ok and exp not in unknown:
                        if len(unknown) < MAX_UNKNOWN:
                            now_t = time.time()
                            unknown[exp] = [0, now_t, now_t, enforce]
                        else:
                            st["unknown_overflow"] += 1
                    if len(route) > 100_000:     # spoofed-source floods must not grow this forever
                        route.clear()
                    route[addr[0]] = r
                if r is None or not r[2]:        # unlisted sender: count it for the GUI
                    exp = addr[0][7:] if addr[0].startswith("::ffff:") else addr[0]
                    u = unknown.get(exp)
                    if u is not None:
                        u[0] += 1
                        u[2] = time.time()
                        u[3] = r is None
                    if r is None:
                        st["rejected"] += 1
                        continue
                w, exp, _ = r
                pending[w].append((kind, exp, time.time(), data, addr[1]))
                st["packets"] += 1
                st["bytes"] += len(data)
        now = time.monotonic()
        if now - last_flush >= 0.02 or any(len(p) >= 500 for p in pending):
            for w in range(n):
                if pending[w]:
                    try:
                        queues[w].put_nowait(pending[w])
                    except queue.Full:
                        st["queue_drops"] += len(pending[w])
                    pending[w] = []
            last_flush = now
        if acl_q is not None and now - last_acl >= 0.25:
            last_acl = now
            try:
                while True:
                    acl = acl_q.get_nowait()
                    listed = matcher(acl["networks"])
                    enforce = acl["enforce"]
                    route.clear()                # re-check every sender against the new list
                    for ip in [ip for ip in unknown if listed(ip)]:
                        del unknown[ip]
                    st["acl_enforce"], st["acl_entries"] = enforce, len(acl["networks"])
                    log.info("access list updated: %s, %d entries",
                             "enforcing" if enforce else "open", len(acl["networks"]))
            except queue.Empty:
                pass
        if now - last_stats >= 2:
            st["unknown"] = sorted(([ip, *v] for ip, v in unknown.items()),
                                   key=lambda x: -x[3])[:500]
            kd = kernel_drops(socks["f"])
            if kd is not None and k0 is not None:
                st["kernel_drops"] = kd - k0
            stats_q.put(("rx", 0, dict(st)))
            last_stats = now


# ---------------------------------------------------------------- decoder worker
class Writer(threading.Thread):
    """Batches JSON rows and inserts them into ClickHouse."""

    def __init__(self, idx: int, cfg: dict):
        super().__init__(name=f"writer-{idx}", daemon=True)
        self.idx = idx
        self.ch = ClickHouse(cfg["ch_url"], cfg["ch_user"], cfg["ch_password"], cfg["ch_database"])
        self.batch_rows = cfg["batch_rows"]
        self.flush_s = cfg["flush_interval"]
        self.max_bytes = int(cfg["max_buffer_mb"] * 1024 * 1024)
        self.q: queue.SimpleQueue = queue.SimpleQueue()   # lists of json lines
        self.buffered = 0            # rows waiting for ClickHouse
        self.buffered_bytes = 0      # their size; capped so an outage can't exhaust RAM
        self.lock = threading.Lock()
        self.stats = {"inserted": 0, "insert_errors": 0, "db_drops": 0, "last_error": None,
                      "rejected_batches": 0,
                      "last_error_ts": 0, "last_insert_ms": 0, "buffered": 0, "buffered_mb": 0.0}
        self.last_ms = 0
        self.stop_evt = threading.Event()

    def put(self, lines: list):
        size = sum(len(x) for x in lines) + 64 * len(lines)   # + python object overhead
        with self.lock:
            if self.buffered_bytes + size > self.max_bytes:
                self.stats["db_drops"] += len(lines)
                return
            self.buffered += len(lines)
            self.buffered_bytes += size
        self.q.put(lines)

    def _ids(self, count: int):
        """Unique, roughly time ordered ids: ms << 22 | worker << 16 | counter."""
        ms = max(int(time.time() * 1000), self.last_ms + 1)
        out = []
        i = 0
        while i < count:
            chunk = min(65536, count - i)
            base = (ms << 22) | ((self.idx & 63) << 16)
            out.extend(range(base, base + chunk))
            i += chunk
            ms += 1
        self.last_ms = ms
        return out

    def run(self):
        pending: list = []
        last = time.monotonic()
        backoff = 0.0
        while True:
            timeout = max(0.05, self.flush_s - (time.monotonic() - last))
            try:
                pending.extend(self.q.get(timeout=timeout))
                while len(pending) < self.batch_rows:
                    pending.extend(self.q.get_nowait())
            except queue.Empty:
                pass
            stopping = self.stop_evt.is_set()
            due = len(pending) >= self.batch_rows or time.monotonic() - last >= self.flush_s
            if pending and (due or stopping) and time.monotonic() >= backoff:
                batch = pending[:self.batch_rows * 2]
                ids = self._ids(len(batch))
                body = "\n".join(f'{{"id":{i},' + line[1:] for i, line in zip(ids, batch))
                t0 = time.monotonic()
                try:
                    try:
                        self.ch.insert_json_lines("events", body.encode())
                    except ClickHouseError as ex:
                        if ex.code not in DATA_ERRORS:
                            raise
                        # A row ClickHouse can't parse would otherwise block this batch
                        # (and everything behind it) forever: retry once, skipping bad rows.
                        log.warning("worker %d: ClickHouse rejected a row (%s) - inserting the "
                                    "batch again without the bad rows", self.idx, str(ex)[:160])
                        self.ch.insert_json_lines("events", body.encode(), skip_bad_rows=True)
                        self.stats["rejected_batches"] += 1
                    del pending[:len(batch)]
                    size = sum(len(x) for x in batch) + 64 * len(batch)
                    with self.lock:
                        self.buffered -= len(batch)
                        self.buffered_bytes = max(0, self.buffered_bytes - size)
                    self.stats["inserted"] += len(batch)
                    self.stats["last_insert_ms"] = int((time.monotonic() - t0) * 1000)
                    backoff = 0.0
                except ClickHouseError as ex:
                    self.stats["insert_errors"] += 1
                    self.stats["last_error"] = str(ex)[:300]
                    self.stats["last_error_ts"] = time.time()
                    log.error("worker %d: insert failed (%d rows kept): %s",
                              self.idx, len(pending), str(ex)[:200])
                    backoff = time.monotonic() + 2
                last = time.monotonic()
            self.stats["buffered"] = self.buffered
            self.stats["buffered_mb"] = round(self.buffered_bytes / 1048576, 1)
            if stopping and (not pending or time.monotonic() >= backoff + 10):
                return


def _state_file(cfg, idx):
    return Path(cfg["state_dir"]) / f"templates-w{idx}.json"


def _load_state(dec: Decoder, cfg: dict, idx: int, n: int):
    """Load saved templates of all workers, keep the routers that hash to us."""
    d = Path(cfg["state_dir"])
    if not d.is_dir():
        return

    def mine(exp):
        return zlib.crc32(exp.encode()) % n == idx
    for f in d.glob("templates-w*.json"):
        try:
            dec.import_state(json.loads(f.read_text()), accept=mine)
        except (OSError, ValueError, KeyError, TypeError) as ex:
            log.warning("cannot load %s: %s", f, ex)


def _save_state(dec: Decoder, cfg: dict, idx: int):
    p = _state_file(cfg, idx)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as fh:
            json.dump(dec.export_state(), fh)
        tmp.replace(p)
        dec.dirty = False
    except OSError as ex:
        log.warning("cannot save template state: %s", ex)


def worker_main(idx: int, n: int, cfg: dict, in_q, stats_q):
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    logging.basicConfig(level=cfg["log_level"], format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    dec = Decoder(cfg.get("limits"))
    _load_state(dec, cfg, idx, n)
    # loaded templates are written back immediately so a second restart keeps them
    _save_state(dec, cfg, idx)
    writer = Writer(idx, cfg)
    writer.start()
    dumps = json.dumps
    last_stats = last_save = last_tpl = time.monotonic()
    running = True
    while running:
        try:
            batch = in_q.get(timeout=0.25)
        except queue.Empty:
            batch = None
        if batch == "STOP":
            running = False
            batch = None
        if batch:
            lines = []
            for kind, exp, rx, data, port in batch:
                try:
                    if kind == "f":
                        for rec in dec.parse(data, exp, port):
                            lines.append(dumps(hsl_row(rec, exp, rx), separators=(",", ":")))
                    else:
                        st = dec._stat(exp)
                        if st is None:
                            continue
                        st["syslog"] += 1
                        st["last_seen"] = rx
                        lines.append(dumps(syslog_row(data, exp, rx), separators=(",", ":")))
                except Exception as ex:     # one bad packet must never stop the decoder
                    st = dec.exporters.get(exp)
                    if st is not None:
                        st["errors"] += 1
                        st["last_error"] = f"{type(ex).__name__}: {ex}"[:200]
            if lines:
                writer.put(lines)
        now = time.monotonic()
        if now - last_stats >= 2 or not running:
            stats_q.put(("worker", idx, {
                "exporters": dec.exporters, "writer": dict(writer.stats),
                "rejected_exporters": dec.rejected_exporters,
                "queue": _qsize(in_q),
            }))
            last_stats = now
        if now - last_tpl >= 10 or not running:
            snap = dec.templates_snapshot()
            snap["options"] = dec.options_log[-50:]
            stats_q.put(("templates", idx, snap))
            last_tpl = now
        if (dec.dirty and now - last_save >= 30) or not running:
            _save_state(dec, cfg, idx)
            last_save = now
    writer.stop_evt.set()
    writer.join(timeout=15)


def _qsize(q):
    try:
        return q.qsize()
    except NotImplementedError:   # macOS
        return None
