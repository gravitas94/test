#!/usr/bin/env python3
"""
HSL simulator - sends Zone-Based-Firewall style High Speed Logging records
(NetFlow v9 or IPFIX) plus option templates, like an IOS XE SD-WAN edge would.
Use it to test the collector without a router.

  python3 tools/hsl_simulator.py --host 127.0.0.1 --port 2055 --rate 50
  python3 tools/hsl_simulator.py --ipfix --source 127.0.0.2 --count 500
"""
import argparse
import random
import socket
import struct
import time

# data template: (field id, length)
DATA_FIELDS = [(8, 4), (12, 4), (7, 2), (11, 2), (4, 1), (10, 4), (14, 4), (233, 1),
               (33002, 2), (51, 4), (231, 8), (232, 8), (298, 8), (299, 8), (234, 4),
               (323, 8)]
T_DATA, T_IF, T_CLASS = 260, 261, 262
IFACES = {1: "GigabitEthernet0/0/0", 2: "GigabitEthernet0/0/1", 7: "Tunnel1"}
CLASSES = {1001: "seq-1-cm_ZBFW-allow-web", 1002: "seq-2-cm_ZBFW-deny-telnet",
           1003: "class-default"}
SRC = ["10.10.1.%d" % i for i in range(10, 40)]
DST = ["8.8.8.8", "1.1.1.1", "172.16.5.20", "192.0.2.80", "203.0.113.7", "10.20.0.5"]
PORTS = [(6, 443), (6, 80), (17, 53), (6, 22), (6, 23), (17, 123), (6, 3389), (1, 0)]


def str_field(s, n=32):
    return s.encode()[:n].ljust(n, b"\0")


def ip(s):
    return socket.inet_aton(s)


def pad4(b):
    return b + b"\0" * (-len(b) % 4)


def tpl_v9():
    body = struct.pack("!HH", T_DATA, len(DATA_FIELDS))
    body += b"".join(struct.pack("!HH", f, l) for f, l in DATA_FIELDS)
    tset = struct.pack("!HH", 0, 4 + len(body)) + body
    # options templates: interface (scope ifIndex) -> name ; system scope -> class id / name
    o1 = struct.pack("!HHH", T_IF, 4, 4) + struct.pack("!HH", 2, 4) + struct.pack("!HH", 82, 32)
    o2 = struct.pack("!HHH", T_CLASS, 4, 8) + struct.pack("!HH", 1, 4) + \
        struct.pack("!HHHH", 51, 4, 100, 32)
    obody = pad4(o1 + o2)
    oset = struct.pack("!HH", 1, 4 + len(obody)) + obody
    return [tset, oset]


def tpl_ipfix():
    body = struct.pack("!HH", T_DATA, len(DATA_FIELDS))
    for f, l in DATA_FIELDS:
        if f > 0x7FFF:  # Cisco private id -> enterprise 9
            body += struct.pack("!HHI", 0x8000 | (f & 0x7FFF), l, 9)
        else:
            body += struct.pack("!HH", f, l)
    tset = struct.pack("!HH", 2, 4 + len(body)) + body
    o1 = struct.pack("!HHH", T_IF, 2, 1) + struct.pack("!HHHH", 10, 4, 82, 32)
    o2 = struct.pack("!HHH", T_CLASS, 2, 1) + struct.pack("!HHHH", 51, 4, 100, 32)
    obody = o1 + o2
    oset = struct.pack("!HH", 3, 4 + len(obody)) + obody
    return [tset, oset]


def option_data():
    ifs = b"".join(struct.pack("!I", k) + str_field(v) for k, v in IFACES.items())
    cls = b"".join(struct.pack("!II", 0, k) + str_field(v) for k, v in CLASSES.items())
    return [struct.pack("!HH", T_IF, 4 + len(pad4(ifs))) + pad4(ifs),
            struct.pack("!HH", T_CLASS, 4 + len(pad4(cls))) + pad4(cls)]


def option_data_ipfix():
    ifs = b"".join(struct.pack("!I", k) + str_field(v) for k, v in IFACES.items())
    cls = b"".join(struct.pack("!I", k) + str_field(v) for k, v in CLASSES.items())
    return [struct.pack("!HH", T_IF, 4 + len(ifs)) + ifs,
            struct.pack("!HH", T_CLASS, 4 + len(cls)) + cls]


def record():
    proto, dport = random.choice(PORTS)
    denied = dport in (23, 3389) or random.random() < 0.08
    event = 3 if denied else random.choice([1, 2, 2])
    cls = 1002 if denied else random.choice([1001, 1003])
    ib, rb = (0, 0) if event != 2 else (random.randint(200, 900000), random.randint(200, 9000000))
    ip_, rp = (1, 0) if event != 2 else (random.randint(2, 900), random.randint(2, 9000))
    return (ip(random.choice(SRC)) + ip(random.choice(DST)) +
            struct.pack("!HHBIIBHIQQQQIQ", random.randint(1024, 65000) if proto != 1 else 0,
                        dport, proto, 1, 7, event, 0, cls, ib, rb, ip_, rp, 10,
                        int(time.time() * 1000)))


class Router:
    def __init__(self, ip, ipfix, domain=1):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        if ip:
            self.sock.bind((ip, 0))
        self.ipfix, self.domain, self.seq, self.last_tpl = ipfix, domain, 0, 0.0

    def packet(self, n, with_tpl=False):
        sets = []
        if with_tpl or time.time() - self.last_tpl > 10:   # template refresh every 10 s
            sets += tpl_ipfix() if self.ipfix else tpl_v9()
            sets += option_data_ipfix() if self.ipfix else option_data()
            self.last_tpl = time.time()
        recs = b"".join(record() for _ in range(n))
        if not self.ipfix:
            recs = pad4(recs)
        sets.append(struct.pack("!HH", T_DATA, 4 + len(recs)) + recs)
        body = b"".join(sets)
        if self.ipfix:
            hdr = struct.pack("!HHIII", 10, 16 + len(body), int(time.time()), self.seq, self.domain)
            self.seq += n + (len(IFACES) + len(CLASSES) if len(sets) > 1 else 0)
        else:
            hdr = struct.pack("!HHIIII", 9, len(sets), int(time.monotonic() * 1000) & 0xFFFFFFFF,
                              int(time.time()), self.seq, self.domain)
            self.seq += 1
        return hdr + body


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=2055)
    ap.add_argument("--source", default=None, help="bind to this local IP (single router)")
    ap.add_argument("--routers", type=int, default=1,
                    help="simulate N routers from 127.0.1.1 .. 127.0.1.N (Linux; on macOS add "
                         "loopback aliases first: sudo ifconfig lo0 alias 127.0.1.X)")
    ap.add_argument("--rate", type=float, default=20, help="total records per second")
    ap.add_argument("--count", type=int, default=0, help="stop after N records (0 = forever)")
    ap.add_argument("--per-packet", type=int, default=19, help="records per packet (19 ~ 1400 bytes)")
    ap.add_argument("--ipfix", action="store_true")
    a = ap.parse_args()
    if a.routers > 1:
        routers = [Router(f"127.0.{1 + i // 250}.{1 + i % 250}", a.ipfix) for i in range(a.routers)]
    else:
        routers = [Router(a.source, a.ipfix)]
    for r in routers:                      # templates first, like a router after boot
        r.sock.sendto(r.packet(1, True), (a.host, a.port))
    time.sleep(0.5)
    sent, t0, i = len(routers), time.time(), 0
    per_pkt = max(1, a.per_packet if a.rate >= a.per_packet * 5 else int(a.rate // 5) or 1)
    report = time.time()
    while not a.count or sent < a.count:
        n = per_pkt if not a.count else min(per_pkt, a.count - sent)
        r = routers[i % len(routers)]
        i += 1
        r.sock.sendto(r.packet(n), (a.host, a.port))
        sent += n
        ahead = sent / a.rate - (time.time() - t0)
        if ahead > 0:
            time.sleep(ahead)
        if time.time() - report >= 5:
            print(f"{sent} records, {sent / (time.time() - t0):.0f}/s", flush=True)
            report = time.time()
    print(f"sent {sent} records from {len(routers)} router(s) in {time.time() - t0:.1f}s "
          f"({sent / max(time.time() - t0, 1e-6):.0f}/s)")


if __name__ == "__main__":
    main()
