#!/usr/bin/env python3
"""Container/systemd health probe: exit 0 when the collector is healthy.

Unhealthy only when /api/health?strict=1 answers 503 (process down, database
unreachable or failing, disk below the minimum, certificate expired) or the
web server is down. A 401 (health endpoint not public) still proves it is up.
"""
import os
import ssl
import sys
import urllib.error
import urllib.request

tls = os.environ.get("HSL_TLS", "on").lower() not in ("off", "0", "no")
port = os.environ.get("HSL_WEB_PORT", "8443")
url = f"{'https' if tls else 'http'}://127.0.0.1:{port}/api/health?strict=1"
# probing our own server on 127.0.0.1: its certificate is for the public host name
ctx = ssl._create_unverified_context() if tls else None  # nosec B323
try:
    with urllib.request.urlopen(url, timeout=4, context=ctx) as r:  # nosec B310 - fixed local URL
        sys.exit(0 if r.status == 200 else 1)
except urllib.error.HTTPError as ex:
    sys.exit(0 if ex.code == 401 else 1)
except Exception:
    sys.exit(1)
