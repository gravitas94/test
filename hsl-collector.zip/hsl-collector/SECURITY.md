# Security assessment — HSL Collector

**Version assessed:** 2.2.0  **Fixed in:** 2.3.0  **Date:** 1 November 2026

## Verdict

After the fixes in 2.3.0, the collector is **ready for a production pilot on a
management network**, provided the deployment checklist below is followed.

It is **not** yet suitable for:

- exposing the GUI to the internet;
- environments that require single sign-on, MFA or high availability;
- use as evidence-grade logging without the network controls described
  under *Residual risks*.

Before production, validate it with real routers. All tests so far used a
traffic simulator.

## Scope and method

| What | How |
|---|---|
| Static analysis | bandit 1.x on all Python code |
| Dependencies | pip-audit against the PyPI advisory database |
| Manual review | UDP decoding, web API, authentication and sessions, SQL building, GUI rendering, deployment files |
| Fuzzing | ~50,000 mutated NetFlow v9 / IPFIX / syslog packets per run against the decoder |
| Live attacks | crafted packets, template floods, spoofed senders, XSS and CSV payloads, brute force, oversized requests; run against a real ClickHouse 25.8 |
| Browser tests | Chromium: login, forced password change, CSP violations, XSS rendering |
| Regression | 100 simulated routers at 10k and 20k records/s with all protections on: 0 lost |

Semgrep could not be used: its rule registry was not reachable from the test
environment. The Docker image and the systemd unit were validated, but not run.

This is a code-level assessment by the developer, not an independent
penetration test.

## Findings

Severity is rated by impact and by who can trigger it. "Unauthenticated" means
anyone who can send UDP to the collector's ports.

| ID | Severity | Finding | Status |
|---|---|---|---|
| C1 | **Critical** | **One crafted UDP packet stopped the whole collector.** A template giving a counter field an unusual length made row building raise an exception in the decoder process; the supervisor then exited. Unauthenticated. | Fixed: every column is forced to its type and range; each packet is isolated with its own error handling. |
| C2 | **Critical** | **One crafted UDP packet stopped all database writes.** A text value in a numeric column made ClickHouse reject the batch, which was retried forever while new events piled up and were then dropped. Unauthenticated. | Fixed: values are validated before insert; if ClickHouse still rejects rows, the batch is re-sent once with bad rows skipped. |
| H1 | High | **Memory exhaustion.** ~100 MB of forged template packets grew a decoder to 1.5 GB and the collector was killed. Templates, export streams, routers and learned names were unbounded. Unauthenticated. | Fixed: limits per router (16 streams, 256 templates, 256 fields per template, 20,000 names) and per decoder (2,000 routers). The same flood now uses no extra memory. |
| H2 | High | **No restriction on senders.** Anyone reaching UDP 2055/5514 could inject fake firewall events or flood the collector. | Mitigated: access list of authorized routers (GUI *Access list* tab since 2.4, or fixed `--allow` entries), enforced before decoding; blocked senders are counted and shown. Residual risk: UDP source spoofing (see below). |
| H3 | High | **Default `admin/admin` was usable indefinitely**, including over the API with Basic auth. | Fixed: nothing works until the default password is changed; weak passwords (common words, containing the username, too few distinct characters) are refused. |
| M1 | Medium | No browser security headers: no Content-Security-Policy, clickjacking protection or MIME sniffing protection. | Fixed: strict CSP (scripts allowed only by hash), `X-Frame-Options: DENY`, `nosniff`, `Referrer-Policy`, `Permissions-Policy`, `no-store` caching, HSTS under HTTPS. |
| M2 | Medium | **CSV formula injection.** Syslog text (unauthenticated) and router names were exported unchanged, so a cell like `=HYPERLINK(...)` would run in Excel. | Fixed: cells starting with `= + - @` (or tab/CR) are prefixed with `'` in both CSV exports. |
| M3 | Medium | The unauthenticated `/api/health` exposed internals: disk paths, database error text, worker statistics. | Fixed: without login it returns only `status` and `problems`. |
| M4 | Medium | **Brute-force protection was per address only.** From the collector host, `X-Forwarded-For` could fake a new address for each attempt; password hashing was unbounded under load. | Fixed: extra lockout per username; proxy headers ignored unless `--trusted-proxies` is set; at most 4 concurrent password checks; caps on sessions and throttle state. |
| M5 | Medium | **Deployment defaults:** the container ran as root with a writable filesystem; the ClickHouse password defaulted to `change-me`; the collector used the ClickHouse admin account. | Fixed: non-root user, read-only filesystem, no capabilities, `no-new-privileges`; compose refuses to start without passwords; least-privilege `hsl_app` account (own database only, verified). |
| M6 | Medium | **ClickHouse exposed on the network in the Mac instructions** (`-p 8123:8123` binds all interfaces) with the password `hsl`. | Fixed in the docs (`-p 127.0.0.1:8123:8123`). **Existing installs: recreate the container** (see checklist). |
| L1 | Low | No HTTPS option: passwords and session cookies crossed the network in clear text. | Fixed: since 2.5 HTTPS-only (8443, HTTP only redirects), TLS 1.2+, certificate management with validation in the GUI, Secure cookie and HSTS. |
| L2 | Low | Router names accepted control characters; a newline broke CSV rows. | Fixed: control characters removed, max 128 characters (also for reverse-DNS names). |
| L3 | Low | Log injection: a username with a newline could forge log lines. | Fixed: untrusted text is sanitised before logging. |
| L4 | Low | Unlimited request bodies on JSON endpoints. | Fixed: 64 KB (6 MB for router-name import); larger requests get 413 before being read. |
| L5 | Low | Full database error text (with server details) was returned to the browser. | Fixed: first line only to the client; details go to the log. |
| L6 | Low | Web queries ran with write permission and no limits. | Fixed: web connection is read-only (`readonly=2`, verified), 60 s and 4 GB per query. |
| L7 | Low | Template state files and the state directory were world-readable. | Fixed: files 0600, directory 0700. |
| L8 | Low | Dependencies were unpinned (`>=`). | Fixed: pinned; pip-audit reports no known vulnerabilities. |
| L9 | Low | `Server: uvicorn` banner disclosed the software. | Fixed: header removed. |
| L10 | Low | The systemd unit had no sandboxing and kept the database password in the unit file. | Fixed: unprivileged sandbox (no capabilities, read-only system, syscall filter); secrets in a 0600 env file. |
| I1 | Info | **SQL injection: not found.** All user input reaches ClickHouse as typed, bound query parameters. bandit's B608 warnings were reviewed one by one and annotated. | No change needed |
| I2 | Info | **Cross-site scripting: not found.** All network- and user-supplied text is HTML-escaped; verified in a browser with `<img onerror>` / `<script>` payloads. CSP (M1) now adds a second layer. | No change needed |
| I3 | Info | **CSRF: not found.** Cookies are `SameSite=Strict` and every state-changing request needs a custom header that other sites cannot send. | No change needed |

### Evidence (before → after)

| Test | 2.2.0 | 2.3.0 |
|---|---|---|
| Fuzzer, 60 s | 232 uncaught exceptions | 0 |
| One crafted packet (C1) | collector exited | ignored, counted as decode error |
| One poison packet + 2,500 normal records (C2) | 0 stored, all inserts failing | 2,502 stored, 0 errors |
| 20,000 forged template packets (H1) | 1.5 GB, collector killed | memory flat, flood refused by limits |
| 12 logins with spoofed X-Forwarded-For (M4) | 12× 401, never locked | locked after 5 |
| bandit medium/high | 15 | 0 (each remaining warning reviewed and annotated) |

## Residual risks

1. **UDP is unauthenticated by design.** NetFlow/IPFIX/syslog have no sender
   authentication, and source addresses can be spoofed. The allowlist only
   stops senders outside the listed networks. Anyone able to spoof an address
   inside them can inject fake events. Mitigation: deliver HSL over a dedicated
   management VPN/VRF, with ACLs on the path so only router interfaces can
   reach udp/2055 and udp/5514; uRPF where possible. The access list
   only stops senders whose addresses are not on it. Treat the logs as
   operational data, not tamper-proof evidence.
2. **No high availability.** Events sent while the collector restarts are lost
   (UDP is not retransmitted). Run it under systemd/Docker with automatic
   restart, and back up ClickHouse if the logs matter for audits.
3. **Local accounts only.** No SSO (SAML/OIDC), LDAP/RADIUS or MFA; sessions
   live in memory (a restart signs everyone out). Restrict GUI access with
   firewall rules to admin networks.
4. **Limited audit trail.** Logins, failed logins and user changes are logged;
   who searched or exported what is not. Forward the service log to your SIEM.
5. **ClickHouse and the OS** are outside this code. Keep them patched; the
   compose file uses the 25.8 LTS tag, so pull updates regularly.
6. **Not independently tested.** For a regulated environment, commission an
   external penetration test of the deployed system.

## Deployment checklist

1. Use a Linux VM (not a laptop) on the management network.
2. `cp .env.example .env && chmod 600 .env`; set two random passwords.
3. Install a certificate from your internal CA: GUI *Certificate* tab →
   certificate request (recommended) or import. The GUI is HTTPS-only on 8443;
   8080 only redirects.
4. Firewall the host: udp/2055 and udp/5514 only from router networks; tcp/8443
   and tcp/8080 only from admin networks; tcp/8123 never from outside the host.
5. Start, sign in as `admin/admin`, set a strong password, then create named
   personal accounts (viewers for read-only staff). Don't share the admin account.
6. **Access list:** add your routers (or let them send for a day and use
   *Allow all shown*), check the list, then **Enforce access list**.
7. Monitor `/api/health?strict=1` (HTTP 503 = critical) and forward the
   service log to your SIEM.
8. Watch the Routers page for the first days: *Lost* and *Errors* should stay
   at 0, and the Access list should show no unexpected blocked senders.
9. After updates, re-run `pytest`, `bandit` and `pip-audit` (see README).

**Existing Mac test setup:** the ClickHouse container created earlier listens
on all interfaces with password `hsl`. Recreate it bound to localhost:

```bash
docker rm -f clickhouse
docker run -d --name clickhouse -p 127.0.0.1:8123:8123 --ulimit nofile=262144:262144 \
  -e CLICKHOUSE_PASSWORD=hsl clickhouse/clickhouse-server:25.8
```

(This removes the test data stored in that container.)
