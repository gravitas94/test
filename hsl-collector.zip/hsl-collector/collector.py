#!/usr/bin/env python3
"""
HSL Collector v2 - Cisco SD-WAN High Speed Logging collector with web GUI,
built for 100+ routers.

  receiver process -> N decoder processes -> ClickHouse <- web GUI / REST API
"""
from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import io
import ipaddress
import re
import urllib.parse
import json
import logging
import multiprocessing as mp
import os
import queue
import threading
import time
import asyncio
import contextlib
from contextlib import asynccontextmanager
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from starlette.concurrency import run_in_threadpool

from hslc import __version__
from hslc.clickhouse import ClickHouse, ClickHouseError, ensure_schema
from hslc.decoder import PROTO_BY_NAME, PROTOS
from hslc.acl import AclError, AclStore, parse_network
from hslc.auth import AuthError, Sessions, Throttle, UserStore, clean
from hslc.maintenance import DiskGuard, RouterNames
from hslc.tls import KEY_TYPES, CertError, TlsManager
from hslc.pipeline import receiver_main, worker_main

log = logging.getLogger("hsl-collector")
BASE_DIR = Path(__file__).resolve().parent
ID_OVERLAP = 5000 << 22          # live tail re-reads the last ~5 s to catch late inserts

SELECT_COLS = """toString(id) AS sid, toUnixTimestamp64Milli(ts) AS ts_ms,
  toUnixTimestamp64Milli(rx) AS rx_ms, exporter, kind, event, proto, src_ip, src_port,
  dst_ip, dst_port, bytes, packets, in_if, out_if, in_if_name, out_if_name, class_name,
  vrf, xlate_src_ip, xlate_src_port, xlate_dst_ip, xlate_dst_port, ext_event, severity,
  message, extra"""
JSON_SETTINGS = {"output_format_json_quote_64bit_integers": 0}


# ---------------------------------------------------------------- pipeline supervisor
class Supervisor:
    """Starts the receiver + decoder processes and aggregates their statistics."""

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.ctx = mp.get_context("spawn")
        self.n = cfg["workers"]
        self.queues = [self.ctx.Queue(maxsize=cfg["worker_queue"]) for _ in range(self.n)]
        self.stats_q = self.ctx.Queue()
        self.acl_q = self.ctx.Queue()        # access list updates for the receiver
        self.tls_summary = None              # set by the web app: certificate status
        self.procs: list = []
        self.rx: dict = {}
        self.workers: dict = {}
        self.templates: dict = {}
        self.rates: dict = {}            # exporter -> (t, records, rate)
        self.lock = threading.Lock()
        self.started = time.time()
        self.stopping = False                # shutdown in progress: watchdog stands down

    def start(self):
        for i in range(self.n):
            p = self.ctx.Process(target=worker_main, name=f"hsl-decoder-{i}",
                                 args=(i, self.n, self.cfg, self.queues[i], self.stats_q),
                                 daemon=True)
            p.start()
            self.procs.append(p)
        p = self.ctx.Process(target=receiver_main, name="hsl-receiver",
                             args=(self.cfg, self.queues, self.stats_q, self.acl_q), daemon=True)
        p.start()
        self.receiver = p
        threading.Thread(target=self._collect, daemon=True, name="stats").start()
        threading.Thread(target=self._watchdog, daemon=True, name="watchdog").start()

    def stop(self):
        self.stopping = True
        if self.receiver.is_alive():
            self.receiver.terminate()
        for q in self.queues:
            try:
                q.put("STOP", timeout=1)
            except queue.Full:
                pass
        for p in self.procs:
            p.join(timeout=20)
            if p.is_alive():
                p.terminate()

    def _watchdog(self):
        while True:
            time.sleep(5)
            if self.stopping:
                return
            for p in self.procs + [self.receiver]:
                if not p.is_alive() and p.exitcode not in (0, None):
                    log.error("process %s died (exit %s) - exiting so the service manager "
                              "can restart the collector", p.name, p.exitcode)
                    os._exit(1)

    def _collect(self):
        while True:
            kind, idx, data = self.stats_q.get()
            with self.lock:
                if kind == "rx":
                    self.rx = data
                elif kind == "worker":
                    self.workers[idx] = data
                    now = time.time()
                    for exp, st in data["exporters"].items():
                        recs = st["records"] + st.get("syslog", 0)
                        prev = self.rates.get(exp)
                        if prev and now > prev[0]:
                            rate = (recs - prev[1]) / (now - prev[0])
                            self.rates[exp] = (now, recs, max(0.0, rate))
                        else:
                            self.rates[exp] = (now, recs, 0.0)
                elif kind == "templates":
                    self.templates[idx] = data

    def exporters(self) -> list:
        with self.lock:
            out = []
            for idx, w in self.workers.items():
                for exp, st in w["exporters"].items():
                    d = dict(st)
                    d["worker"] = idx
                    d["rate"] = round(self.rates.get(exp, (0, 0, 0.0))[2], 1)
                    out.append(d)
            return sorted(out, key=lambda x: -x["rate"])

    def push_acl(self, acl: dict):
        self.cfg["acl"] = acl
        self.acl_q.put(acl)

    def unknown_senders(self) -> list:
        with self.lock:
            return [{"ip": ip, "packets": n, "first_seen": f, "last_seen": l, "blocked": b}
                    for ip, n, f, l, b in self.rx.get("unknown", [])]

    def health(self) -> dict:
        with self.lock:
            ws = [{"worker": i, "queue": w["queue"], **w["writer"]}
                  for i, w in sorted(self.workers.items())]
            exps = [st for w in self.workers.values() for st in w["exporters"].values()]
            return {
                "workers": ws, "rx": dict(self.rx),
                "seq_lost_packets": sum(e["lost"] for e in exps if e["lost_unit"] == "packets"),
                "seq_lost_records": sum(e["lost"] for e in exps if e["lost_unit"] == "records"),
                "no_template": sum(e["no_template"] for e in exps),
                "decode_errors": sum(e["errors"] for e in exps),
                "queue_drops": self.rx.get("queue_drops", 0),
                "rejected_packets": self.rx.get("rejected", 0),
                "acl_enforce": self.rx.get("acl_enforce"),
                "acl_entries": self.rx.get("acl_entries"),
                "unlisted_senders": len(self.rx.get("unknown", [])),
                "rejected_exporters": sum(w.get("rejected_exporters", 0)
                                          for w in self.workers.values()),
                "rejected_batches": sum(w.get("rejected_batches", 0) for w in ws),
                "kernel_drops": self.rx.get("kernel_drops"),
                "db_drops": sum(w["db_drops"] for w in ws),
                "insert_errors": sum(w["insert_errors"] for w in ws),
                "buffered": sum(w["buffered"] for w in ws),
                "buffered_mb": round(sum(w.get("buffered_mb", 0) for w in ws), 1),
                "inserts_failing": any(w["insert_errors"] and w.get("last_error_ts", 0) > time.time() - 30
                                       and w["buffered"] for w in ws),
                "inserted": sum(w["inserted"] for w in ws),
                "last_db_error": next((w["last_error"] for w in ws if w["last_error"]), None),
                "processes_alive": all(p.is_alive() for p in self.procs + [self.receiver]),
                "tls": self.tls_summary() if self.tls_summary else None,
            }

    def templates_snapshot(self) -> dict:
        with self.lock:
            tpls, names, opts = [], [], []
            for d in self.templates.values():
                tpls += d["templates"]
                names += d["names"]
                opts += d.get("options", [])
            return {"templates": sorted(tpls, key=lambda x: (x["exporter"], x["id"])),
                    "names": names[:5000], "options": opts[-100:]}


# ---------------------------------------------------------------- query helpers
def build_where(p: dict, names: "RouterNames | None" = None) -> tuple[str, dict]:
    w, a = [], {}

    def like(v):
        return v.replace("%", "\\%").replace("_", "\\_").replace("*", "%")

    try:
        if p.get("since"):
            w.append("ts >= fromUnixTimestamp64Milli({since:Int64}, 'UTC')")
            a["since"] = int(float(p["since"]) * 1000)
        if p.get("until"):
            w.append("ts <= fromUnixTimestamp64Milli({until:Int64}, 'UTC')")
            a["until"] = int(float(p["until"]) * 1000)
        if p.get("after_id"):
            w.append("id > {after_id:UInt64} AND ts >= now64(3) - INTERVAL 15 MINUTE")
            a["after_id"] = max(0, int(p["after_id"]) - ID_OVERLAP)
        if p.get("before"):
            b_ts, b_id = p["before"].split(":")
            w.append("(ts, id) < (fromUnixTimestamp64Milli({b_ts:Int64}, 'UTC'), {b_id:UInt64})")
            a["b_ts"], a["b_id"] = int(b_ts), int(b_id)
        if p.get("proto"):
            pr = p["proto"].strip().lower()
            w.append("proto = {proto:UInt8}")
            a["proto"] = int(PROTO_BY_NAME.get(pr, pr))
        if p.get("port"):
            w.append("(src_port = {port:UInt16} OR dst_port = {port:UInt16})")
            a["port"] = int(p["port"])
    except ValueError as ex:
        raise ValueError(f"bad filter value: {ex}")
    for key in ("exporter", "event", "kind"):
        if p.get(key):
            w.append(f"{key} = {{{key}:String}}")
            a[key] = p[key]
    for key, col in (("src", "src_ip"), ("dst", "dst_ip")):
        if p.get(key):
            v = p[key].strip()
            w.append(f"{col} LIKE {{{key}:String}}" if "*" in v else f"{col} = {{{key}:String}}")
            a[key] = like(v) if "*" in v else v
    if p.get("ip"):
        v = p["ip"].strip()
        if "*" in v:
            w.append("(src_ip LIKE {ip:String} OR dst_ip LIKE {ip:String})")
            a["ip"] = like(v)
        else:
            w.append("(src_ip = {ip:String} OR dst_ip = {ip:String})")
            a["ip"] = v
    if p.get("q"):
        text = ("positionCaseInsensitive(concat(class_name, ' ', in_if_name, ' ', out_if_name, "
                "' ', message, ' ', extra, ' ', src_ip, ' ', dst_ip, ' ', xlate_src_ip, ' ', "
                "xlate_dst_ip, ' ', exporter), {q:String}) > 0")
        ips = names.match(p["q"]) if names else []
        if ips:                                  # router hostname match
            text = f"({text} OR exporter IN {{qips:Array(String)}})"
            a["qips"] = ch_array(ips)
        w.append(text)
        a["q"] = p["q"]
    return (" WHERE " + " AND ".join(w)) if w else "", a


def ch_array(values) -> str:
    """Python strings -> ClickHouse Array(String) parameter literal."""
    return "[" + ",".join("'" + v.replace("\\", "\\\\").replace("'", "\\'") + "'"
                          for v in values) + "]"


def _ep(ip, port):
    if not ip:
        return "?"
    if not port:
        return ip
    return f"[{ip}]:{port}" if ":" in ip else f"{ip}:{port}"


def to_item(r: dict, names: "RouterNames | None" = None) -> dict:
    extra = {}
    if r.get("extra"):
        try:
            extra = json.loads(r["extra"])
        except ValueError:
            extra = {"extra": r["extra"]}
    proto = r["proto"] or None
    if r["kind"] == "syslog":
        summary = r["message"]
    else:
        parts = [f"{PROTOS.get(proto, proto or '')} {_ep(r['src_ip'], r['src_port'])} -> "
                 f"{_ep(r['dst_ip'], r['dst_port'])}".strip()]
        if r["in_if_name"] or r["out_if_name"]:
            parts.append(f"{r['in_if_name'] or r['in_if']} -> {r['out_if_name'] or r['out_if']}")
        if r["class_name"]:
            parts.append(f"class={r['class_name']}")
        if r["xlate_src_ip"] or r["xlate_dst_ip"]:
            parts.append(f"nat {_ep(r['xlate_src_ip'], r['xlate_src_port'])} -> "
                         f"{_ep(r['xlate_dst_ip'], r['xlate_dst_port'])}")
        for k, v in extra.items():
            if k.endswith("_name"):
                parts.append(f"{k[:-5].removesuffix('_id')}={v}")
        if r["vrf"]:
            parts.append(f"vrf={r['vrf']}")
        if r["ext_event"]:
            parts.append(f"ext_event={r['ext_event']}")
        summary = " | ".join(parts)
    data = {k: v for k, v in r.items()
            if k not in ("sid", "ts_ms", "rx_ms", "extra", "exporter", "kind")
            and v not in ("", 0, -1, None)}
    data.update(extra)
    if r["rx_ms"] != r["ts_ms"]:
        data["received"] = r["rx_ms"] / 1000
    return {
        "id": r["sid"], "ts": r["ts_ms"] / 1000, "ts_ms": r["ts_ms"], "exporter": r["exporter"],
        "kind": r["kind"], "event": r["event"], "proto": proto,
        "proto_name": PROTOS.get(proto, proto), "src_ip": r["src_ip"] or None,
        "src_port": r["src_port"] or None, "dst_ip": r["dst_ip"] or None,
        "dst_port": r["dst_port"] or None,
        "bytes": r["bytes"] if r["kind"] == "hsl" else None,
        "packets": r["packets"] if r["kind"] == "hsl" else None,
        "summary": summary, "data": data,
        "router_name": names.get(r["exporter"]) if names else None,
    }


# ---------------------------------------------------------------- web app
MAX_BULK = 5000


def acl_lines(text: str) -> list:
    """'10.1.2.3, ams-01' / '10.1.0.0/16 Amsterdam' / '10.1.2.3' per line -> [(net, desc)]."""
    items = []
    for line in text.splitlines()[:MAX_BULK]:
        line = line.strip().lstrip("\ufeff")
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"\s*[,;\t]\s*|\s+", line, maxsplit=1)
        items.append((parts[0], parts[1] if len(parts) > 1 else ""))
    return items


def _is_ip(v: str) -> bool:
    try:
        ipaddress.ip_address(v)
        return True
    except ValueError:
        return False


def csv_safe(expr: str, alias: str | None = None) -> str:
    """SQL: prefix text cells that a spreadsheet would run as a formula with '.
    Syslog messages and names come from the network or users (CSV/formula injection)."""
    alias = alias or expr
    return (rf"if(substring({expr}, 1, 1) IN ('=', '+', '-', '@', '\t', '\r'), "
            rf"concat('\'', {expr}), {expr}) AS {alias}")


def csv_cell(v: str) -> str:
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


def strip_userinfo(url: str) -> str:
    u = urllib.parse.urlsplit(url)
    return u._replace(netloc=u.hostname + (f":{u.port}" if u.port else "")).geturl() if u.hostname else url


def overall_status(h: dict, disk: dict, detail=False):
    """ok / warning / critical for dashboards and monitoring."""
    crit, warn = [], []
    if not h.get("processes_alive", True):
        crit.append("a collector process has stopped")
    if h.get("inserts_failing"):
        crit.append(f"database inserts failing, {h['buffered']} rows buffered")
    if h.get("database") not in (None, "ok"):
        crit.append("database unreachable")
    if disk.get("free_pct") is not None:
        if disk["free_pct"] < disk["min_free_pct"]:
            crit.append(f"disk {disk['free_pct']}% free - oldest days are being deleted")
        elif disk["free_pct"] < disk["warn_free_pct"]:
            warn.append(f"disk {disk['free_pct']}% free")
        if disk.get("days_until_full") is not None and disk["days_until_full"] < 3:
            warn.append(f"disk full in about {disk['days_until_full']} days")
        if not disk.get("retention_fits", True):
            warn.append("disk too small for the configured retention")
    t = h.get("tls")
    if t:
        if t.get("expired"):
            crit.append("HTTPS certificate has expired")
        elif t.get("days_left") is not None and t["days_left"] < 30:
            warn.append(f"HTTPS certificate expires in {t['days_left']} days")
        if t.get("self_signed"):
            warn.append("HTTPS uses a self-signed certificate - install a CA-signed one")
    if disk.get("error"):
        warn.append("disk check failed: " + disk["error"][:100])
    if h.get("acl_enforce") is True and not h.get("acl_entries"):
        crit.append("access list is enforced but empty - all logs are blocked")
    elif h.get("acl_enforce") is False:
        warn.append("access list not enforced - logs accepted from any sender")
    status = "critical" if crit else "warning" if warn else "ok"
    return (status, crit + warn) if detail else status


def create_app(cfg: dict, tls: "TlsManager | None" = None) -> FastAPI:
    ch = ClickHouse(cfg["ch_url"], cfg["ch_user"], cfg["ch_password"], cfg["ch_database"], timeout=90)
    # Every query from the web side is read-only and bounded in time and memory,
    # so even a logged-in user can't change data or overload ClickHouse through it.
    ch.default_settings = {"readonly": 2, "max_execution_time": 60,
                           "max_memory_usage": 4_000_000_000, "max_threads": 8}
    ch_rw = ClickHouse(cfg["ch_url"], cfg["ch_user"], cfg["ch_password"], cfg["ch_database"], timeout=30)
    acl = AclStore(cfg["state_dir"], cfg["allow_config"])
    cfg["acl"] = acl.effective()
    sup = Supervisor(cfg)
    if tls is not None:
        sup.tls_summary = tls.summary
    acl.listeners.append(sup.push_acl)
    names = RouterNames(ch_rw, cfg["rdns"])
    guard = DiskGuard(ClickHouse(cfg["ch_url"], cfg["ch_user"], cfg["ch_password"],
                                 cfg["ch_database"], timeout=600), cfg)

    def rdns_loop():
        while True:
            time.sleep(15)
            names.resolve_new([e["exporter"] for e in sup.exporters()])

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        try:
            names.load()
        except ClickHouseError as ex:
            log.warning("cannot load router names: %s", ex)
        sup.start()
        guard.start()
        if cfg["rdns"]:
            threading.Thread(target=rdns_loop, daemon=True, name="rdns").start()
        log.info("HSL (NetFlow v9 / IPFIX) on udp/%s:%d, syslog %s, %d decoder processes",
                 cfg["listen"], cfg["flow_port"],
                 f"udp/{cfg['syslog_port']}" if cfg["syslog_port"] else "off", cfg["workers"])
        log.info("web GUI on %s://%s:%d", "http" if tls is None else "https", cfg["web_host"],
                 cfg["web_port"])
        yield
        log.info("shutting down, flushing buffered rows ...")
        sup.stop()

    app = FastAPI(title="HSL Collector", version=__version__, lifespan=lifespan,
                  docs_url="/api/docs", redoc_url=None)

    # ---------------------------------------------------------------- auth
    users = UserStore(cfg["state_dir"])
    sessions = Sessions()
    throttle = Throttle()                                  # per client address
    user_throttle = Throttle(limit=10, base=30, cap=900)   # per username (distributed guessing)
    basic_cache: dict = {}            # sha256(header) -> (user, expires); avoids re-hashing
    COOKIE = "hsl_session"
    public = {"/", "/api/login", "/favicon.ico"}
    PW_CHANGE_PATHS = {"/api/me", "/api/me/password", "/api/logout"}
    if cfg["public_health"]:
        public.add("/api/health")

    def client_ip(request: Request) -> str:
        return request.client.host if request.client else "?"

    async def basic_user(request: Request):
        hdr = request.headers.get("authorization", "")
        if not hdr.lower().startswith("basic "):
            return None
        key = hashlib.sha256(hdr.encode()).hexdigest()
        hit = basic_cache.get(key)
        if hit and hit[1] > time.time() and users.get(hit[0]):
            return hit[0]
        ip = client_ip(request)
        try:
            u, _, pw = base64.b64decode(hdr[6:]).decode().partition(":")
        except Exception:
            return None
        if throttle.check(ip) or user_throttle.check(u.lower()):
            return None
        user = await run_in_threadpool(users.verify, u, pw)
        if user:
            throttle.ok(ip)
            user_throttle.ok(u.lower())
            if len(basic_cache) > 1000:
                basic_cache.clear()
            basic_cache[key] = (user, time.time() + 300)
        else:
            throttle.fail(ip)
            user_throttle.fail(u.lower())
            log.warning("failed basic-auth login for '%s' from %s", clean(u), ip)
        return user

    @app.middleware("http")
    async def authenticate(request: Request, call_next):
        path = request.url.path
        user, via = sessions.get(request.cookies.get(COOKIE)), "session"
        if user is None:
            user, via = await basic_user(request), "basic"
        if user is not None and not users.get(user):          # deleted meanwhile
            user = None
        request.state.user = user
        request.state.role = (users.get(user) or {}).get("role") if user else None
        if path in public:
            return await call_next(request)
        if user is None:
            return JSONResponse({"error": "login required"}, status_code=401)
        # the default password must be changed before anything else is allowed
        if (users.get(user) or {}).get("default_password") and path not in PW_CHANGE_PATHS:
            return JSONResponse({"error": "Change the default password first",
                                 "password_change_required": True}, status_code=403)  # nosec B105 - error message, not a password
        # cookie sessions: state-changing requests must come from our own page
        if via == "session" and request.method not in ("GET", "HEAD", "OPTIONS") \
                and request.headers.get("x-hsl") != "1":
            return JSONResponse({"error": "missing X-HSL header"}, status_code=403)
        return await call_next(request)

    # ---------------------------------------------------------------- headers & limits
    page = (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")
    script_hashes = " ".join(
        "'sha256-" + base64.b64encode(hashlib.sha256(x.encode()).digest()).decode() + "'"
        for x in re.findall(r"<script>(.*?)</script>", page, re.S))
    CSP = ("default-src 'none'; script-src " + script_hashes + "; style-src 'self' 'unsafe-inline'; "
           "img-src 'self' data:; connect-src 'self'; form-action 'self'; base-uri 'none'; "
           "frame-ancestors 'none'")
    CSP_DOCS = ("default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
                "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: "
                "https://fastapi.tiangolo.com; frame-ancestors 'none'")
    BODY_LIMITS = {"/api/routers/import": 6 * 1024 * 1024,
                   "/api/tls/import": 1024 * 1024, "/api/tls/csr/complete": 1024 * 1024}

    @app.middleware("http")
    async def limit_body(request: Request, call_next):
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            limit = BODY_LIMITS.get(request.url.path, 64 * 1024)
            cl = request.headers.get("content-length")
            if cl is None and request.headers.get("transfer-encoding"):
                return JSONResponse({"error": "Content-Length required"}, status_code=411)
            try:
                if cl is not None and int(cl) > limit:
                    return JSONResponse({"error": "request too large"}, status_code=413)
            except ValueError:
                return JSONResponse({"error": "bad Content-Length"}, status_code=400)
        return await call_next(request)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        resp = await call_next(request)
        h = resp.headers
        path = request.url.path
        h["Content-Security-Policy"] = CSP_DOCS if path.startswith("/api/docs") else CSP
        h["X-Content-Type-Options"] = "nosniff"
        h["X-Frame-Options"] = "DENY"
        h["Referrer-Policy"] = "no-referrer"
        h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(), payment=()"
        h["Cross-Origin-Opener-Policy"] = "same-origin"
        h["Cross-Origin-Resource-Policy"] = "same-origin"
        if path.startswith("/api/") or path == "/":
            h["Cache-Control"] = "no-store"
        if request.url.scheme == "https":
            h["Strict-Transport-Security"] = "max-age=31536000"
        return resp

    if cfg["allowed_hosts"]:
        from starlette.middleware.trustedhost import TrustedHostMiddleware
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=cfg["allowed_hosts"])

    def need_admin(request: Request):
        if request.state.role != "admin":
            return JSONResponse({"error": "admin rights required"}, status_code=403)
        return None

    def auth_error(ex: AuthError):
        return JSONResponse({"error": str(ex)}, status_code=ex.status)

    async def body_json(request: Request) -> dict:
        try:
            b = await request.json()
            return b if isinstance(b, dict) else {}
        except ValueError:
            return {}

    @app.post("/api/login")
    async def login(request: Request):
        ip = client_ip(request)
        if request.headers.get("x-hsl") != "1":
            return JSONResponse({"error": "missing X-HSL header"}, status_code=403)
        b = await body_json(request)
        uname = str(b.get("username", "")).strip()
        wait = max(throttle.check(ip), user_throttle.check(uname.lower()))
        if wait:
            return JSONResponse({"error": f"Too many failed logins. Try again in {wait} s."},
                                status_code=429)
        user = await run_in_threadpool(users.verify, uname, str(b.get("password", "")))
        if not user:
            throttle.fail(ip)
            user_throttle.fail(uname.lower())
            log.warning("failed login for '%s' from %s", clean(uname), ip)
            return JSONResponse({"error": "Wrong username or password"}, status_code=401)
        throttle.ok(ip)
        user_throttle.ok(uname.lower())
        users.touch_login(user)
        log.info("user '%s' logged in from %s", user, ip)
        resp = JSONResponse({"user": users.public(user)})
        resp.set_cookie(COOKIE, sessions.create(user), httponly=True, samesite="strict",
                        secure=request.url.scheme == "https", path="/")
        return resp

    @app.post("/api/logout")
    def logout(request: Request):
        sessions.drop(request.cookies.get(COOKIE))
        resp = JSONResponse({"ok": True})
        resp.delete_cookie(COOKIE, path="/")
        return resp

    @app.get("/api/me")
    def me(request: Request):
        return {"user": users.public(request.state.user)}

    @app.put("/api/me/password")
    async def change_own_password(request: Request):
        b = await body_json(request)
        me_ = request.state.user
        ok = await run_in_threadpool(users.verify, me_, str(b.get("current_password", "")))
        if not ok:
            return JSONResponse({"error": "Current password is wrong"}, status_code=400)
        try:
            await run_in_threadpool(users.set_password, me_, str(b.get("new_password", "")))
        except AuthError as ex:
            return auth_error(ex)
        sessions.drop_user(me_, keep=request.cookies.get(COOKIE))
        basic_cache.clear()
        log.info("user '%s' changed own password", me_)
        return {"ok": True}

    @app.get("/api/users")
    def users_list(request: Request):
        return need_admin(request) or {"users": users.list()}

    @app.post("/api/users")
    async def users_add(request: Request):
        if (e := need_admin(request)):
            return e
        b = await body_json(request)
        try:
            await run_in_threadpool(users.add, str(b.get("username", "")),
                                    str(b.get("password", "")), str(b.get("role", "viewer")))
        except AuthError as ex:
            return auth_error(ex)
        log.info("user '%s' created user '%s' (%s)", request.state.user, clean(b.get("username")),
                 clean(b.get("role")))
        return {"user": users.public(str(b.get("username")).strip())}

    @app.put("/api/users/{username}")
    async def users_update(username: str, request: Request):
        if (e := need_admin(request)):
            return e
        b = await body_json(request)
        try:
            if "role" in b:
                users.set_role(username, str(b["role"]))
                sessions.drop_user(username, keep=request.cookies.get(COOKIE))
            if "password" in b:
                await run_in_threadpool(users.set_password, username, str(b["password"]))
                sessions.drop_user(username, keep=request.cookies.get(COOKIE))
                basic_cache.clear()
        except AuthError as ex:
            return auth_error(ex)
        log.info("user '%s' updated user '%s' (%s)", request.state.user, clean(username),
                 ", ".join(k for k in ("role", "password") if k in b))
        return {"user": users.public(username)}

    @app.delete("/api/users/{username}")
    def users_delete(username: str, request: Request):
        if (e := need_admin(request)):
            return e
        if username == request.state.user:
            return JSONResponse({"error": "You cannot delete your own account"}, status_code=400)
        try:
            users.delete(username)
        except AuthError as ex:
            return auth_error(ex)
        sessions.drop_user(username)
        basic_cache.clear()
        log.info("user '%s' deleted user '%s'", request.state.user, clean(username))
        return {"ok": True}

    def db_error(ex):
        msg = str(ex).strip().splitlines()[0] if str(ex).strip() else "error"
        msg = re.sub(r"\s*\(version [^)]*\)", "", msg)
        log.warning("database error on web request: %s", str(ex)[:300])
        return JSONResponse({"error": f"database: {msg[:200]}"}, status_code=503)

    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(BASE_DIR / "static" / "index.html")

    @app.get("/api/events")
    def events(request: Request):
        p = dict(request.query_params)
        try:
            where, args = build_where(p, names)
            args["limit"] = max(1, min(int(p.get("limit", 200)), 2000))
        except ValueError as ex:
            return JSONResponse({"error": str(ex)}, status_code=400)
        order = "id DESC" if p.get("after_id") else "ts DESC, id DESC"
        try:
            rows = ch.query(f"SELECT {SELECT_COLS} FROM events{where} ORDER BY {order} "  # nosec B608 - only bound {placeholders} and fixed column lists
                            "LIMIT {limit:UInt32}", args, JSON_SETTINGS)
        except ClickHouseError as ex:
            return db_error(ex)
        return {"items": [to_item(r, names) for r in rows]}

    @app.get("/api/export.csv")
    def export_csv(request: Request):
        p = dict(request.query_params)
        try:
            where, args = build_where(p, names)
            args["limit"] = max(1, min(int(p.get("limit", 100000)), 5_000_000))
            rn = names.all()
            args["rips"], args["rnames"] = ch_array(rn.keys()), ch_array(v["name"] for v in rn.values())
            resp = ch.stream(
                "SELECT toString(id) AS event_id, toString(ts) AS time_utc, exporter, "
                + csv_safe("transform(exporter, {rips:Array(String)}, {rnames:Array(String)}, '')",
                           "router_name") + ", kind, event, "
                "proto, src_ip, src_port, dst_ip, dst_port, bytes, packets, "
                f"{csv_safe('in_if_name')}, {csv_safe('out_if_name')}, {csv_safe('class_name')}, "
                "vrf, xlate_src_ip, xlate_src_port, xlate_dst_ip, xlate_dst_port, ext_event, "
                f"{csv_safe('message')}, {csv_safe('extra')} FROM events{where} "
                "ORDER BY ts DESC, id DESC LIMIT {limit:UInt32} FORMAT CSVWithNames", args)
        except ValueError as ex:
            return JSONResponse({"error": str(ex)}, status_code=400)
        except ClickHouseError as ex:
            return db_error(ex)

        def gen():
            with resp:
                while chunk := resp.read(65536):
                    yield chunk
        fn = time.strftime("hsl-events-%Y%m%d-%H%M%S.csv")
        return StreamingResponse(gen(), media_type="text/csv",
                                 headers={"Content-Disposition": f'attachment; filename="{fn}"'})

    @app.get("/api/stats")
    def stats(window: int = 3600):
        window = max(60, min(window, 30 * 86400))
        now = time.time()
        bucket = 60 if window <= 3 * 3600 else (300 if window <= 86400 else 3600)
        a = {"since": int(now - window), "bucket": bucket}
        since = "minute >= toDateTime({since:UInt32}, 'UTC')"
        try:
            hist = ch.query(
                "SELECT toUInt32(toStartOfInterval(minute, toIntervalSecond({bucket:UInt32}))) AS t, "  # nosec B608 - bound parameters only
                f"sum(n) AS total, sumIf(n, event = 'denied') AS denied FROM stats_1m "
                f"WHERE {since} GROUP BY t ORDER BY t", a, JSON_SETTINGS)
            hist = [{"t": h["t"], "n": h["total"], "denied": h["denied"]} for h in hist]
            by_event = ch.query(f"SELECT event, sum(n) AS n FROM stats_1m WHERE {since} "  # nosec B608 - bound parameters only
                                "GROUP BY event ORDER BY n DESC", a, JSON_SETTINGS)

            def talkers(d, denied=None):
                cond = "" if denied is None else f" AND denied = {denied}"
                return ch.query(f"SELECT ip, sum(n) AS n FROM talkers_1m WHERE {since} "  # nosec B608 - d and denied are internal constants
                                f"AND dir = '{d}'{cond} GROUP BY ip ORDER BY n DESC LIMIT 8",
                                a, JSON_SETTINGS)
            top_src, top_dst, top_denied = talkers("src"), talkers("dst"), talkers("src", 1)
            top_ports = ch.query(f"SELECT port, proto, sum(n) AS n FROM ports_1m WHERE {since} "  # nosec B608 - bound parameters only
                                 "GROUP BY port, proto ORDER BY n DESC LIMIT 8", a, JSON_SETTINGS)
            storage = ch.query(
                "SELECT sum(rows) AS rows, sum(bytes_on_disk) AS disk, "
                "sum(data_uncompressed_bytes) AS raw, min(min_time) AS oldest FROM system.parts "
                "WHERE active AND database = {db:String} AND table = 'events'",
                {"db": cfg["ch_database"]}, JSON_SETTINGS)[0]
        except ClickHouseError as ex:
            return db_error(ex)
        for r in top_ports:
            r["proto_name"] = PROTOS.get(r["proto"], r["proto"])
        h = sup.health()
        return {
            "now": now, "window": window, "bucket": bucket,
            "total_stored": storage["rows"] or 0, "disk_bytes": storage["disk"] or 0,
            "raw_bytes": storage["raw"] or 0,
            "in_window": sum(r["n"] for r in by_event),
            "rate": round(sum(v[2] for v in sup.rates.values()), 1),
            "histogram": hist, "by_event": by_event, "top_src": top_src, "top_dst": top_dst,
            "top_denied": top_denied, "top_ports": top_ports,
            "exporters": len(sup.rates), "health": h, "disk": guard.snapshot(),
            "status": overall_status(h, guard.snapshot()),
        }

    @app.get("/api/exporters")
    def exporters():
        rn = names.all()
        out = sup.exporters()
        for e in out:
            n = rn.get(e["exporter"])
            e["name"], e["name_source"] = (n["name"], n["source"]) if n else (None, None)
        return {"exporters": out}

    @app.get("/api/health")
    def health(request: Request, strict: int = 0):
        """Monitoring endpoint. ?strict=1 answers HTTP 503 when status is critical.
        Without login only the status and problem list are returned."""
        h = sup.health()
        try:
            ch.query("SELECT 1")
            h["database"] = "ok"
        except ClickHouseError as ex:
            h["database"] = str(ex)[:300]
        h["disk"] = guard.snapshot()
        h["status"], h["problems"] = overall_status(h, h["disk"], detail=True)
        code = 503 if strict and h["status"] == "critical" else 200
        if request.state.user is None:
            h = {"status": h["status"], "problems": h["problems"]}
        return JSONResponse(h, status_code=code)

    # ---- access list (who may send HSL / syslog)
    def acl_view():
        snap = acl.snapshot()
        rn = names.all()
        routers = [(e["exporter"], ipaddress.ip_address(e["exporter"]), e["last_seen"])
                   for e in sup.exporters() if _is_ip(e["exporter"])]
        recent = time.time() - 3600
        for e in snap["entries"]:
            net = ipaddress.ip_network(e["network"])
            hits = [ip for ip, a, _ in routers if a.version == net.version and a in net]
            e["routers"] = len(hits)
            e["router_names"] = [(rn.get(ip) or {}).get("name") or ip for ip in hits[:5]]
        nets = [ipaddress.ip_network(e["network"]) for e in snap["entries"]]
        uncovered = [ip for ip, a, seen in routers if seen > recent
                     and not any(a.version == n.version and a in n for n in nets)]
        unknown = sup.unknown_senders()
        for u in unknown:
            u["name"] = (rn.get(u["ip"]) or {}).get("name")
        snap.update(unlisted=unknown, active_not_listed=uncovered,
                    enforced_now=sup.rx.get("acl_enforce"))
        return snap

    def acl_error(ex):
        return JSONResponse({"error": str(ex)}, status_code=400)

    @app.get("/api/acl")
    def acl_get():
        return acl_view()

    @app.post("/api/acl")
    async def acl_add(request: Request):
        if (e := need_admin(request)):
            return e
        b = await body_json(request)
        try:
            if "lines" in b:                      # bulk: "ip[/len][,description]" per line
                res = acl.add_many(acl_lines(str(b["lines"])), request.state.user)
            elif "entries" in b:                  # [{network, description}, ...]
                res = acl.add_many([(str(x.get("network", "")), str(x.get("description", "")))
                                    for x in list(b["entries"])[:MAX_BULK]], request.state.user)
            else:
                res = acl.add_many([(str(b.get("network", "")), str(b.get("description", "")))],
                                   request.state.user)
        except AclError as ex:
            return acl_error(ex)
        if res["added"]:
            log.info("user '%s' added to access list: %s", request.state.user,
                     ", ".join(e["network"] for e in res["added"][:20]))
        return {**res, "acl": acl_view()}

    @app.put("/api/acl/mode")
    async def acl_mode(request: Request):
        if (e := need_admin(request)):
            return e
        b = await body_json(request)
        try:
            acl.set_mode(str(b.get("mode", "")))
        except AclError as ex:
            return acl_error(ex)
        log.warning("user '%s' set access list mode to %s", request.state.user, clean(b.get("mode")))
        return acl_view()

    @app.put("/api/acl/{entry_id}")
    async def acl_update(entry_id: str, request: Request):
        if (e := need_admin(request)):
            return e
        b = await body_json(request)
        try:
            acl.update(entry_id, str(b.get("description", "")))
        except AclError as ex:
            return acl_error(ex)
        return acl_view()

    @app.delete("/api/acl/{entry_id}")
    def acl_delete(entry_id: str, request: Request):
        if (e := need_admin(request)):
            return e
        try:
            removed = acl.remove(entry_id)
        except AclError as ex:
            return acl_error(ex)
        log.warning("user '%s' removed %s from access list", request.state.user, removed["network"])
        return acl_view()

    # ---- HTTPS certificate
    def tls_off():
        return JSONResponse({"error": "HTTPS is switched off on the server (--no-tls)"}, status_code=400)

    def cert_error(ex: CertError):
        return JSONResponse({"error": ex.errors[0], "errors": ex.errors}, status_code=400)

    def req_host(request: Request) -> list[str]:
        h = request.headers.get("host", "")
        h = h[1:h.index("]")] if h.startswith("[") and "]" in h else h.rsplit(":", 1)[0] if h.count(":") == 1 else h
        return [h] if h else []

    def b64field(b: dict, name: str) -> bytes | None:
        """File uploads arrive base64 encoded (<name>_b64); pasted text as <name>_text."""
        if b.get(name + "_b64"):
            try:
                return base64.b64decode(str(b[name + "_b64"]), validate=True)
            except ValueError:
                raise CertError("The uploaded file could not be read")
        if b.get(name + "_text"):
            return str(b[name + "_text"]).encode()
        return None

    def tls_view(warnings=None):
        out = tls.info()
        out.update(enabled=True, key_types=KEY_TYPES, https_port=cfg["web_port"],
                   http_port=cfg["http_port"], warnings=warnings or [])
        return out

    @app.get("/api/tls")
    def tls_get():
        if tls is None:
            return {"enabled": False}
        return tls_view()

    async def tls_change(request: Request, what: str, fn):
        if (e := need_admin(request)):
            return e
        if tls is None:
            return tls_off()
        b = await body_json(request)
        try:
            warnings = await run_in_threadpool(fn, b)
        except CertError as ex:
            log.warning("user '%s': certificate %s rejected: %s", request.state.user, what,
                        clean(ex.errors[0], 200))
            return cert_error(ex)
        a = tls.info().get("active") or {}
        log.warning("user '%s': certificate %s - now %s, issued by %s, valid until %s, SHA-256 %s",
                    request.state.user, what, a.get("subject"), a.get("issuer"),
                    time.strftime("%Y-%m-%d", time.gmtime(a.get("not_after", 0))), a.get("sha256"))
        return tls_view(warnings if isinstance(warnings, list) else [])

    @app.post("/api/tls/csr")
    async def tls_csr(request: Request):
        if (e := need_admin(request)):
            return e
        if tls is None:
            return tls_off()
        b = await body_json(request)
        names = b.get("names") or []
        if isinstance(names, str):
            names = re.split(r"[\s,;]+", names)
        try:
            await run_in_threadpool(tls.create_csr, b.get("common_name", ""), list(names)[:100],
                                    b.get("organization", ""), b.get("country", ""),
                                    str(b.get("key_type", "rsa2048")), request.state.user)
        except CertError as ex:
            return cert_error(ex)
        log.info("user '%s' created a certificate request for %s", request.state.user,
                 clean(b.get("common_name"), 100))
        return tls_view()

    @app.get("/api/tls/csr.pem")
    def tls_csr_download(request: Request):
        if (e := need_admin(request)):
            return e
        p = (tls.info().get("pending") or {}) if tls else {}
        if not p:
            return JSONResponse({"error": "no open certificate request"}, status_code=404)
        fn = re.sub(r"[^A-Za-z0-9.-]", "_", p["common_name"]) + ".csr"
        return Response(p["csr"], media_type="application/pkcs10",
                        headers={"Content-Disposition": f'attachment; filename="{fn}"'})

    @app.delete("/api/tls/csr")
    def tls_csr_cancel(request: Request):
        if (e := need_admin(request)):
            return e
        if tls is None:
            return tls_off()
        tls.cancel_csr()
        log.info("user '%s' cancelled the certificate request", request.state.user)
        return tls_view()

    @app.post("/api/tls/csr/complete")
    async def tls_csr_complete(request: Request):
        def go(b):
            data = b64field(b, "cert")
            if not data:
                raise CertError("Upload or paste the signed certificate")
            return tls.complete_csr(data, request.state.user, req_host(request))
        return await tls_change(request, "installed (signed for this server's request)", go)

    @app.post("/api/tls/import")
    async def tls_import(request: Request):
        def go(b):
            pfx = b64field(b, "pfx")
            if pfx:
                return tls.import_pkcs12(pfx, b.get("password") or None, request.state.user,
                                         req_host(request))
            cert, key = b64field(b, "cert"), b64field(b, "key")
            if not cert or not key:
                raise CertError("Provide the certificate and its private key, or a .pfx/.p12 file")
            return tls.import_pair(cert, key, b.get("password") or None, request.state.user,
                                   req_host(request))
        return await tls_change(request, "imported", go)

    @app.post("/api/tls/self-signed")
    async def tls_self_signed(request: Request):
        def go(b):
            names = b.get("names") or []
            if isinstance(names, str):
                names = re.split(r"[\s,;]+", names)
            return tls.self_signed([n for n in names if n][:100], request.state.user)
        return await tls_change(request, "replaced by a new self-signed certificate", go)

    @app.post("/api/tls/rollback")
    async def tls_rollback(request: Request):
        return await tls_change(request, "rolled back to the previous one",
                                lambda b: tls.rollback(request.state.user) or [])

    # ---- router names
    @app.get("/api/routers")
    def routers_list():
        return {"routers": names.all()}

    @app.put("/api/routers/{ip}")
    async def routers_set(ip: str, request: Request):
        if (e := need_admin(request)):
            return e
        try:
            body = await request.json()
            ip, name = names.set(ip, str(body.get("name", "")))
        except ValueError as ex:
            return JSONResponse({"error": f"invalid: {ex}"}, status_code=400)
        except ClickHouseError as ex:
            return db_error(ex)
        return {"exporter": ip, "name": name}

    @app.post("/api/routers/import")
    async def routers_import(request: Request):
        if (e := need_admin(request)):
            return e
        text = (await request.body()).decode("utf-8", "replace")
        if len(text) > 5_000_000:
            return JSONResponse({"error": "file too large"}, status_code=413)
        try:
            return names.import_csv(text)
        except ClickHouseError as ex:
            return db_error(ex)

    @app.get("/api/routers.csv")
    def routers_csv():
        buf = io.StringIO()
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(["ip", "name", "source"])
        for ip, v in sorted(names.all().items()):
            w.writerow([ip, csv_cell(v["name"]), v["source"]])
        return Response(buf.getvalue(), media_type="text/csv",
                        headers={"Content-Disposition": 'attachment; filename="routers.csv"'})

    @app.get("/api/templates")
    def templates():
        return sup.templates_snapshot()

    @app.get("/api/meta")
    def meta():
        return {"version": __version__, "uptime": time.time() - sup.started,
                "flow_port": cfg["flow_port"], "syslog_port": cfg["syslog_port"],
                "retention_days": cfg["retention_days"], "workers": cfg["workers"],
                "database": f"{strip_userinfo(cfg['ch_url'])} / {cfg['ch_database']}",
                "https": tls is not None, "web_port": cfg["web_port"], "http_port": cfg["http_port"]}

    return app


# ---------------------------------------------------------------- main
def env(name, default):
    return os.environ.get(name, default)


def main():
    ap = argparse.ArgumentParser(description="Cisco SD-WAN HSL collector with web GUI (ClickHouse)")
    ap.add_argument("--listen", default=env("HSL_LISTEN", "0.0.0.0"))  # nosec B104 - network service; restrict with --listen
    ap.add_argument("--flow-port", type=int, default=int(env("HSL_FLOW_PORT", 2055)))
    ap.add_argument("--syslog-port", type=int, default=int(env("HSL_SYSLOG_PORT", 5514)),
                    help="0 disables the syslog listener")
    ap.add_argument("--web-host", default=env("HSL_WEB_HOST", "0.0.0.0"))  # nosec B104 - network service; restrict with --web-host
    ap.add_argument("--web-port", type=int, default=int(env("HSL_WEB_PORT", 8443)),
                    help="HTTPS port of the GUI (default 8443)")
    ap.add_argument("--http-port", type=int, default=int(env("HSL_HTTP_PORT", 8080)),
                    help="plain-HTTP port that only redirects to HTTPS; 0 = off (default 8080)")
    ap.add_argument("--no-tls", action="store_true", default=env("HSL_TLS", "on").lower() in ("off", "0", "no"),
                    help="serve plain HTTP on --web-port - only behind a TLS reverse proxy")
    ap.add_argument("--tls-hostnames", default=env("HSL_TLS_HOSTNAMES", ""),
                    help="extra names/IPs for the generated self-signed certificate, comma separated")
    ap.add_argument("--public-health", action=argparse.BooleanOptionalAction,
                    default=env("HSL_PUBLIC_HEALTH", "1") in ("1", "true", "yes"),
                    help="allow /api/health without login, for monitoring (default on)")
    ap.add_argument("--allow", default=env("HSL_ALLOW", ""),
                    help="fixed access-list entries, comma separated (e.g. 10.0.0.0/8,192.0.2.10). "
                         "When set, enforcement is always on. More entries can be added in the GUI")
    ap.add_argument("--max-exporters", type=int, default=int(env("HSL_MAX_EXPORTERS", 2000)),
                    help="max routers tracked per decoder process (default 2000)")
    ap.add_argument("--max-templates", type=int, default=int(env("HSL_MAX_TEMPLATES", 256)),
                    help="max templates kept per router (default 256)")
    ap.add_argument("--tls-cert", default=env("HSL_TLS_CERT", ""),
                    help="use this certificate file (PEM, with chain) instead of the GUI-managed one")
    ap.add_argument("--tls-key", default=env("HSL_TLS_KEY", ""))
    ap.add_argument("--trusted-proxies", default=env("HSL_TRUSTED_PROXIES", ""),
                    help="reverse proxy addresses whose X-Forwarded-For/-Proto headers are "
                         "trusted, comma separated (default: none)")
    ap.add_argument("--allowed-hosts", default=env("HSL_ALLOWED_HOSTS", ""),
                    help="host names the GUI answers to, comma separated (default: any)")
    ap.add_argument("--reset-admin", action="store_true",
                    help="reset user 'admin' to password 'admin' (role admin) and exit")
    ap.add_argument("--workers", type=int,
                    default=int(env("HSL_WORKERS", max(1, min(8, (os.cpu_count() or 2) - 1)))),
                    help="decoder processes (default: CPU cores - 1, max 8)")
    ap.add_argument("--ch-url", default=env("HSL_CH_URL", "http://127.0.0.1:8123"))
    ap.add_argument("--ch-user", default=env("HSL_CH_USER", "default"))
    ap.add_argument("--ch-password", default=env("HSL_CH_PASSWORD", ""))
    ap.add_argument("--ch-database", default=env("HSL_CH_DATABASE", "hsl"))
    ap.add_argument("--retention-days", type=float, default=float(env("HSL_RETENTION_DAYS", 7)),
                    help="0 keeps everything")
    ap.add_argument("--state-dir", default=env("HSL_STATE_DIR", str(BASE_DIR / "state")),
                    help="where learned templates are saved across restarts")
    ap.add_argument("--rcvbuf", type=int, default=int(env("HSL_RCVBUF", 32 * 1024 * 1024)))
    ap.add_argument("--batch-rows", type=int, default=int(env("HSL_BATCH_ROWS", 50000)))
    ap.add_argument("--flush-interval", type=float, default=float(env("HSL_FLUSH_INTERVAL", 1.0)))
    ap.add_argument("--max-buffer-mb", type=float, default=float(env("HSL_MAX_BUFFER_MB", 256)),
                    help="memory per decoder for rows waiting while ClickHouse is unreachable")
    ap.add_argument("--min-free-pct", type=float, default=float(env("HSL_MIN_FREE_PCT", 15)),
                    help="delete oldest days when disk free space falls below this (default 15)")
    ap.add_argument("--warn-free-pct", type=float, default=float(env("HSL_WARN_FREE_PCT", 25)),
                    help="show a warning below this free space (default 25)")
    ap.add_argument("--guard-interval", type=float, default=float(env("HSL_GUARD_INTERVAL", 60)),
                    help="seconds between disk checks")
    ap.add_argument("--rdns", action="store_true", default=env("HSL_RDNS", "") in ("1", "true", "yes"),
                    help="name routers by reverse DNS when no name was set")
    ap.add_argument("--log-level", default=env("HSL_LOG_LEVEL", "INFO"))
    a = ap.parse_args()
    if a.reset_admin:
        UserStore(a.state_dir).reset_admin()
        print("User 'admin' reset to password 'admin'. Log in and change it.")
        return
    cfg = vars(a)
    cfg["allow_config"] = [x.strip() for x in a.allow.split(",") if x.strip()]
    try:
        for x in cfg["allow_config"]:
            parse_network(x)
    except AclError as ex:
        ap.error(f"--allow: {ex}")
    if bool(a.tls_cert) != bool(a.tls_key):
        ap.error("--tls-cert and --tls-key go together")
    cfg["allowed_hosts"] = [h.strip() for h in a.allowed_hosts.split(",") if h.strip()]
    cfg["limits"] = {"max_exporters": max(1, a.max_exporters),
                     "max_templates": max(8, a.max_templates)}
    state = Path(a.state_dir)
    state.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(state, 0o700)                       # users.json and templates live here
    except OSError:
        pass
    cfg["log_level"] = a.log_level.upper()
    cfg["worker_queue"] = 2000                      # batches (of up to 500 packets) per decoder
    cfg["workers"] = max(1, min(a.workers, 64))
    logging.basicConfig(level=cfg["log_level"],
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    ch = ClickHouse(a.ch_url, a.ch_user, a.ch_password, a.ch_database)
    for attempt in range(30):
        try:
            ensure_schema(ch, a.retention_days)
            break
        except ClickHouseError as ex:
            if attempt == 29:
                raise SystemExit(f"ClickHouse not usable: {ex}")
            log.warning("waiting for ClickHouse (%s) ...", str(ex)[:150])
            time.sleep(2)
    eff = AclStore(a.state_dir, cfg["allow_config"]).effective()
    if not eff["enforce"]:
        log.warning("access list not enforced: accepting HSL and syslog from ANY address - "
                    "switch it on in the GUI (Access list) in production")
    tls = None
    if a.no_tls:
        log.warning("HTTPS switched off (--no-tls): serving plain HTTP on port %d - only use this "
                    "behind a reverse proxy that terminates TLS", a.web_port)
    else:
        try:
            tls = TlsManager(a.state_dir, a.tls_cert, a.tls_key,
                             [x.strip() for x in a.tls_hostnames.split(",") if x.strip()])
        except (OSError, CertError) as ex:
            raise SystemExit(f"HTTPS certificate problem: {ex}")
        info = tls.info().get("active") or {}
        log.info("HTTPS certificate: %s (%s), valid until %s", info.get("subject"),
                 "self-signed" if info.get("self_signed") else f"issued by {info.get('issuer')}",
                 time.strftime("%Y-%m-%d", time.gmtime(info.get("not_after", 0))))
    asyncio.run(serve(cfg, create_app(cfg, tls), tls))


class _QuietServer(uvicorn.Server):
    """Second server (HTTP redirect): leaves signal handling to the main server."""

    @contextlib.contextmanager
    def capture_signals(self):
        yield


_HOST_RE = re.compile(r"^(\[[0-9A-Fa-f:.]+\]|[A-Za-z0-9.-]{1,253})(:\d{1,5})?$")


def redirect_app(https_port: int, allowed_hosts: list[str]):
    """Plain-HTTP app: every request gets a redirect to the same path over HTTPS."""
    suffix = "" if https_port == 443 else f":{https_port}"

    async def app(scope, receive, send):
        if scope["type"] != "http":
            return
        host = dict(scope.get("headers") or []).get(b"host", b"").decode("latin-1")
        m = _HOST_RE.match(host)
        name = m.group(1) if m else ""
        if not name or (allowed_hosts and name.strip("[]") not in allowed_hosts):
            await send({"type": "http.response.start", "status": 400,
                        "headers": [(b"content-type", b"text/plain")]})
            await send({"type": "http.response.body", "body": b"Use HTTPS\n"})
            return
        path = scope.get("raw_path") or scope["path"].encode()
        if not path.startswith(b"/"):
            path = b"/" + path
        if scope.get("query_string"):
            path += b"?" + scope["query_string"]
        location = f"https://{name}{suffix}".encode() + path
        await send({"type": "http.response.start", "status": 301,
                    "headers": [(b"location", location), (b"content-length", b"0"),
                                (b"cache-control", b"no-store")]})
        await send({"type": "http.response.body", "body": b""})
    return app


async def serve(cfg: dict, app, tls):
    proxies = cfg["trusted_proxies"].strip()
    common = dict(host=cfg["web_host"], log_level="warning", access_log=False, server_header=False)
    if tls is not None:
        main_cfg = uvicorn.Config(app, port=cfg["web_port"], proxy_headers=bool(proxies),
                                  forwarded_allow_ips=proxies or None,
                                  ssl_certfile=str(tls.cert_path), ssl_keyfile=str(tls.key_path),
                                  ssl_context_factory=lambda config, default: tls.make_context(),
                                  **common)
    else:
        main_cfg = uvicorn.Config(app, port=cfg["web_port"], proxy_headers=bool(proxies),
                                  forwarded_allow_ips=proxies or None, **common)
    main = uvicorn.Server(main_cfg)
    extra = []
    if tls is not None and cfg["http_port"]:
        extra.append(_QuietServer(uvicorn.Config(redirect_app(cfg["web_port"], cfg["allowed_hosts"]),
                                                 port=cfg["http_port"], lifespan="off", **common)))
        log.info("HTTP port %d redirects to HTTPS port %d", cfg["http_port"], cfg["web_port"])
    tasks = [asyncio.create_task(s.serve()) for s in extra]
    await main.serve()
    for s in extra:
        s.should_exit = True
    await asyncio.gather(*tasks, return_exceptions=True)


if __name__ == "__main__":
    main()
